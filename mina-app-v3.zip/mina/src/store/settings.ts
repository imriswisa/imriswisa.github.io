import AsyncStorage from '@react-native-async-storage/async-storage';
import { create } from 'zustand';

export type ThemeMode = 'system' | 'light' | 'dark';
const KEY = 'mina.themeMode';

interface SettingsState {
  themeMode: ThemeMode;
  captions: boolean;
  setCaptions(on: boolean): void;
  load(): Promise<void>;
  setThemeMode(mode: ThemeMode): void;
}

export const useSettings = create<SettingsState>((set) => ({
  themeMode: 'system',
  captions: true,
  async load() {
    const v = await AsyncStorage.getItem(KEY).catch(() => null);
    if (v === 'light' || v === 'dark' || v === 'system') set({ themeMode: v });
    const c = await AsyncStorage.getItem('mina.captions').catch(() => null);
    if (c === 'off') set({ captions: false });
  },
  setCaptions(on) {
    set({ captions: on });
    AsyncStorage.setItem('mina.captions', on ? 'on' : 'off').catch(() => {});
  },
  setThemeMode(mode) {
    set({ themeMode: mode });
    AsyncStorage.setItem(KEY, mode).catch(() => {});
  },
}));
