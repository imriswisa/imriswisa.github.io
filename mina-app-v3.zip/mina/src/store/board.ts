import { create } from 'zustand';
import type { BoardBlock } from '../lib/live/tools';

interface BoardState {
  title: string | null;
  blocks: BoardBlock[];
  show(blocks: BoardBlock[], opts: { title?: string; append?: boolean }): void;
  reveal(): number;
  clear(): void;
}

const MAX_BLOCKS = 10;

export const useBoard = create<BoardState>((set, get) => ({
  title: null,
  blocks: [],
  show(blocks, { title, append }) {
    set((s) => ({
      title: title ?? (append ? s.title : null),
      blocks: (append ? [...s.blocks, ...blocks] : blocks).slice(-MAX_BLOCKS),
    }));
  },
  reveal() {
    const hidden = get().blocks.filter((b) => b.kind === 'fill_blank' && !b.revealed).length;
    set((s) => ({ blocks: s.blocks.map((b) => (b.kind === 'fill_blank' ? { ...b, revealed: true } : b)) }));
    return hidden;
  },
  clear() {
    set({ title: null, blocks: [] });
  },
}));
