import type { Session } from '@supabase/supabase-js';
import { create } from 'zustand';
import { isBackendConfigured } from '../lib/config';
import type { Cefr } from '../lib/live/tools';
import { supabase } from '../lib/supabase';

export interface Profile {
  id: string;
  display_name: string | null;
  cefr_level: Cefr;
  interests: string[];
  goal: string | null;
  daily_minutes: number;
  hebrew_usage: 'low' | 'medium' | 'high';
  native_language: string;
  target_language: string;
  mina_voice: string;
  correction_style: 'gentle' | 'normal' | 'strict';
  speech_speed: 'slow' | 'normal' | 'fast';
  onboarded: boolean;
}

interface AuthState {
  ready: boolean;
  session: Session | null;
  profile: Profile | null;
  profileError: string | null;
  init(): void;
  loadProfile(): Promise<void>;
  updateProfile(patch: Partial<Omit<Profile, 'id'>>): Promise<string | null>;
  signOut(): Promise<void>;
}

let started = false;

export const useAuth = create<AuthState>((set, get) => ({
  ready: false,
  session: null,
  profile: null,
  profileError: null,

  init() {
    if (started) return;
    started = true;
    if (!isBackendConfigured) {
      set({ ready: true });
      return;
    }
    supabase.auth
      .getSession()
      .then(async ({ data }) => {
        set({ session: data.session });
        if (data.session) await get().loadProfile();
      })
      .catch(() => {})
      .finally(() => set({ ready: true }));

    supabase.auth.onAuthStateChange((_event, session) => {
      const before = get().session?.user.id;
      set({ session });
      if (!session) set({ profile: null });
      else if (session.user.id !== before) void get().loadProfile();
    });
  },

  async loadProfile() {
    const user = get().session?.user;
    if (!user) return;
    let { data, error } = await supabase.from('profiles').select('*').eq('id', user.id).maybeSingle();
    if (!error && !data) {
      // The sign-up trigger normally creates the row; cover accounts made before it existed.
      const created = await supabase.from('profiles').insert({ id: user.id }).select('*').single();
      data = created.data;
      error = created.error;
    }
    if (error) set({ profileError: error.message });
    else set({ profile: data as Profile, profileError: null });
  },

  async updateProfile(patch) {
    const user = get().session?.user;
    if (!user) return 'not-signed-in';
    const { data, error } = await supabase
      .from('profiles')
      .update({ ...patch, updated_at: new Date().toISOString() })
      .eq('id', user.id)
      .select('*')
      .single();
    if (error) return error.message;
    set({ profile: data as Profile });
    return null;
  },

  async signOut() {
    await supabase.auth.signOut();
    set({ session: null, profile: null });
  },
}));
