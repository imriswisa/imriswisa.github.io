import React from 'react';
import { View } from 'react-native';
import { Mina } from '@/components/Mina';
import { Card, Screen, T } from '@/components/ui';

/** Shown when the app has no backend keys yet. Nothing is faked: lessons need the backend. */
export default function Setup() {
  return (
    <Screen>
      <View style={{ alignItems: 'center' }}>
        <Mina size={170} emotion="confused" />
      </View>
      <T v="title">עוד רגע מתחילים</T>
      <T>האפליקציה עדיין לא מחוברת לשרת, ולכן אי אפשר להתחבר או לדבר עם מינה. צריך להגדיר פעם אחת:</T>
      <Card>
        <T v="label">1. פרויקט Supabase (חינם)</T>
        <T v="soft">להריץ את הקובץ supabase/migrations/0001_init.sql ולהעלות את הפונקציה live-token.</T>
      </Card>
      <Card>
        <T v="label">2. מפתח Gemini (חינם)</T>
        <T v="soft">ליצור מפתח ב-Google AI Studio ולשמור אותו כסוד בשם GEMINI_API_KEY בפונקציה, לא באפליקציה.</T>
      </Card>
      <Card>
        <T v="label">3. קובץ ‎.env</T>
        <T v="soft">להעתיק את ‎.env.example ל-‎.env, למלא את כתובת הפרויקט ואת המפתח הציבורי, ולהפעיל מחדש.</T>
      </Card>
      <T v="soft">ההוראות המלאות, צעד אחר צעד, נמצאות בקובץ README.md.</T>
    </Screen>
  );
}
