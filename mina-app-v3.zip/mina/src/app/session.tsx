import { Ionicons } from '@expo/vector-icons';
import { useLocalSearchParams, useRouter } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { ActivityIndicator, Linking, Platform, Pressable, StyleSheet, View } from 'react-native';
import Animated, { useAnimatedStyle, useSharedValue, withTiming } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Mina } from '@/components/Mina';
import { QuotaWait } from '@/components/QuotaWait';
import { Whiteboard } from '@/components/Whiteboard';
import { Button, Card, Notice, Screen, T, tap } from '@/components/ui';
import { lessonById } from '@/lib/curriculum';
import { useLiveLesson, type LessonError } from '@/lib/live/useLiveLesson';
import { useLangs } from '@/lib/useLangs';
import { useSettings } from '@/store/settings';
import { useTheme } from '@/theme';

const ERRORS: Record<LessonError, { title: string; body: string }> = {
  'mic-denied': { title: 'מינה לא שומעת אותך', body: 'צריך לאשר גישה למיקרופון כדי לדבר איתה. אפשר לאשר בהגדרות ואז לנסות שוב.' },
  'audio-unavailable': { title: 'המיקרופון לא זמין', body: 'לא הצלחנו להפעיל את המיקרופון במכשיר הזה. אם אפליקציה אחרת משתמשת בו, סגרו אותה ונסו שוב.' },
  offline: { title: 'אין חיבור', body: 'נראה שהאינטרנט נפל. בדקו את החיבור ונסו שוב.' },
  'not-deployed': { title: 'השרת עוד לא מוכן', body: 'הפונקציה live-token לא הועלתה ל-Supabase. ההוראות נמצאות ב-README.md.' },
  'missing-key': { title: 'חסר מפתח Gemini', body: 'צריך לשמור את הסוד GEMINI_API_KEY בפונקציה live-token ב-Supabase.' },
  'key-rejected': { title: 'מפתח Gemini נדחה', body: 'Google דחתה את המפתח. בדקו שהוא הועתק נכון ושהוא פעיל ב-Google AI Studio.' },
  quota: { title: 'מינה צריכה הפסקה קטנה', body: 'הגענו למגבלת השימוש החינמי של שירות הקול.' },
  service: { title: 'מינה לא זמינה כרגע', body: 'שירות הקול לא הגיב. נסו שוב בעוד רגע.' },
  expired: { title: 'השיחה פגה', body: 'החיבור לשיחה פג תוקף. התחילו שיעור חדש.' },
  unauthorized: { title: 'צריך להתחבר מחדש', body: 'ההתחברות שלך פגה. צאו מהחשבון והיכנסו שוב.' },
};

/** Captions follow the language Mina is speaking: Hebrew and Arabic read right-to-left. */
const isLtr = (s: string) => (s.match(/[A-Za-zÀ-ɏЀ-ӿ]/g)?.length ?? 0) > (s.match(/[\u0590-\u06FF]/g)?.length ?? 0);

const clock = (s: number) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;

export default function Session() {
  const t = useTheme();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{ mode?: string; topic?: string; title?: string; lessonId?: string }>();
  const plan = lessonById(params.lessonId);
  const lesson = useLiveLesson(params.mode ?? 'free', params.topic, plan);
  const { native, target } = useLangs();
  const [captions, setCaptions] = useState(useSettings.getState().captions);

  const leave = () => (router.canGoBack() ? router.back() : router.replace('/'));

  if (lesson.phase === 'error' && lesson.error) {
    const e = ERRORS[lesson.error];
    return (
      <Screen>
        <View style={{ alignItems: 'center', marginTop: 20 }}>
          <Mina size={170} emotion="confused" />
        </View>
        <T v="title" center>
          {e.title}
        </T>
        <T center>{e.body}</T>
        {lesson.error === 'quota' && lesson.quota ? <QuotaWait quota={lesson.quota} onRetry={lesson.retry} /> : null}
        <View style={{ flex: 1 }} />
        {lesson.error === 'mic-denied' && Platform.OS !== 'web' ? (
          <Button title="לפתוח הגדרות" onPress={() => Linking.openSettings()} />
        ) : null}
        {lesson.error !== 'quota' || !lesson.quota ? (
          <Button title="לנסות שוב" kind={lesson.error === 'mic-denied' && Platform.OS !== 'web' ? 'ghost' : 'primary'} onPress={lesson.retry} />
        ) : null}
        <Button kind="ghost" title="חזרה" onPress={leave} />
      </Screen>
    );
  }

  if (lesson.phase === 'ended' && lesson.result) {
    const r = lesson.result;
    return (
      <Screen>
        <View style={{ alignItems: 'center' }}>
          <Mina size={150} emotion={r.seconds >= 60 ? 'excited' : 'encouraging'} />
        </View>
        <T v="title" center>
          {r.seconds >= 60 ? 'איזה שיעור!' : 'קצר, אבל נחשב'}
        </T>
        <T v="soft" center>
          דיברת עם מינה {clock(r.seconds)} דקות
        </T>
        {lesson.error ? <Notice tone="bad" text={`השיעור נקטע: ${ERRORS[lesson.error].title}. מה שלמדת עד כאן נשמר.`} /> : null}
        {lesson.error === 'quota' && lesson.quota ? <QuotaWait quota={lesson.quota} /> : null}
        {!r.saved ? <Notice tone="bad" text="לא הצלחנו לשמור את השיעור בהיסטוריה בגלל בעיית חיבור." /> : null}
        {r.newLevel ? (
          <Card color={t.mint}>
            <T v="label">הרמה שמינה קבעה: {r.newLevel}</T>
            <T v="soft" style={{ color: t.ink }}>
              השיעורים הבאים יותאמו אליה. אפשר לשנות בפרופיל.
            </T>
          </Card>
        ) : null}
        {r.mistakes.length > 0 ? (
          <Card>
            <T v="label">מה תיקנו היום</T>
            {r.mistakes.map((m, i) => (
              <View key={i} style={{ marginTop: 8 }}>
                <T ltr={!target.rtl} style={{ color: t.bad, textDecorationLine: 'line-through' }}>
                  {m.wrong}
                </T>
                <T ltr={!target.rtl} v="label" style={{ color: t.good }}>
                  {m.correct}
                </T>
                {m.explanation ? <T v="soft">{m.explanation}</T> : null}
                {m.times > 1 ? <T v="small">זו כבר הפעם ה-{m.times}. מינה תחזור לזה.</T> : null}
              </View>
            ))}
          </Card>
        ) : null}
        {r.words.length > 0 ? (
          <Card>
            <T v="label">מילים חדשות</T>
            {r.words.map((w, i) => (
              <T key={i}>
                {w.translation} · <T ltr={!target.rtl} v="label">{w.word}</T>
              </T>
            ))}
          </Card>
        ) : null}
        {r.mistakes.length === 0 && r.words.length === 0 && r.seconds >= 60 ? (
          <Card>
            <T v="soft">מינה לא שמרה תיקונים או מילים חדשות בשיעור הזה.</T>
          </Card>
        ) : null}
        {r.mistakes.length > 0 ? (
          <Card color={t.butter}>
            <T v="label">לשיעור הבא</T>
            <T v="soft" style={{ color: t.ink }}>
              מינה תפתח בחזרה על התיקונים האלה. אפשר לעבור עליהם בינתיים בלשונית ״חזרה״.
            </T>
          </Card>
        ) : null}
        <View style={{ flex: 1 }} />
        <Button title="סיום" onPress={leave} />
      </Screen>
    );
  }

  const preparing = lesson.phase === 'preparing';

  return (
    <View style={[styles.root, { backgroundColor: t.bg, paddingTop: insets.top + 8, paddingBottom: insets.bottom + 14 }]}>
      <View style={styles.top}>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="לסיים את השיעור"
          hitSlop={12}
          onPress={() => {
            tap();
            if (preparing) leave();
            else void lesson.finish();
          }}
          style={[styles.round, { backgroundColor: t.card, borderColor: t.line }]}
        >
          <Ionicons name="close" size={22} color={t.ink} />
        </Pressable>
        <View style={{ flex: 1, alignItems: 'center' }}>
          <T v="label" center numberOfLines={1}>
            {params.title ?? 'שיחה עם מינה'}
          </T>
          <T v="small" center>
            {preparing ? 'מתחברים…' : clock(lesson.seconds)}
          </T>
        </View>
        <View style={styles.round} />
      </View>

      {lesson.phase === 'reconnecting' ? <Notice text="החיבור נקטע. מנסים להתחבר מחדש…" /> : null}
      {lesson.audioBlocked && lesson.phase === 'live' ? (
        <Pressable
          accessibilityRole="button"
          onPress={() => {
            tap();
            lesson.unblockAudio();
          }}
          style={[styles.unblock, { backgroundColor: t.primary }]}
        >
          <Ionicons name="volume-high" size={22} color={t.onPrimary} />
          <T v="label" style={{ color: t.onPrimary }}>
            הקישו כאן כדי לשמוע את מינה
          </T>
        </Pressable>
      ) : null}

      <View style={styles.stage}>
        <Mina size={190} emotion={lesson.emotion} talk={lesson.talk} getLevel={lesson.getLevel} />
        <T v="small" center accessibilityLiveRegion="polite">
          {preparing
            ? 'מינה בדרך…'
            : lesson.muted
              ? 'המיקרופון מושתק'
              : lesson.talk === 'speaking'
                ? 'מינה מדברת · אפשר לקטוע אותה'
                : lesson.talk === 'thinking'
                  ? 'מינה חושבת…'
                  : 'מינה מקשיבה'}
        </T>
        {preparing ? <ActivityIndicator color={t.ink} style={{ marginTop: 6 }} /> : null}
      </View>

      <View style={{ flex: 1, minHeight: 160 }}>
        <Whiteboard />
      </View>

      {captions && lesson.caption ? (
        <T v="soft" center numberOfLines={2} style={{ minHeight: 44, writingDirection: isLtr(lesson.caption) ? 'ltr' : 'rtl' }}>
          {lesson.caption}
        </T>
      ) : (
        <View style={{ minHeight: 44 }} />
      )}

      <View style={styles.controls}>
        <Control
          icon={captions ? 'chatbox-ellipses' : 'chatbox-ellipses-outline'}
          label={captions ? 'להסתיר כתוביות' : 'להציג כתוביות'}
          text="כתוביות"
          onPress={() => setCaptions((c) => !c)}
        />
        <MicButton muted={lesson.muted} disabled={preparing} getMicLevel={lesson.getMicLevel} onPress={() => lesson.setMuted(!lesson.muted)} />
        <Control icon="language" label={`לבקש הסבר ב${native.he}`} text={`ב${native.he}`} disabled={preparing} onPress={lesson.askForHebrew} />
      </View>
    </View>
  );
}

function Control({
  icon,
  label,
  text,
  onPress,
  disabled,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
  text: string;
  onPress: () => void;
  disabled?: boolean;
}) {
  const t = useTheme();
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      disabled={disabled}
      onPress={() => {
        tap();
        onPress();
      }}
      style={{ alignItems: 'center', gap: 4, opacity: disabled ? 0.4 : 1, width: 84 }}
    >
      <View style={[styles.round, { backgroundColor: t.card, borderColor: t.line, width: 52, height: 52 }]}>
        <Ionicons name={icon} size={22} color={t.ink} />
      </View>
      <T v="small" center>
        {text}
      </T>
    </Pressable>
  );
}

/** Big microphone button with a ring that pulses with the student's own voice. */
function MicButton({
  muted,
  disabled,
  getMicLevel,
  onPress,
}: {
  muted: boolean;
  disabled?: boolean;
  getMicLevel: () => number;
  onPress: () => void;
}) {
  const t = useTheme();
  const level = useSharedValue(0);
  useEffect(() => {
    const id = setInterval(() => {
      level.value = withTiming(getMicLevel(), { duration: 90 });
    }, 80);
    return () => clearInterval(id);
  }, [getMicLevel]);
  const ring = useAnimatedStyle(() => ({ transform: [{ scale: 1 + level.value * 0.45 }], opacity: 0.25 + level.value * 0.4 }));

  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={muted ? 'להפעיל את המיקרופון' : 'להשתיק את המיקרופון'}
      accessibilityState={{ selected: !muted }}
      disabled={disabled}
      onPress={() => {
        tap();
        onPress();
      }}
      style={{ alignItems: 'center', justifyContent: 'center', width: 96, height: 96, opacity: disabled ? 0.4 : 1 }}
    >
      <Animated.View style={[styles.ring, { backgroundColor: t.mina }, ring]} />
      <View style={[styles.mic, { backgroundColor: muted ? t.bad : t.primary }]}>
        <Ionicons name={muted ? 'mic-off' : 'mic'} size={30} color={muted ? '#FFFFFF' : t.onPrimary} />
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, paddingHorizontal: 16, gap: 10, direction: 'rtl' },
  top: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  round: { width: 44, height: 44, borderRadius: 26, alignItems: 'center', justifyContent: 'center', borderWidth: StyleSheet.hairlineWidth, borderColor: 'transparent' },
  stage: { alignItems: 'center' },
  controls: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-around' },
  ring: { position: 'absolute', width: 76, height: 76, borderRadius: 38 },
  unblock: { flexDirection: 'row', gap: 10, alignItems: 'center', justifyContent: 'center', borderRadius: 999, paddingVertical: 14 },
  mic: { width: 72, height: 72, borderRadius: 36, alignItems: 'center', justifyContent: 'center' },
});
