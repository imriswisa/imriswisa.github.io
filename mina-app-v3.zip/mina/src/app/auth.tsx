import { Redirect, useRouter } from 'expo-router';
import React, { useState } from 'react';
import { KeyboardAvoidingView, Platform, StyleSheet, TextInput, View } from 'react-native';
import { Mina } from '@/components/Mina';
import { Button, Notice, Screen, T } from '@/components/ui';
import { isBackendConfigured } from '@/lib/config';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/store/auth';
import { font, radius, useTheme } from '@/theme';

function explain(message: string): string {
  const m = message.toLowerCase();
  if (m.includes('invalid login')) return 'האימייל או הסיסמה לא נכונים.';
  if (m.includes('already registered')) return 'כבר יש חשבון עם האימייל הזה. נסו להתחבר.';
  if (m.includes('password')) return 'הסיסמה צריכה להיות באורך 6 תווים לפחות.';
  if (m.includes('email not confirmed')) return 'צריך לאשר את האימייל. חפשו את ההודעה ששלחנו.';
  if (m.includes('network') || m.includes('fetch')) return 'אין חיבור לשרת. בדקו את האינטרנט ונסו שוב.';
  if (m.includes('rate limit')) return 'יותר מדי ניסיונות. נסו שוב בעוד כמה דקות.';
  return `משהו השתבש: ${message}`;
}

export default function Auth() {
  const t = useTheme();
  const router = useRouter();
  const session = useAuth((s) => s.session);
  const [mode, setMode] = useState<'in' | 'up'>('up');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);

  if (!isBackendConfigured) return <Redirect href="/setup" />;
  if (session) return <Redirect href="/" />;

  const submit = async () => {
    setError(null);
    setInfo(null);
    const mail = email.trim();
    if (!/^\S+@\S+\.\S+$/.test(mail)) return setError('כתובת האימייל לא נראית תקינה.');
    if (password.length < 6) return setError('הסיסמה צריכה להיות באורך 6 תווים לפחות.');
    setBusy(true);
    try {
      if (mode === 'in') {
        const { error } = await supabase.auth.signInWithPassword({ email: mail, password });
        if (error) return setError(explain(error.message));
      } else {
        const { data, error } = await supabase.auth.signUp({ email: mail, password });
        if (error) return setError(explain(error.message));
        if (!data.session) {
          setMode('in');
          return setInfo('שלחנו אימייל לאישור החשבון. אחרי האישור אפשר להתחבר כאן.');
        }
      }
      await useAuth.getState().loadProfile();
      router.replace('/');
    } catch (e: any) {
      setError(explain(String(e?.message ?? e)));
    } finally {
      setBusy(false);
    }
  };

  const input = [styles.input, { backgroundColor: t.card, borderColor: t.line, color: t.ink }];

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <Screen>
        <View style={{ alignItems: 'center', marginTop: 12 }}>
          <Mina size={190} emotion="happy" />
        </View>
        <T v="title" center>
          היי, אני מינה
        </T>
        <T v="soft" center>
          המורה הפרטית שלך לשפות. מדברים, צוחקים, ולומדים בעשר דקות ביום.
        </T>
        <View style={{ gap: 10, marginTop: 8 }}>
          <TextInput
            accessibilityLabel="אימייל"
            placeholder="אימייל"
            placeholderTextColor={t.inkSoft}
            autoCapitalize="none"
            autoComplete="email"
            keyboardType="email-address"
            value={email}
            onChangeText={setEmail}
            style={[input, { textAlign: 'left', writingDirection: 'ltr' }]}
          />
          <TextInput
            accessibilityLabel="סיסמה"
            placeholder="סיסמה"
            placeholderTextColor={t.inkSoft}
            secureTextEntry
            autoComplete={mode === 'in' ? 'current-password' : 'new-password'}
            value={password}
            onChangeText={setPassword}
            onSubmitEditing={submit}
            style={[input, { textAlign: 'left', writingDirection: 'ltr' }]}
          />
        </View>
        {error ? <Notice tone="bad" text={error} /> : null}
        {info ? <Notice text={info} /> : null}
        <Button title={mode === 'in' ? 'כניסה' : 'יצירת חשבון'} onPress={submit} busy={busy} />
        <Button
          kind="ghost"
          title={mode === 'in' ? 'אין לי חשבון עדיין' : 'כבר יש לי חשבון'}
          onPress={() => {
            setMode(mode === 'in' ? 'up' : 'in');
            setError(null);
          }}
        />
      </Screen>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  input: {
    minHeight: 54,
    borderRadius: radius.md,
    borderWidth: 1,
    paddingHorizontal: 16,
    fontFamily: font.regular,
    fontSize: 17,
  },
});
