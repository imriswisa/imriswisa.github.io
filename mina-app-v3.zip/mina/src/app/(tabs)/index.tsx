import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import Animated, { FadeInDown } from 'react-native-reanimated';
import { Mina } from '@/components/Mina';
import { Button, Card, Notice, Screen, T } from '@/components/ui';
import { nextLesson } from '@/lib/curriculum';
import { minutesToday, streak, weekMinutes } from '@/lib/stats';
import { useLangs } from '@/lib/useLangs';
import { useLearningData } from '@/lib/useLearningData';
import { useAuth } from '@/store/auth';
import { font, radius, useTheme } from '@/theme';

const DAYS = ['א', 'ב', 'ג', 'ד', 'ה', 'ו', 'ש'];

export default function Home() {
  const t = useTheme();
  const router = useRouter();
  const profile = useAuth((s) => s.profile)!;
  const { native, target } = useLangs();
  const { sessions, mistakes, vocabulary, loading, error } = useLearningData();

  const doneIds = sessions.map((s) => s.lesson_id).filter((x): x is string => !!x);
  const lesson = nextLesson(profile.cefr_level, doneIds);
  const week = weekMinutes(sessions);
  const today = minutesToday(sessions);
  const goal = profile.daily_minutes;
  const done = today >= goal;
  const peak = Math.max(goal, ...week);
  const todayIndex = new Date().getDay();
  const repeats = mistakes.filter((m) => m.times_seen > 1).slice(0, 3);
  const progress = Math.min(1, today / goal);

  const steps = ['פתיחה', 'לימוד', 'תרגול', 'סצנה', 'חידון'];

  return (
    <Screen>
      <View style={styles.header}>
        <View style={{ flex: 1, gap: 2 }}>
          <View style={[styles.pill, { backgroundColor: t.card, borderColor: t.line }]}>
            <Text style={{ fontSize: 14 }}>{native.flag}</Text>
            <Ionicons name="arrow-back" size={12} color={t.inkSoft} />
            <Text style={{ fontSize: 14 }}>{target.flag}</Text>
            <Text style={{ fontFamily: font.medium, fontSize: 13, color: t.inkSoft }}>
              {target.he} · {profile.cefr_level}
            </Text>
          </View>
          <T v="title">היי {profile.display_name}</T>
          <T v="soft">{done ? 'עמדת ביעד היומי. כל הכבוד!' : `עוד ${Math.max(1, goal - today)} דקות ליעד של היום`}</T>
        </View>
        <Mina size={96} emotion={done ? 'excited' : 'happy'} />
      </View>

      {error ? <Notice tone="bad" text="לא הצלחנו לטעון את ההתקדמות. בדקו את החיבור." /> : null}

      <Animated.View entering={FadeInDown.duration(400)}>
        <View style={[styles.hero, { backgroundColor: t.lavender }]}>
          <T v="small" style={{ color: t.ink, opacity: 0.7 }}>
            השיעור של היום
          </T>
          <T v="title" style={{ fontSize: 28, lineHeight: 34 }}>
            {lesson.title}
          </T>
          <T style={{ color: t.ink }}>{lesson.goal}</T>
          <View style={styles.steps}>
            {steps.map((s, i) => (
              <View key={s} style={[styles.step, { backgroundColor: t.card }]}>
                <Text style={[styles.stepNum, { color: t.inkSoft }]}>{i + 1}</Text>
                <Text style={[styles.stepText, { color: t.ink }]}>{s}</Text>
              </View>
            ))}
          </View>
          <View style={[styles.track, { backgroundColor: t.card }]}>
            <View style={{ width: `${progress * 100}%`, height: '100%', backgroundColor: t.ink, borderRadius: 4 }} />
          </View>
          <Button
            title="להתחיל את השיעור"
            onPress={() => router.push({ pathname: '/session', params: { mode: 'daily', lessonId: lesson.id, title: lesson.title } })}
          />
        </View>
      </Animated.View>

      <View style={styles.stats}>
        <Stat value={loading ? '·' : String(streak(sessions))} label="ימים ברצף" icon="flame" color={t.peach} />
        <Stat value={loading ? '·' : String(today)} label="דקות היום" icon="time" color={t.mint} />
        <Stat value={loading ? '·' : String(vocabulary.length)} label="מילים" icon="book" color={t.butter} />
      </View>

      <Card>
        <T v="label">השבוע שלך</T>
        <View style={styles.bars} accessible accessibilityLabel={`דקות דיבור בשבעת הימים האחרונים: ${week.join(', ')}`}>
          {week.map((m, i) => {
            const day = (todayIndex - (6 - i) + 7) % 7;
            return (
              <View key={i} style={styles.barCol}>
                <View style={[styles.barTrack, { backgroundColor: t.cardAlt }]}>
                  <View style={{ height: `${Math.max(m > 0 ? 8 : 0, (m / peak) * 100)}%`, backgroundColor: i === 6 ? t.ink : t.mina, borderRadius: 8 }} />
                </View>
                <T v="small" center>
                  {DAYS[day]}
                </T>
              </View>
            );
          })}
        </View>
      </Card>

      {repeats.length > 0 ? (
        <Card>
          <T v="label">מינה עוד זוכרת את אלה…</T>
          {repeats.map((m) => (
            <View key={m.id} style={{ marginTop: 6 }}>
              <T ltr={!target.rtl} style={{ color: t.good }}>
                {m.correct}
              </T>
              <T v="small">חזר {m.times_seen} פעמים</T>
            </View>
          ))}
        </Card>
      ) : null}
    </Screen>
  );
}

function Stat({ value, label, icon, color }: { value: string; label: string; icon: keyof typeof Ionicons.glyphMap; color: string }) {
  const t = useTheme();
  return (
    <View style={[styles.stat, { backgroundColor: color }]}>
      <Ionicons name={icon} size={18} color={t.ink} style={{ opacity: 0.7 }} />
      <T v="title" center style={{ fontSize: 28, lineHeight: 34 }}>
        {value}
      </T>
      <T v="small" center style={{ color: t.ink }}>
        {label}
      </T>
    </View>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  pill: { flexDirection: 'row', alignSelf: 'flex-start', alignItems: 'center', gap: 6, borderWidth: StyleSheet.hairlineWidth, borderRadius: radius.pill, paddingHorizontal: 10, paddingVertical: 4 },
  hero: { borderRadius: radius.lg, padding: 20, gap: 10 },
  steps: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 4 },
  step: { flexDirection: 'row', alignItems: 'center', gap: 5, borderRadius: radius.pill, paddingHorizontal: 10, paddingVertical: 5 },
  stepNum: { fontFamily: font.bold, fontSize: 12 },
  stepText: { fontFamily: font.medium, fontSize: 13 },
  track: { height: 8, borderRadius: 4, overflow: 'hidden', direction: 'ltr', transform: [{ scaleX: -1 }] },
  stats: { flexDirection: 'row', gap: 10 },
  stat: { flex: 1, alignItems: 'center', paddingVertical: 14, borderRadius: radius.lg, gap: 2 },
  bars: { flexDirection: 'row', gap: 8, height: 120, marginTop: 8, direction: 'ltr' },
  barCol: { flex: 1, gap: 6 },
  barTrack: { flex: 1, borderRadius: 8, justifyContent: 'flex-end', overflow: 'hidden' },
});
