import { useRouter } from 'expo-router';
import React, { useState } from 'react';
import { StyleSheet, Text, TextInput, View } from 'react-native';
import { Button, Card, Screen, T } from '@/components/ui';
import { SCENARIOS } from '@/lib/catalog';
import { font, radius, useTheme } from '@/theme';

export default function Practice() {
  const t = useTheme();
  const router = useRouter();
  const [custom, setCustom] = useState('');
  const tints = [t.peach, t.sky, t.butter, t.mint, t.lavender];

  const start = (mode: string, title: string, topic?: string) =>
    router.push({ pathname: '/session', params: { mode, title, ...(topic ? { topic } : {}) } });

  return (
    <Screen>
      <T v="title">תרגול</T>

      <Card color={t.lavender} onPress={() => start('free', 'שיחה חופשית')} label="שיחה חופשית עם מינה">
        <T v="h2">שיחה חופשית</T>
        <T v="soft" style={{ color: t.ink }}>
          מינה בוחרת נושא, מספרת, שואלת ומתקנת בדרך.
        </T>
      </Card>

      <T v="h2" style={{ marginTop: 6 }}>
        משחקי תפקידים
      </T>
      <View style={styles.grid}>
        {SCENARIOS.map((s, i) => (
          <Card
            key={s.id}
            color={tints[i % tints.length]}
            style={styles.tile}
            label={`${s.title}: ${s.goal}`}
            onPress={() => start('roleplay', s.title, s.brief)}
          >
            <Text style={styles.emoji}>{s.emoji}</Text>
            <T v="label">{s.title}</T>
            <T v="small" style={{ color: t.ink }}>
              {s.goal}
            </T>
          </Card>
        ))}
      </View>

      <Card>
        <T v="h2">תרחיש משלך</T>
        <TextInput
          accessibilityLabel="תיאור התרחיש"
          placeholder="למשל: אני מחזיר נעליים פגומות לחנות"
          placeholderTextColor={t.inkSoft}
          value={custom}
          onChangeText={setCustom}
          maxLength={200}
          style={[styles.input, { backgroundColor: t.cardAlt, borderColor: t.line, color: t.ink }]}
        />
        <Button
          title="להתחיל את התרחיש"
          disabled={!custom.trim()}
          onPress={() => start('roleplay', 'תרחיש משלך', `Custom scenario described by the student (in Hebrew): ${custom.trim()}`)}
        />
      </Card>
    </Screen>
  );
}

const styles = StyleSheet.create({
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  tile: { width: '48%', flexGrow: 1, minHeight: 130 },
  emoji: { fontSize: 30 },
  input: {
    minHeight: 52,
    borderRadius: radius.md,
    borderWidth: 1,
    paddingHorizontal: 14,
    fontFamily: font.regular,
    fontSize: 16,
    textAlign: 'right',
    writingDirection: 'rtl',
    marginVertical: 6,
  },
});
