import React, { useState } from 'react';
import { ActivityIndicator, View } from 'react-native';
import { Card, Chip, Notice, Row, Screen, T } from '@/components/ui';
import { useLangs } from '@/lib/useLangs';
import { useLearningData } from '@/lib/useLearningData';
import { useTheme } from '@/theme';

const CATEGORY: Record<string, string> = {
  grammar: 'דקדוק',
  vocabulary: 'אוצר מילים',
  pronunciation: 'הגייה',
  word_order: 'סדר מילים',
  other: 'אחר',
};

export default function Review() {
  const t = useTheme();
  const [tab, setTab] = useState<'mistakes' | 'words'>('mistakes');
  const { mistakes, vocabulary, loading, error } = useLearningData();
  const ltr = !useLangs().target.rtl;

  return (
    <Screen>
      <T v="title">חזרה</T>
      <Row>
        <Chip label={`טעויות (${mistakes.length})`} selected={tab === 'mistakes'} onPress={() => setTab('mistakes')} />
        <Chip label={`מילים (${vocabulary.length})`} selected={tab === 'words'} onPress={() => setTab('words')} />
      </Row>

      {loading ? <ActivityIndicator color={t.ink} style={{ marginTop: 30 }} /> : null}
      {error ? <Notice tone="bad" text="לא הצלחנו לטעון. בדקו את החיבור ונסו שוב." /> : null}

      {!loading && tab === 'mistakes' && mistakes.length === 0 ? (
        <Card>
          <T v="label">עדיין אין כאן כלום</T>
          <T v="soft">כשמינה מתקנת אותך בשיחה, התיקון נשמר כאן והיא חוזרת אליו בשיעורים הבאים.</T>
        </Card>
      ) : null}
      {tab === 'mistakes' &&
        mistakes.map((m) => (
          <Card key={m.id}>
            <View>
              <T ltr={ltr} style={{ color: t.bad, textDecorationLine: 'line-through' }}>
                {m.wrong}
              </T>
              <T ltr={ltr} v="label" style={{ color: t.good }}>
                {m.correct}
              </T>
            </View>
            {m.explanation_he ? <T v="soft">{m.explanation_he}</T> : null}
            <T v="small">
              {CATEGORY[m.category] ?? CATEGORY.other} · {m.times_seen === 1 ? 'פעם אחת' : `${m.times_seen} פעמים`}
            </T>
          </Card>
        ))}

      {!loading && tab === 'words' && vocabulary.length === 0 ? (
        <Card>
          <T v="label">עדיין אין מילים</T>
          <T v="soft">מילים חדשות שלמדת בשיחות עם מינה יישמרו כאן אוטומטית.</T>
        </Card>
      ) : null}
      {tab === 'words' &&
        vocabulary.map((w) => (
          <Card key={w.id}>
            <T ltr={ltr} v="h2">
              {w.word}
            </T>
            <T v="label">{w.translation_he}</T>
            {w.example ? (
              <T ltr={ltr} v="soft">
                {w.example}
              </T>
            ) : null}
          </Card>
        ))}

      <Card color={t.cardAlt}>
        <T v="label">בשלב הבא</T>
        <T v="soft">כרטיסיות עם חזרה מרווחת (FSRS) ושינון בקול. כרגע זו רשימה לקריאה בלבד.</T>
      </Card>
    </Screen>
  );
}
