import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import React, { useState } from 'react';
import { StyleSheet, TextInput, View } from 'react-native';
import { Button, Card, Screen, T } from '@/components/ui';
import { CURRICULUM, lessonsFor } from '@/lib/curriculum';
import { CEFR } from '@/lib/live/tools';
import { useLangs } from '@/lib/useLangs';
import { useLearningData } from '@/lib/useLearningData';
import { useAuth } from '@/store/auth';
import { font, radius, useTheme } from '@/theme';

export default function Learn() {
  const t = useTheme();
  const router = useRouter();
  const level = useAuth((s) => s.profile!.cefr_level);
  const { target } = useLangs();
  const { sessions } = useLearningData();
  const [custom, setCustom] = useState('');
  const done = new Set(sessions.map((s) => s.lesson_id).filter(Boolean));

  const mine = lessonsFor(level);
  const nextLevel = CEFR[CEFR.indexOf(level) + 1];
  const stretch = nextLevel ? CURRICULUM.filter((l) => l.level === nextLevel) : [];

  const start = (mode: string, title: string, extra: Record<string, string> = {}) =>
    router.push({ pathname: '/session', params: { mode, title, ...extra } });

  const LessonRow = ({ id, title, goal }: { id: string; title: string; goal: string }) => (
    <Card onPress={() => start('daily', title, { lessonId: id })} label={title} style={styles.lesson}>
      <View style={[styles.check, { backgroundColor: done.has(id) ? t.good : t.cardAlt }]}>
        <Ionicons name={done.has(id) ? 'checkmark' : 'play'} size={16} color={done.has(id) ? '#FFFFFF' : t.ink} />
      </View>
      <View style={{ flex: 1 }}>
        <T v="label">{title}</T>
        <T v="small">{goal}</T>
      </View>
    </Card>
  );

  return (
    <Screen>
      <T v="title">הקורס שלך</T>
      <T v="soft">
        {target.flag} {target.he} · רמה {level} · {mine.filter((l) => done.has(l.id)).length} מתוך {mine.length} שיעורים
      </T>

      {mine.map((l) => (
        <LessonRow key={l.id} id={l.id} title={l.title} goal={l.goal} />
      ))}

      {stretch.length ? (
        <>
          <T v="h2" style={{ marginTop: 8 }}>
            הצצה לרמה {nextLevel}
          </T>
          {stretch.slice(0, 3).map((l) => (
            <LessonRow key={l.id} id={l.id} title={l.title} goal={l.goal} />
          ))}
        </>
      ) : null}

      <Card color={t.mint} style={{ marginTop: 8 }}>
        <T v="h2">שיעור על נושא משלך</T>
        <T v="soft" style={{ color: t.ink }}>
          כתבו נושא, ומינה תבנה שיעור שלם סביבו.
        </T>
        <TextInput
          accessibilityLabel="נושא לשיעור"
          placeholder="למשל: איך לדבר בחדר כושר"
          placeholderTextColor={t.inkSoft}
          value={custom}
          onChangeText={setCustom}
          maxLength={200}
          style={[styles.input, { backgroundColor: t.card, borderColor: t.line, color: t.ink }]}
        />
        <Button title="לבנות לי שיעור" disabled={!custom.trim()} onPress={() => start('custom', 'שיעור לפי בקשה', { topic: custom.trim() })} />
      </Card>

      <Card onPress={() => start('vocabulary', 'אוצר מילים')} label="אימון אוצר מילים">
        <T v="h2">אוצר מילים</T>
        <T v="soft">שש מילים חדשות סביב תחומי העניין שלך, עם תרגול וחידון.</T>
      </Card>
    </Screen>
  );
}

const styles = StyleSheet.create({
  lesson: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  check: { width: 34, height: 34, borderRadius: 17, alignItems: 'center', justifyContent: 'center' },
  input: {
    minHeight: 52,
    borderRadius: radius.md,
    borderWidth: 1,
    paddingHorizontal: 14,
    fontFamily: font.regular,
    fontSize: 16,
    textAlign: 'right',
    writingDirection: 'rtl',
    marginVertical: 6,
  },
});
