import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import React, { useState } from 'react';
import { StyleSheet, Switch, View } from 'react-native';
import { Mina } from '@/components/Mina';
import { Button, Chip, Notice, Row, Screen, T } from '@/components/ui';
import { LEVELS } from '@/lib/catalog';
import { LANGUAGES, VOICES } from '@/lib/languages';
import { useLangs } from '@/lib/useLangs';
import { useLearningData } from '@/lib/useLearningData';
import { useAuth, type Profile } from '@/store/auth';
import { useSettings } from '@/store/settings';
import { radius, useTheme } from '@/theme';

export default function Settings() {
  const t = useTheme();
  const router = useRouter();
  const profile = useAuth((s) => s.profile)!;
  const email = useAuth((s) => s.session?.user.email);
  const { native, target } = useLangs();
  const themeMode = useSettings((s) => s.themeMode);
  const setThemeMode = useSettings((s) => s.setThemeMode);
  const captions = useSettings((s) => s.captions);
  const setCaptions = useSettings((s) => s.setCaptions);
  const { sessions } = useLearningData();
  const [error, setError] = useState(false);

  const save = async (patch: Partial<Omit<Profile, 'id'>>) => {
    setError(false);
    const err = await useAuth.getState().updateProfile(patch);
    if (err) setError(true);
  };

  const totalSeconds = sessions.reduce((s, x) => s + x.duration_seconds, 0);
  const totalMinutes = totalSeconds > 0 ? Math.max(1, Math.round(totalSeconds / 60)) : 0;

  return (
    <Screen>
      <View style={[styles.head, { backgroundColor: t.lavender }]}>
        <Mina size={72} emotion="happy" />
        <View style={{ flex: 1 }}>
          <T v="h2">{profile.display_name}</T>
          <T v="small" style={{ color: t.ink }}>
            {email}
          </T>
          <T v="small" style={{ color: t.ink }}>
            שיעורים: {sessions.length} · דקות דיבור: {totalMinutes}
          </T>
        </View>
      </View>
      {error ? <Notice tone="bad" text="השינוי לא נשמר. בדקו את החיבור ונסו שוב." /> : null}

      <Section icon="language" title="שפות">
        <T v="small">אני מדבר/ת</T>
        <Row>
          {LANGUAGES.map((l) => (
            <Chip
              key={l.code}
              label={`${l.flag} ${l.he}`}
              selected={native.code === l.code}
              onPress={() => l.code !== target.code && save({ native_language: l.code })}
            />
          ))}
        </Row>
        <T v="small" style={{ marginTop: 8 }}>
          אני לומד/ת
        </T>
        <Row>
          {LANGUAGES.filter((l) => l.code !== native.code).map((l) => (
            <Chip key={l.code} label={`${l.flag} ${l.he}`} selected={target.code === l.code} onPress={() => save({ target_language: l.code })} />
          ))}
        </Row>
        <T v="small">מינה מדברת רק בשתי השפות שבחרת.</T>
      </Section>

      <Section icon="school" title="רמה">
        <Row>
          {LEVELS.map((l) => (
            <Chip key={l.id} label={`${l.id} · ${l.title}`} selected={profile.cefr_level === l.id} onPress={() => save({ cefr_level: l.id })} />
          ))}
        </Row>
        <Button
          kind="ghost"
          title="מבחן רמה בדיבור עם מינה"
          style={{ marginTop: 8 }}
          onPress={() => router.push({ pathname: '/session', params: { mode: 'placement', title: 'מבחן רמה' } })}
        />
      </Section>

      <Section icon="person-circle" title="המורה">
        <T v="small">הקול של מינה</T>
        <Row>
          {VOICES.map((v) => (
            <Chip key={v.id} label={`${v.he} · ${v.hint}`} selected={(profile.mina_voice ?? 'Aoede') === v.id} onPress={() => save({ mina_voice: v.id })} />
          ))}
        </Row>
        <T v="small" style={{ marginTop: 8 }}>
          מהירות דיבור
        </T>
        <Row>
          <Chip label="לאט" selected={profile.speech_speed === 'slow'} onPress={() => save({ speech_speed: 'slow' })} />
          <Chip label="רגיל" selected={profile.speech_speed === 'normal'} onPress={() => save({ speech_speed: 'normal' })} />
          <Chip label="מהיר" selected={profile.speech_speed === 'fast'} onPress={() => save({ speech_speed: 'fast' })} />
        </Row>
        <T v="small" style={{ marginTop: 8 }}>
          כמה {native.he} מינה מדברת
        </T>
        <Row>
          <Chip label="מעט" selected={profile.hebrew_usage === 'low'} onPress={() => save({ hebrew_usage: 'low' })} />
          <Chip label="בינוני" selected={profile.hebrew_usage === 'medium'} onPress={() => save({ hebrew_usage: 'medium' })} />
          <Chip label="הרבה" selected={profile.hebrew_usage === 'high'} onPress={() => save({ hebrew_usage: 'high' })} />
        </Row>
        <T v="small" style={{ marginTop: 8 }}>
          תיקון טעויות
        </T>
        <Row>
          <Chip label="עדין" selected={profile.correction_style === 'gentle'} onPress={() => save({ correction_style: 'gentle' })} />
          <Chip label="רגיל" selected={(profile.correction_style ?? 'normal') === 'normal'} onPress={() => save({ correction_style: 'normal' })} />
          <Chip label="קפדני" selected={profile.correction_style === 'strict'} onPress={() => save({ correction_style: 'strict' })} />
        </Row>
      </Section>

      <Section icon="calendar" title="יעד יומי">
        <Row>
          {[5, 10, 15, 20, 30].map((m) => (
            <Chip key={m} label={`${m} דק׳`} selected={profile.daily_minutes === m} onPress={() => save({ daily_minutes: m })} />
          ))}
        </Row>
      </Section>

      <Section icon="color-palette" title="תצוגה">
        <Row>
          <Chip label="לפי המכשיר" selected={themeMode === 'system'} onPress={() => setThemeMode('system')} />
          <Chip label="בהיר" selected={themeMode === 'light'} onPress={() => setThemeMode('light')} />
          <Chip label="כהה" selected={themeMode === 'dark'} onPress={() => setThemeMode('dark')} />
        </Row>
        <View style={styles.switchRow}>
          <T v="label" style={{ flex: 1 }}>
            כתוביות בזמן השיעור
          </T>
          <Switch value={captions} onValueChange={setCaptions} trackColor={{ true: t.mina, false: t.line }} thumbColor={t.card} />
        </View>
      </Section>

      <Button
        kind="ghost"
        title="התנתקות"
        onPress={async () => {
          await useAuth.getState().signOut();
          router.replace('/');
        }}
      />
    </Screen>
  );
}

function Section({ icon, title, children }: { icon: keyof typeof Ionicons.glyphMap; title: string; children: React.ReactNode }) {
  const t = useTheme();
  return (
    <View style={[styles.section, { backgroundColor: t.card, borderColor: t.line }]}>
      <View style={styles.sectionHead}>
        <View style={[styles.icon, { backgroundColor: t.cardAlt }]}>
          <Ionicons name={icon} size={18} color={t.ink} />
        </View>
        <T v="h2">{title}</T>
      </View>
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  head: { flexDirection: 'row', alignItems: 'center', gap: 14, borderRadius: radius.lg, padding: 16 },
  section: { borderRadius: radius.lg, borderWidth: StyleSheet.hairlineWidth, padding: 16, gap: 8 },
  sectionHead: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 4 },
  icon: { width: 34, height: 34, borderRadius: 17, alignItems: 'center', justifyContent: 'center' },
  switchRow: { flexDirection: 'row', alignItems: 'center', marginTop: 8 },
});
