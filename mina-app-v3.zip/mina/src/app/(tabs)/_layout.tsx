import { Ionicons } from '@expo/vector-icons';
import { Redirect, Tabs } from 'expo-router';
import React from 'react';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '@/store/auth';
import { font, useTheme } from '@/theme';

const TABS: { name: string; title: string; icon: keyof typeof Ionicons.glyphMap }[] = [
  { name: 'index', title: 'בית', icon: 'home' },
  { name: 'learn', title: 'קורס', icon: 'school' },
  { name: 'practice', title: 'תרגול', icon: 'chatbubbles' },
  { name: 'review', title: 'חזרה', icon: 'albums' },
  { name: 'profile', title: 'הגדרות', icon: 'settings' },
];

export default function TabsLayout() {
  const t = useTheme();
  const insets = useSafeAreaInsets();
  const session = useAuth((s) => s.session);
  const onboarded = useAuth((s) => s.profile?.onboarded);
  if (!session || !onboarded) return <Redirect href="/" />;

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: t.ink,
        tabBarInactiveTintColor: t.inkSoft,
        tabBarLabelStyle: { fontFamily: font.medium, fontSize: 12, lineHeight: 16 },
        tabBarStyle: {
          backgroundColor: t.bg,
          borderTopColor: t.line,
          direction: 'rtl',
          height: 74 + insets.bottom,
          paddingTop: 6,
          paddingBottom: 16 + insets.bottom,
        },
        sceneStyle: { backgroundColor: t.bg },
      }}
    >
      {TABS.map((tab) => (
        <Tabs.Screen
          key={tab.name}
          name={tab.name}
          options={{
            title: tab.title,
            tabBarIcon: ({ color, focused }) => (
              <Ionicons name={focused ? tab.icon : (`${tab.icon}-outline` as keyof typeof Ionicons.glyphMap)} size={23} color={color as string} />
            ),
          }}
        />
      ))}
    </Tabs>
  );
}
