import { Redirect, useRouter } from 'expo-router';
import React, { useState } from 'react';
import { Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import Animated, { FadeInDown } from 'react-native-reanimated';
import { Mina } from '@/components/Mina';
import { Button, Card, Chip, Notice, Row, Screen, T, tap } from '@/components/ui';
import { GOALS, INTERESTS, LEVELS } from '@/lib/catalog';
import { LANGUAGES, VOICES, lang } from '@/lib/languages';
import type { Cefr, Emotion } from '@/lib/live/tools';
import { useAuth, type Profile } from '@/store/auth';
import { font, radius, useTheme } from '@/theme';

const STEPS = ['welcome', 'languages', 'name', 'level', 'interests', 'goal', 'style'] as const;
const FACES: Emotion[] = ['excited', 'happy', 'happy', 'encouraging', 'excited', 'surprised', 'happy'];

export default function Onboarding() {
  const t = useTheme();
  const router = useRouter();
  const session = useAuth((s) => s.session);
  const [step, setStep] = useState(0);
  const [native, setNative] = useState('he');
  const [target, setTarget] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [level, setLevel] = useState<Cefr | 'test' | null>(null);
  const [interests, setInterests] = useState<string[]>([]);
  const [goal, setGoal] = useState<string | null>(null);
  const [minutes, setMinutes] = useState(10);
  const [nativeUse, setNativeUse] = useState<Profile['hebrew_usage']>('medium');
  const [voice, setVoice] = useState<string>('Aoede');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!session) return <Redirect href="/" />;

  const targetName = target ? lang(target).he : 'השפה';
  const nativeName = lang(native).he;
  const canNext = [true, !!target && target !== native, name.trim().length > 0, level !== null, interests.length > 0, goal !== null, true][step];

  const finish = async () => {
    setBusy(true);
    setError(null);
    const err = await useAuth.getState().updateProfile({
      display_name: name.trim(),
      native_language: native,
      target_language: target!,
      cefr_level: level === 'test' || level === null ? 'A1' : level,
      interests,
      goal,
      daily_minutes: minutes,
      hebrew_usage: nativeUse,
      mina_voice: voice,
      onboarded: true,
    });
    setBusy(false);
    if (err) return setError('לא הצלחנו לשמור. בדקו את החיבור ונסו שוב.');
    router.replace('/(tabs)');
    if (level === 'test') router.push({ pathname: '/session', params: { mode: 'placement', title: 'מבחן רמה' } });
  };

  const toggle = (i: string) => setInterests((cur) => (cur.includes(i) ? cur.filter((x) => x !== i) : [...cur, i]));

  return (
    <Screen>
      {step > 0 ? (
        <View style={styles.dots}>
          {STEPS.slice(1).map((s, i) => (
            <View key={s} style={[styles.dot, { backgroundColor: i < step ? t.ink : t.line }]} />
          ))}
        </View>
      ) : null}

      <View style={{ alignItems: 'center' }}>
        <Mina size={step === 0 ? 200 : 120} emotion={FACES[step]} />
      </View>

      <Animated.View key={step} entering={FadeInDown.duration(320)} style={{ gap: 14 }}>
        {step === 0 && (
          <>
            <T v="title" center>
              ברוכים הבאים למינה
            </T>
            <T v="soft" center>
              מורה פרטית עם בינה מלאכותית שמלמדת אותך שפה בשיחה אמיתית, בקול.
            </T>
            <Feature emoji="🎙️" title="מדברים, לא מקלידים" text="מינה שומעת, עונה בקול ואפשר לקטוע אותה כמו בשיחה רגילה." />
            <Feature emoji="📋" title="שיעור מוכן בכל יום" text="קורס מסודר לפי הרמה שלך. מינה מגיעה עם תוכנית ומובילה." />
            <Feature emoji="🧠" title="זוכרת את הטעויות שלך" text="כל תיקון נשמר, ומינה חוזרת עליו בשיעורים הבאים." />
            <Feature emoji="✍️" title="לוח חי" text="מילים, כללים ותרגילים מופיעים על הלוח בזמן שהיא מסבירה." />
          </>
        )}

        {step === 1 && (
          <>
            <T v="title">איזו שפה לומדים?</T>
            <T v="h2">אני מדבר/ת</T>
            <Row>
              {LANGUAGES.map((l) => (
                <Chip key={l.code} label={`${l.flag} ${l.he}`} selected={native === l.code} onPress={() => { setNative(l.code); if (target === l.code) setTarget(null); }} />
              ))}
            </Row>
            <T v="h2" style={{ marginTop: 6 }}>
              ורוצה ללמוד
            </T>
            <View style={styles.langGrid}>
              {LANGUAGES.filter((l) => l.code !== native).map((l) => (
                <Pressable
                  key={l.code}
                  accessibilityRole="button"
                  accessibilityState={{ selected: target === l.code }}
                  onPress={() => { tap(); setTarget(l.code); }}
                  style={[styles.langTile, { backgroundColor: target === l.code ? t.lavender : t.card, borderColor: target === l.code ? t.ink : t.line }]}
                >
                  <Text style={styles.flag}>{l.flag}</Text>
                  <T v="label" center>{l.he}</T>
                  <T v="small" center>{l.native}</T>
                </Pressable>
              ))}
            </View>
            <T v="soft">מינה תדבר איתך רק בשתי השפות האלה.</T>
          </>
        )}

        {step === 2 && (
          <>
            <T v="title">איך קוראים לך?</T>
            <TextInput
              accessibilityLabel="השם שלך"
              placeholder="השם שלך"
              placeholderTextColor={t.inkSoft}
              value={name}
              onChangeText={setName}
              maxLength={40}
              style={[styles.input, { backgroundColor: t.card, borderColor: t.line, color: t.ink }]}
            />
          </>
        )}

        {step === 3 && (
          <>
            <T v="title">מה הרמה שלך ב{targetName}?</T>
            {LEVELS.map((l) => (
              <Card key={l.id} onPress={() => setLevel(l.id)} color={level === l.id ? t.lavender : undefined} label={l.title}>
                <T v="label">{l.title} · {l.id}</T>
                <T v="soft">{l.hint}</T>
              </Card>
            ))}
            <Card onPress={() => setLevel('test')} color={level === 'test' ? t.mint : undefined} label="מבחן רמה בדיבור">
              <T v="label">לא בטוח/ה? מינה תבדוק</T>
              <T v="soft">שיחה קצרה של כשלוש דקות, ומינה קובעת את הרמה.</T>
            </Card>
          </>
        )}

        {step === 4 && (
          <>
            <T v="title">על מה כיף לך לדבר?</T>
            <T v="soft">מינה תבנה את הדוגמאות בשיעורים סביב זה.</T>
            <Row>
              {INTERESTS.map((i) => (
                <Chip key={i} label={i} selected={interests.includes(i)} onPress={() => toggle(i)} />
              ))}
            </Row>
          </>
        )}

        {step === 5 && (
          <>
            <T v="title">בשביל מה ה{targetName}?</T>
            <Row>
              {GOALS.map((g) => (
                <Chip key={g} label={g} selected={goal === g} onPress={() => setGoal(g)} />
              ))}
            </Row>
          </>
        )}

        {step === 6 && (
          <>
            <T v="title">עוד כמה העדפות</T>
            <T v="h2">כמה זמן ביום?</T>
            <Row>
              {[5, 10, 15, 20, 30].map((m) => (
                <Chip key={m} label={`${m} דק׳`} selected={minutes === m} onPress={() => setMinutes(m)} />
              ))}
            </Row>
            <T v="h2">כמה {nativeName} מינה תדבר?</T>
            <Row>
              <Chip label="מעט" selected={nativeUse === 'low'} onPress={() => setNativeUse('low')} />
              <Chip label="בינוני" selected={nativeUse === 'medium'} onPress={() => setNativeUse('medium')} />
              <Chip label="הרבה" selected={nativeUse === 'high'} onPress={() => setNativeUse('high')} />
            </Row>
            <T v="h2">הקול של מינה</T>
            <Row>
              {VOICES.map((v) => (
                <Chip key={v.id} label={`${v.he} · ${v.hint}`} selected={voice === v.id} onPress={() => setVoice(v.id)} />
              ))}
            </Row>
          </>
        )}
      </Animated.View>

      {error ? <Notice tone="bad" text={error} /> : null}
      <View style={{ flex: 1 }} />
      <Button
        title={step === 0 ? 'בואו נתחיל' : step === STEPS.length - 1 ? 'יאללה, לשיעור הראשון' : 'המשך'}
        disabled={!canNext}
        busy={busy}
        onPress={() => (step === STEPS.length - 1 ? finish() : setStep(step + 1))}
      />
      {step > 0 ? <Button kind="ghost" title="חזרה" onPress={() => setStep(step - 1)} /> : null}
    </Screen>
  );
}

function Feature({ emoji, title, text }: { emoji: string; title: string; text: string }) {
  const t = useTheme();
  return (
    <View style={[styles.feature, { backgroundColor: t.card, borderColor: t.line }]}>
      <Text style={styles.featureEmoji}>{emoji}</Text>
      <View style={{ flex: 1 }}>
        <T v="label">{title}</T>
        <T v="soft">{text}</T>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  dots: { flexDirection: 'row', gap: 6, justifyContent: 'center' },
  dot: { flex: 1, maxWidth: 40, height: 4, borderRadius: 2 },
  input: {
    minHeight: 56,
    borderRadius: radius.md,
    borderWidth: 1,
    paddingHorizontal: 16,
    fontFamily: font.medium,
    fontSize: 19,
    textAlign: 'right',
    writingDirection: 'rtl',
  },
  langGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  langTile: { width: '31%', flexGrow: 1, borderRadius: radius.md, borderWidth: 1.5, paddingVertical: 14, alignItems: 'center', gap: 2 },
  flag: { fontSize: 30 },
  feature: { flexDirection: 'row', gap: 14, alignItems: 'center', borderRadius: radius.md, borderWidth: StyleSheet.hairlineWidth, padding: 14 },
  featureEmoji: { fontSize: 28 },
});
