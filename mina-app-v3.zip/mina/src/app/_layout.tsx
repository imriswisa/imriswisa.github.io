import { Heebo_400Regular, Heebo_500Medium, Heebo_700Bold, Heebo_800ExtraBold, useFonts } from '@expo-google-fonts/heebo';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import React, { useEffect } from 'react';
import { ActivityIndicator, View } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { installAudioUnlock } from '@/lib/audio/engine';
import { useAuth } from '@/store/auth';
import { useSettings } from '@/store/settings';
import { useTheme } from '@/theme';

export default function RootLayout() {
  const t = useTheme();
  const [fontsLoaded, fontError] = useFonts({ Heebo_400Regular, Heebo_500Medium, Heebo_700Bold, Heebo_800ExtraBold });
  const ready = useAuth((s) => s.ready);

  useEffect(() => {
    installAudioUnlock();
    void useSettings.getState().load();
    useAuth.getState().init();
  }, []);

  if ((!fontsLoaded && !fontError) || !ready) {
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: t.bg }}>
        <ActivityIndicator color={t.ink} />
      </View>
    );
  }

  return (
    <SafeAreaProvider>
      <StatusBar style={t.dark ? 'light' : 'dark'} />
      <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: t.bg }, animation: 'fade' }}>
        <Stack.Screen name="session" options={{ animation: 'slide_from_bottom', gestureEnabled: false }} />
      </Stack>
    </SafeAreaProvider>
  );
}
