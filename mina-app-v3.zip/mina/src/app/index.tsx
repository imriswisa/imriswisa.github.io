import { Redirect } from 'expo-router';
import React from 'react';
import { isBackendConfigured } from '@/lib/config';
import { useAuth } from '@/store/auth';

/** Decides where the app opens: setup help, sign-in, onboarding, or home. */
export default function Gate() {
  const session = useAuth((s) => s.session);
  const profile = useAuth((s) => s.profile);
  if (!isBackendConfigured) return <Redirect href="/setup" />;
  if (!session) return <Redirect href="/auth" />;
  if (!profile?.onboarded) return <Redirect href="/onboarding" />;
  return <Redirect href="/(tabs)" />;
}
