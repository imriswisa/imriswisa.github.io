import { useColorScheme } from 'react-native';
import { useSettings } from './store/settings';

const light = {
  dark: false,
  bg: '#FAF7F2',
  card: '#FFFFFF',
  cardAlt: '#F3EEE6',
  ink: '#1F1D1A',
  inkSoft: '#6F6A62',
  line: '#E9E3D9',
  primary: '#1F1D1A',
  onPrimary: '#FAF7F2',
  lavender: '#DDD6F7',
  peach: '#FFD9C7',
  mint: '#CFEBDD',
  butter: '#FBE8A6',
  sky: '#CFE6F7',
  good: '#2E8B62',
  bad: '#C8553D',
  marker: '#FFF1A8',
  board: '#FFFDF8',
  mina: '#B9A8F5',
  minaInk: '#2A2440',
};

const dark: typeof light = {
  dark: true,
  bg: '#141312',
  card: '#1F1D1B',
  cardAlt: '#292623',
  ink: '#F4F0EA',
  inkSoft: '#A39D93',
  line: '#34302C',
  primary: '#F4F0EA',
  onPrimary: '#141312',
  lavender: '#3B3560',
  peach: '#5A3A2E',
  mint: '#27473A',
  butter: '#5A4C1E',
  sky: '#263F52',
  good: '#6FCF9F',
  bad: '#F08A73',
  marker: '#6B5A12',
  board: '#1B1A18',
  mina: '#A999EE',
  minaInk: '#1D1930',
};

export type Theme = typeof light;

export function useTheme(): Theme {
  const system = useColorScheme();
  const mode = useSettings((s) => s.themeMode);
  const isDark = mode === 'system' ? system === 'dark' : mode === 'dark';
  return isDark ? dark : light;
}

export const font = {
  regular: 'Heebo_400Regular',
  medium: 'Heebo_500Medium',
  bold: 'Heebo_700Bold',
  black: 'Heebo_800ExtraBold',
};

export const radius = { sm: 12, md: 18, lg: 26, pill: 999 };
