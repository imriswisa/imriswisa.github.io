import { useCallback, useEffect, useRef, useState } from 'react';
import { createAudioEngine } from '../audio/engine';
import { AudioEngine, AudioUnavailableError, MicPermissionError } from '../audio/types';
import { supabase } from '../supabase';
import { useAuth } from '../../store/auth';
import { useBoard } from '../../store/board';
import { GeminiLiveClient, LiveFailure, LiveToolCall } from './GeminiLiveClient';
import { buildToolDeclarations, Emotion, parseBlocks, parseCefr, parseEmotion } from './tools';
import type { TalkState } from '../../components/Mina';
import type { LessonPlan } from '../curriculum';
import { scopeFromText, type QuotaInfo, type QuotaScope } from '../quota';

export type LessonPhase = 'preparing' | 'live' | 'reconnecting' | 'ended' | 'error';

export type LessonError =
  | 'mic-denied'
  | 'audio-unavailable'
  | 'offline'
  | 'not-deployed'
  | 'missing-key'
  | 'key-rejected'
  | 'quota'
  | 'service'
  | 'expired'
  | 'unauthorized';

export interface SavedMistake {
  wrong: string;
  correct: string;
  explanation?: string;
  times: number;
}
export interface SavedWord {
  word: string;
  translation: string;
}
interface Turn {
  who: 'student' | 'mina';
  text: string;
}

export interface LessonResult {
  seconds: number;
  mistakes: SavedMistake[];
  words: SavedWord[];
  newLevel: string | null;
  /** false when the lesson could not be written to the database. */
  saved: boolean;
}

async function tokenErrorToLessonError(error: any): Promise<{ error: LessonError; quota?: QuotaInfo }> {
  const status: number | undefined = error?.context?.status;
  if (status === undefined) return { error: 'offline' };
  if (status === 404) return { error: 'not-deployed' };
  if (status === 401) return { error: 'unauthorized' };
  let body: any = {};
  try {
    body = (await error.context.json()) ?? {};
  } catch {}
  const code = body.error ?? '';
  if (code === 'missing_gemini_key') return { error: 'missing-key' };
  if (code === 'gemini_key_rejected') return { error: 'key-rejected' };
  if (code === 'gemini_quota' || status === 429) {
    const scope: QuotaScope = body.scope === 'minute' || body.scope === 'day' ? body.scope : 'unknown';
    const retryAfterSec = typeof body.retryAfterSec === 'number' ? body.retryAfterSec : null;
    return { error: 'quota', quota: { scope, retryAfterSec, at: Date.now() } };
  }
  return { error: 'service' };
}

function failureToLessonError(f: LiveFailure): { error: LessonError; quota?: QuotaInfo } {
  if (f.kind === 'network') return { error: 'offline' };
  if (f.kind === 'expired') return { error: 'expired' };
  if (/quota|exhaust|rate limit/i.test(f.detail)) {
    return { error: 'quota', quota: { scope: scopeFromText(f.detail), retryAfterSec: null, at: Date.now() } };
  }
  return { error: 'service' };
}

/**
 * Runs one live lesson: microphone -> Gemini Live -> speaker, plus everything Mina
 * does through tools (her face, the whiteboard, saving mistakes and vocabulary).
 */
export function useLiveLesson(mode: string, topic: string | undefined, plan?: LessonPlan) {
  const [phase, setPhase] = useState<LessonPhase>('preparing');
  const [error, setError] = useState<LessonError | null>(null);
  const [emotion, setEmotion] = useState<Emotion>('neutral');
  const [talk, setTalk] = useState<TalkState>('idle');
  const [caption, setCaption] = useState('');
  const [muted, setMutedState] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const [result, setResult] = useState<LessonResult | null>(null);
  const [attempt, setAttempt] = useState(0);
  const [audioBlocked, setAudioBlocked] = useState(false);
  const [quota, setQuota] = useState<QuotaInfo | null>(null);

  const engine = useRef<AudioEngine | null>(null);
  const client = useRef<GeminiLiveClient | null>(null);
  const startedAt = useRef<number | null>(null);
  const turns = useRef<Turn[]>([]);
  const mistakes = useRef<SavedMistake[]>([]);
  const words = useRef<SavedWord[]>([]);
  const newLevel = useRef<string | null>(null);
  const lastUserAt = useRef(0);
  const awaitingReply = useRef(false);
  const finished = useRef(false);
  const emotionTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const addText = (who: Turn['who'], text: string) => {
    const last = turns.current[turns.current.length - 1];
    if (last && last.who === who) last.text += text;
    else turns.current.push({ who, text });
  };

  const handleTool = async (call: LiveToolCall): Promise<Record<string, unknown>> => {
    const a = call.args;
    switch (call.name) {
      case 'set_expression': {
        const e = parseEmotion(a.emotion);
        if (!e) return { ok: false, error: 'unknown emotion' };
        setEmotion(e);
        if (emotionTimer.current) clearTimeout(emotionTimer.current);
        // Strong expressions relax back to neutral if she doesn't set a new one.
        emotionTimer.current = setTimeout(() => setEmotion('neutral'), 9000);
        return { ok: true };
      }
      case 'whiteboard_show': {
        const blocks = parseBlocks(a.blocks);
        if (!blocks.length) return { ok: false, error: 'no valid blocks' };
        useBoard.getState().show(blocks, {
          title: typeof a.title === 'string' ? a.title.slice(0, 80) : undefined,
          append: a.append === true,
        });
        return { ok: true, shown: blocks.length };
      }
      case 'whiteboard_reveal':
        return { ok: true, revealed: useBoard.getState().reveal() };
      case 'whiteboard_clear':
        useBoard.getState().clear();
        return { ok: true };
      case 'save_mistake': {
        const wrong = String(a.wrong ?? '').trim();
        const correct = String(a.correct ?? '').trim();
        if (!wrong || !correct) return { saved: false, error: 'wrong and correct are required' };
        const explanation = typeof a.explanation_he === 'string' ? a.explanation_he : undefined;
        const { data, error } = await supabase.rpc('log_mistake', {
          p_wrong: wrong,
          p_correct: correct,
          p_explanation_he: explanation ?? null,
          p_category: String(a.category ?? 'other'),
        });
        if (error) return { saved: false, error: 'database unavailable' };
        const times = typeof data === 'number' ? data : 1;
        mistakes.current.push({ wrong, correct, explanation, times });
        return { saved: true, times_seen: times, repeated: times > 1 };
      }
      case 'save_vocabulary': {
        const word = String(a.word ?? '').trim().slice(0, 80);
        const translation = String(a.translation_he ?? '').trim().slice(0, 120);
        const userId = useAuth.getState().session?.user.id;
        if (!word || !translation || !userId) return { saved: false, error: 'word and translation_he are required' };
        const { error } = await supabase.from('vocabulary').insert({
          user_id: userId,
          word,
          translation_he: translation,
          example: typeof a.example === 'string' ? a.example.slice(0, 300) : null,
        });
        if (error && error.code !== '23505') return { saved: false, error: 'database unavailable' };
        if (!error) words.current.push({ word, translation });
        return { saved: true, already_known: !!error };
      }
      case 'set_level': {
        const cefr = parseCefr(a.cefr);
        if (!cefr) return { ok: false, error: 'invalid level' };
        const err = await useAuth.getState().updateProfile({ cefr_level: cefr });
        if (err) return { ok: false, error: 'database unavailable' };
        newLevel.current = cefr;
        return { ok: true };
      }
      default:
        return { ok: false, error: `unknown tool ${call.name}` };
    }
  };

  const teardown = useCallback(async () => {
    client.current?.close();
    client.current = null;
    if (emotionTimer.current) clearTimeout(emotionTimer.current);
    const e = engine.current;
    engine.current = null;
    if (e) await e.stop().catch(() => {});
  }, []);

  /** End the lesson, save it, and produce the summary. */
  const finish = useCallback(async () => {
    if (finished.current) return;
    finished.current = true;
    const secs = startedAt.current ? Math.round((Date.now() - startedAt.current) / 1000) : 0;
    await teardown();
    let saved = true;
    const userId = useAuth.getState().session?.user.id;
    // Lessons that never really started (a few seconds) are not worth recording.
    if (userId && secs >= 20) {
      const { error } = await supabase.from('lesson_sessions').insert({
        user_id: userId,
        mode,
        topic: plan?.title ?? topic ?? null,
        lesson_id: plan?.id ?? null,
        started_at: new Date(startedAt.current!).toISOString(),
        duration_seconds: secs,
        mistakes_count: mistakes.current.length,
        vocabulary_count: words.current.length,
        transcript: turns.current.slice(-80).map((t) => ({ who: t.who, text: t.text.slice(0, 1000) })),
      });
      saved = !error;
    }
    setResult({ seconds: secs, mistakes: mistakes.current, words: words.current, newLevel: newLevel.current, saved });
    setPhase('ended');
  }, [mode, topic, teardown]);

  const fail = useCallback(
    async (e: LessonError, q?: QuotaInfo) => {
      setQuota(q ?? null);
      // If a real lesson was already under way, keep what was learned and show the
      // summary (with a note) instead of throwing the student onto an error page.
      if (startedAt.current && Date.now() - startedAt.current > 20000) {
        setError(e);
        await finish();
        return;
      }
      await teardown();
      setError(e);
      setPhase('error');
    },
    [finish, teardown],
  );

  useEffect(() => {
    let cancelled = false;
    finished.current = false;
    startedAt.current = null;
    turns.current = [];
    mistakes.current = [];
    words.current = [];
    newLevel.current = null;
    useBoard.getState().clear();
    setPhase('preparing');
    setError(null);
    setQuota(null);
    setResult(null);
    setSeconds(0);

    (async () => {
      // 1. Microphone first: the permission prompt can take a while, and the token
      //    we fetch next is only valid for a short time.
      const eng = createAudioEngine();
      engine.current = eng;
      try {
        await eng.start((pcm) => client.current?.sendAudio(pcm));
      } catch (e) {
        if (cancelled) return;
        return fail(e instanceof MicPermissionError ? 'mic-denied' : 'audio-unavailable');
      }
      if (cancelled) return void eng.stop();

      // 2. Ask our backend for a one-time token and Mina's instructions.
      const { data, error: fnError } = await supabase.functions.invoke('live-token', {
        body: {
          mode,
          topic,
          tools: buildToolDeclarations({ placement: mode === 'placement' }),
          plan: plan
            ? { title: plan.title, goal: plan.goal, topic: plan.topic, warmup: plan.warmup, teach: plan.teach, practice: plan.practice, scene: plan.scene }
            : undefined,
        },
      });
      if (cancelled) return;
      if (fnError || !data?.token) {
        const r = fnError ? await tokenErrorToLessonError(fnError) : { error: 'service' as LessonError };
        return fail(r.error, r.quota);
      }

      // 3. Open the live conversation.
      const c = new GeminiLiveClient(
        data.token,
        {
          model: data.model,
          voice: data.voice,
          systemInstruction: data.systemInstruction,
          tools: buildToolDeclarations({ placement: !!data.placement }),
        },
        {
          onReady() {
            if (!startedAt.current) {
              startedAt.current = Date.now();
              // The model waits for input; this nudge makes Mina open the lesson herself.
              c.sendText('(The student is ready. Start the lesson now: greet them and begin step 1 of your plan.)');
            }
            setPhase('live');
          },
          onAudio(pcm) {
            awaitingReply.current = false;
            engine.current?.play(pcm);
          },
          onInterrupted() {
            engine.current?.flush();
          },
          onTurnComplete() {
            awaitingReply.current = false;
          },
          onUserText(text) {
            lastUserAt.current = Date.now();
            awaitingReply.current = true;
            addText('student', text);
          },
          onTeacherText(text) {
            addText('mina', text);
            const last = turns.current[turns.current.length - 1];
            setCaption(last.text.slice(-160));
          },
          onToolCalls(calls) {
            void Promise.all(
              calls.map(async (call) => ({
                id: call.id,
                name: call.name,
                result: await handleTool(call).catch(() => ({ ok: false, error: 'internal error' })),
              })),
            ).then((results) => client.current?.respondToTools(results));
          },
          onReconnecting() {
            engine.current?.flush();
            setPhase('reconnecting');
          },
          onFatal(reason) {
            const r = failureToLessonError(reason);
            void fail(r.error, r.quota);
          },
        },
      );
      client.current = c;
      c.connect();
    })();

    return () => {
      cancelled = true;
      void teardown();
    };
  }, [attempt]);

  // Clock + conversation state for the character.
  useEffect(() => {
    if (phase !== 'live') {
      setTalk('idle');
      return;
    }
    const id = setInterval(() => {
      if (startedAt.current) setSeconds(Math.round((Date.now() - startedAt.current) / 1000));
      const now = Date.now();
      const sinceUser = now - lastUserAt.current;
      setAudioBlocked(!!engine.current?.isBlocked?.());
      if (engine.current?.isPlaying()) setTalk('speaking');
      else if (awaitingReply.current && sinceUser > 700 && sinceUser < 8000) setTalk('thinking');
      else setTalk('listening');
    }, 150);
    return () => clearInterval(id);
  }, [phase]);

  const getLevel = useCallback(() => engine.current?.outputLevel() ?? 0, []);
  const getMicLevel = useCallback(() => engine.current?.inputLevel() ?? 0, []);

  return {
    phase,
    error,
    emotion,
    talk,
    caption,
    muted,
    seconds,
    result,
    getLevel,
    getMicLevel,
    setMuted(m: boolean) {
      engine.current?.setMuted(m);
      setMutedState(m);
    },
    /** Tap-to-ask shortcut: have Mina explain her last point in the student's language. */
    askForHebrew() {
      client.current?.sendText('(The student tapped the "explain in my language" button. Explain your last point briefly in the student\'s native language, then continue the lesson.)');
    },
    audioBlocked,
    quota,
    /** Call from a tap: lets iPhone Safari start Mina's audio. */
    unblockAudio() {
      void engine.current?.unblock?.();
      setAudioBlocked(false);
    },
    finish,
    retry: () => setAttempt((n) => n + 1),
  };
}
