import { LIVE_WS_URL, MIC_SAMPLE_RATE } from '../config';
import { base64ToBytes, bytesToBase64, bytesToInt16, int16ToBytes, utf8Decode } from '../audio/pcm';

export interface LiveToolCall {
  id: string;
  name: string;
  args: Record<string, unknown>;
}

export interface LiveCallbacks {
  onReady(): void;
  onAudio(pcm24k: Int16Array): void;
  /** The student started talking over the teacher - stop playback immediately. */
  onInterrupted(): void;
  onTurnComplete(): void;
  onUserText(text: string): void;
  onTeacherText(text: string): void;
  onToolCalls(calls: LiveToolCall[]): void;
  onReconnecting(attempt: number): void;
  /** Terminal failure: the session is over and will not retry. */
  onFatal(reason: LiveFailure): void;
}

export type LiveFailure =
  | { kind: 'network' }
  | { kind: 'rejected'; code: number; detail: string }
  | { kind: 'expired' };

export interface LiveSetup {
  model: string;
  voice: string;
  systemInstruction: string;
  tools: unknown[];
}

const MAX_RECONNECTS = 3;

/**
 * Thin client for the Gemini Live API over a raw WebSocket, authenticated with a
 * short-lived ephemeral token. It survives network drops by resuming the same
 * server-side session (the server sends resumption handles as the call goes on).
 */
export class GeminiLiveClient {
  private ws: WebSocket | null = null;
  private ready = false;
  private closedByUs = false;
  private resumeHandle: string | null = null;
  private reconnects = 0;
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;

  constructor(
    private readonly token: string,
    private readonly setup: LiveSetup,
    private readonly cb: LiveCallbacks,
  ) {}

  connect(): void {
    this.closedByUs = false;
    this.open();
  }

  private open(): void {
    this.ready = false;
    const ws = new WebSocket(`${LIVE_WS_URL}?access_token=${encodeURIComponent(this.token)}`);
    ws.binaryType = 'arraybuffer';
    this.ws = ws;

    ws.onopen = () => {
      if (this.ws !== ws) return;
      ws.send(JSON.stringify({ setup: this.buildSetup() }));
    };

    ws.onmessage = (ev) => {
      if (this.ws !== ws) return;
      let msg: any;
      try {
        const text = typeof ev.data === 'string' ? ev.data : utf8Decode(new Uint8Array(ev.data as ArrayBuffer));
        msg = JSON.parse(text);
      } catch {
        return; // ignore frames we cannot parse rather than killing the call
      }
      this.handle(msg);
    };

    ws.onerror = () => {
      // onclose always follows and carries the useful details.
    };

    ws.onclose = (ev) => {
      if (this.ws !== ws) return;
      this.ws = null;
      this.ready = false;
      if (this.closedByUs) return;
      this.handleDrop(ev.code ?? 1006, ev.reason ?? '');
    };
  }

  private buildSetup() {
    const s = this.setup;
    return {
      model: s.model.startsWith('models/') ? s.model : `models/${s.model}`,
      generationConfig: {
        responseModalities: ['AUDIO'],
        speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: s.voice } } },
      },
      systemInstruction: { parts: [{ text: s.systemInstruction }] },
      tools: s.tools,
      inputAudioTranscription: {},
      outputAudioTranscription: {},
      realtimeInputConfig: {
        automaticActivityDetection: { prefixPaddingMs: 120, silenceDurationMs: 700 },
      },
      // Lets long lessons continue past the context limit and lets us reconnect.
      contextWindowCompression: { slidingWindow: {} },
      sessionResumption: this.resumeHandle ? { handle: this.resumeHandle } : {},
    };
  }

  private handle(msg: any): void {
    if (msg.setupComplete) {
      this.ready = true;
      this.reconnects = 0;
      this.cb.onReady();
      return;
    }
    if (msg.sessionResumptionUpdate) {
      const u = msg.sessionResumptionUpdate;
      if (u.resumable && u.newHandle) this.resumeHandle = u.newHandle;
    }
    if (msg.goAway) {
      // The server is about to rotate the connection; reconnect proactively.
      this.reopenSoon(0);
      return;
    }
    if (msg.toolCall?.functionCalls?.length) {
      this.cb.onToolCalls(
        msg.toolCall.functionCalls.map((f: any) => ({
          id: String(f.id ?? ''),
          name: String(f.name ?? ''),
          args: f.args && typeof f.args === 'object' ? f.args : {},
        })),
      );
    }
    const sc = msg.serverContent;
    if (!sc) return;
    if (sc.interrupted) this.cb.onInterrupted();
    if (sc.inputTranscription?.text) this.cb.onUserText(sc.inputTranscription.text);
    if (sc.outputTranscription?.text) this.cb.onTeacherText(sc.outputTranscription.text);
    for (const part of sc.modelTurn?.parts ?? []) {
      const data = part?.inlineData?.data;
      if (typeof data === 'string' && String(part.inlineData.mimeType ?? '').startsWith('audio/')) {
        this.cb.onAudio(bytesToInt16(base64ToBytes(data)));
      }
    }
    if (sc.turnComplete) this.cb.onTurnComplete();
  }

  private handleDrop(code: number, reason: string): void {
    // 1007/1008/1011 with an auth-ish reason mean the server refused us; retrying
    // the same request cannot help, so report it honestly.
    const refused = code === 1007 || code === 1008 || /api key|token|permission|quota|unregistered|invalid/i.test(reason);
    if (refused && /expired/i.test(reason)) {
      this.cb.onFatal({ kind: 'expired' });
      return;
    }
    if (refused && !this.resumeHandle) {
      this.cb.onFatal({ kind: 'rejected', code, detail: reason });
      return;
    }
    if (this.reconnects >= MAX_RECONNECTS) {
      this.cb.onFatal(refused ? { kind: 'rejected', code, detail: reason } : { kind: 'network' });
      return;
    }
    this.reopenSoon(400 * 2 ** this.reconnects);
  }

  private reopenSoon(delayMs: number): void {
    if (this.closedByUs || this.reconnectTimer) return;
    this.reconnects++;
    this.cb.onReconnecting(this.reconnects);
    const old = this.ws;
    this.ws = null;
    this.ready = false;
    try {
      old?.close();
    } catch {}
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      if (!this.closedByUs) this.open();
    }, delayMs);
  }

  private send(obj: unknown): boolean {
    if (!this.ready || !this.ws || this.ws.readyState !== 1) return false;
    this.ws.send(JSON.stringify(obj));
    return true;
  }

  get isReady(): boolean {
    return this.ready;
  }

  sendAudio(pcm16k: Int16Array): void {
    this.send({
      realtimeInput: {
        audio: { data: bytesToBase64(int16ToBytes(pcm16k)), mimeType: `audio/pcm;rate=${MIC_SAMPLE_RATE}` },
      },
    });
  }

  /** Text typed/tapped by the student (or a quiet nudge from the app). */
  sendText(text: string): void {
    this.send({ realtimeInput: { text } });
  }

  respondToTools(results: { id: string; name: string; result: Record<string, unknown> }[]): void {
    this.send({
      toolResponse: {
        functionResponses: results.map((r) => ({
          id: r.id,
          name: r.name,
          // SILENT: don't make Mina stop and announce that a tool finished.
          response: { ...r.result, scheduling: 'SILENT' },
        })),
      },
    });
  }

  close(): void {
    this.closedByUs = true;
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    this.reconnectTimer = null;
    const ws = this.ws;
    this.ws = null;
    this.ready = false;
    try {
      ws?.close();
    } catch {}
  }
}
