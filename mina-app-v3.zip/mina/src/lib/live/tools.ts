// The tools Mina can call during a conversation. The model decides when to use them;
// nothing on the whiteboard or on her face is scripted in advance.

export const EMOTIONS = [
  'neutral',
  'happy',
  'laughing',
  'excited',
  'surprised',
  'confused',
  'annoyed',
  'encouraging',
] as const;
export type Emotion = (typeof EMOTIONS)[number];

export const BLOCK_KINDS = [
  'word',
  'sentence',
  'rule',
  'correction',
  'fill_blank',
  'pronunciation',
  'word_by_word',
  'note',
] as const;
export type BlockKind = (typeof BLOCK_KINDS)[number];

export interface BoardBlock {
  id: string;
  kind: BlockKind;
  en?: string;
  he?: string;
  wrong?: string;
  highlight?: string[];
  pairs?: { en: string; he: string }[];
  answer?: string;
  emoji?: string;
  revealed?: boolean;
}

export const CEFR = ['A1', 'A2', 'B1', 'B2', 'C1', 'C2'] as const;
export type Cefr = (typeof CEFR)[number];

const S = (description: string, extra: object = {}) => ({ type: 'STRING', description, ...extra });

const blockSchema = {
  type: 'OBJECT',
  properties: {
    kind: S(
      'word = one vocabulary word; sentence = example sentence; rule = short grammar explanation; ' +
        'correction = wrong vs. right sentence; fill_blank = exercise with ____; pronunciation = how to say a word; ' +
        'word_by_word = aligned translation; note = short handwritten side remark.',
      { enum: [...BLOCK_KINDS] },
    ),
    en: S('English text. For fill_blank write the sentence with ____ where the answer goes.'),
    he: S('Hebrew text: translation, explanation, or pronunciation written in Hebrew letters.'),
    wrong: S('Only for correction: the incorrect sentence the student said.'),
    highlight: { type: 'ARRAY', items: { type: 'STRING' }, description: 'Words inside `en` to highlight.' },
    pairs: {
      type: 'ARRAY',
      description: 'Only for word_by_word: each English word with its Hebrew meaning, in order.',
      items: { type: 'OBJECT', properties: { en: S('English word'), he: S('Hebrew meaning') }, required: ['en', 'he'] },
    },
    answer: S('Only for fill_blank: the missing word(s). Hidden until you call whiteboard_reveal.'),
    emoji: S('Optional single emoji that illustrates a vocabulary word.'),
  },
  required: ['kind'],
};

export function buildToolDeclarations(opts: { placement: boolean }) {
  const fns: any[] = [
    {
      name: 'set_expression',
      description:
        'Change your face to match how you feel right now. Call it often, whenever your emotion changes - before a joke, when surprised, when the student repeats a mistake (annoyed, playfully), when they succeed (excited).',
      parameters: {
        type: 'OBJECT',
        properties: { emotion: S('Your current emotion.', { enum: [...EMOTIONS] }) },
        required: ['emotion'],
      },
    },
    {
      name: 'whiteboard_show',
      description:
        'Write on the whiteboard next to you while you explain. Use it for every correction, new word, grammar rule or exercise. Keep it short: 1-4 blocks.',
      parameters: {
        type: 'OBJECT',
        properties: {
          title: S('Optional short heading for the board.'),
          blocks: { type: 'ARRAY', items: blockSchema },
          append: { type: 'BOOLEAN', description: 'true = add below what is already there; false = start a clean board.' },
        },
        required: ['blocks'],
      },
    },
    {
      name: 'whiteboard_reveal',
      description: 'Reveal the hidden answers of the fill_blank exercises currently on the board.',
      parameters: { type: 'OBJECT', properties: {} },
    },
    {
      name: 'whiteboard_clear',
      description: 'Wipe the whiteboard when you move to a new topic.',
      parameters: { type: 'OBJECT', properties: {} },
    },
    {
      name: 'save_mistake',
      description:
        'Record a real mistake the student just made so you can come back to it in future lessons. Call once per mistake.',
      parameters: {
        type: 'OBJECT',
        properties: {
          wrong: S('What the student said.'),
          correct: S('The correct version.'),
          explanation_he: S('One short sentence in Hebrew explaining the rule.'),
          category: S('Type of mistake.', { enum: ['grammar', 'vocabulary', 'pronunciation', 'word_order', 'other'] }),
        },
        required: ['wrong', 'correct', 'category'],
      },
    },
    {
      name: 'save_vocabulary',
      description: 'Save a new English word or phrase the student just learned to their review list.',
      parameters: {
        type: 'OBJECT',
        properties: {
          word: S('The English word or phrase.'),
          translation_he: S('Hebrew translation.'),
          example: S('A short English example sentence.'),
        },
        required: ['word', 'translation_he'],
      },
    },
  ];
  if (opts.placement) {
    fns.push({
      name: 'set_level',
      description: 'Placement test only: store the CEFR level you assessed once you are confident.',
      parameters: {
        type: 'OBJECT',
        properties: {
          cefr: S('Assessed level.', { enum: [...CEFR] }),
          reason_he: S('One sentence in Hebrew explaining the assessment.'),
        },
        required: ['cefr'],
      },
    });
  }
  return [{ functionDeclarations: fns }];
}

// ---------- validation of what the model sends ----------

const str = (v: unknown, max = 400): string | undefined =>
  typeof v === 'string' && v.trim() ? v.trim().slice(0, max) : undefined;

let blockSeq = 0;

/** Turn untrusted tool arguments into safe board blocks (drops anything malformed). */
export function parseBlocks(raw: unknown): BoardBlock[] {
  if (!Array.isArray(raw)) return [];
  const out: BoardBlock[] = [];
  for (const b of raw.slice(0, 8)) {
    if (!b || typeof b !== 'object') continue;
    const o = b as Record<string, unknown>;
    const kind = (BLOCK_KINDS as readonly string[]).includes(o.kind as string) ? (o.kind as BlockKind) : null;
    if (!kind) continue;
    const block: BoardBlock = {
      id: `b${++blockSeq}`,
      kind,
      en: str(o.en),
      he: str(o.he),
      wrong: str(o.wrong),
      answer: str(o.answer, 80),
      emoji: str(o.emoji, 8),
    };
    if (Array.isArray(o.highlight)) {
      block.highlight = o.highlight.map((h) => str(h, 60)).filter((h): h is string => !!h).slice(0, 8);
    }
    if (Array.isArray(o.pairs)) {
      block.pairs = o.pairs
        .map((p: any) => ({ en: str(p?.en, 60), he: str(p?.he, 60) }))
        .filter((p): p is { en: string; he: string } => !!p.en && !!p.he)
        .slice(0, 14);
    }
    const hasContent = block.en || block.he || block.wrong || block.pairs?.length;
    if (hasContent) out.push(block);
  }
  return out;
}

export function parseEmotion(raw: unknown): Emotion | null {
  return (EMOTIONS as readonly string[]).includes(raw as string) ? (raw as Emotion) : null;
}

export function parseCefr(raw: unknown): Cefr | null {
  return (CEFR as readonly string[]).includes(raw as string) ? (raw as Cefr) : null;
}

/** Split a sentence into pieces, marking the ones that should be highlighted. */
export function splitHighlights(text: string, highlight: string[] = []): { text: string; hit: boolean }[] {
  const words = highlight.filter(Boolean).sort((a, b) => b.length - a.length);
  if (!words.length) return [{ text, hit: false }];
  const esc = words.map((w) => w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
  const re = new RegExp(`(${esc.join('|')})`, 'gi');
  return text
    .split(re)
    .filter((p) => p !== '')
    .map((p) => ({ text: p, hit: words.some((w) => w.toLowerCase() === p.toLowerCase()) }));
}
