import type { Cefr } from './live/tools';

// A real course: every lesson has a goal, a warm-up, what to teach, how to practise and
// a short scene. The teacher gets the whole plan before she says a word, so she leads
// the lesson instead of asking the student what to do. The plans describe the content
// in general terms; Mina produces the actual words in whatever language is taught.

export interface LessonPlan {
  id: string;
  level: Cefr;
  title: string; // Hebrew, shown in the app
  goal: string; // Hebrew, shown in the app
  topic: string; // for the teacher
  warmup: string;
  teach: string[];
  practice: string;
  scene: string;
}

const L = (level: Cefr, id: string, title: string, goal: string, topic: string, warmup: string, teach: string[], practice: string, scene: string): LessonPlan => ({
  id, level, title, goal, topic, warmup, teach, practice, scene,
});

export const CURRICULUM: LessonPlan[] = [
  // ---------- A1 ----------
  L('A1', 'a1-first-words', 'המילים הראשונות', 'ללמוד 8 מילים ראשונות ולהגיד אותן בקול', 'first words for a total beginner',
    'Say hello in the student\'s language, explain that today they will learn their very first words, one at a time, and that all they need to do is repeat after you.',
    ['hello, thank you, yes, no (one word at a time)', 'apple, water, bread, coffee (one word at a time, with an emoji)', 'quick review game: you say the word in the student\'s language, they say it in the new language'],
    'Point to imaginary objects one by one ("what is this?" in the student\'s language); the student answers with the new word.',
    'You are a market seller; the student buys an apple and water using only the new words, "please" and "thank you".'),
  L('A1', 'a1-hello', 'נעים להכיר', 'להציג את עצמך במשפטים פשוטים', 'greetings and introducing yourself',
    'Greet the student warmly and introduce yourself in one simple sentence.',
    ['hello / goodbye and how are you', 'my name is ..., I am from ..., I live in ...', 'numbers 1-10 to say your age', 'the verb "to be" for I / you'],
    'Ask the student simple personal questions one by one and have them answer in full sentences.',
    'You meet the student at a party; they introduce themselves to you.'),
  L('A1', 'a1-family', 'המשפחה שלי', 'לספר על בני המשפחה', 'family members',
    'Show a made-up family of your own and ask if the student has brothers or sisters.',
    ['mother, father, brother, sister, son, daughter', 'I have ... / I don\'t have ...', 'possessive: my / your / his / her', 'simple adjectives: tall, funny, young, old'],
    'Ask the student to describe two people in their family with one adjective each.',
    'You are a new friend looking at a family photo on the student\'s phone.'),
  L('A1', 'a1-food', 'אוכל ושתייה', 'להגיד מה אוהבים לאכול ולהזמין משהו פשוט', 'food and drinks',
    'Tell what you had for breakfast (invent something funny) and ask what they had.',
    ['10 common foods and drinks', 'I like / I don\'t like / I love', 'I would like ..., please', 'a / an / some'],
    'Play "like or don\'t like": name foods, the student answers in a full sentence.',
    'You are a waiter at a café; the student orders breakfast.'),
  L('A1', 'a1-day', 'היום שלי', 'לתאר סדר יום', 'daily routine in the present simple',
    'Describe your own (silly) morning routine in three short sentences.',
    ['wake up, eat, go to work/school, come home, sleep', 'telling the time: at 7 o\'clock', 'present simple with I / you / he-she', 'first, then, after that'],
    'Ask the student about their day step by step, from morning to night.',
    'You are a new roommate trying to plan who uses the shower when.'),
  L('A1', 'a1-place', 'איפה זה?', 'לשאול ולהסביר איפה נמצא משהו', 'places in town and directions',
    'Ask what is near the student\'s home.',
    ['bank, shop, station, park, hospital, restaurant', 'Where is ...? It is next to / near / in front of', 'turn left / right, go straight', 'there is / there are'],
    'Describe a small map in words; the student tells you where things are.',
    'You are a lost tourist; the student gives you directions.'),
  L('A1', 'a1-shop', 'קניות', 'לשאול מחיר ולקנות', 'shopping, colours and prices',
    'Tell the student about something you bought that you regret.',
    ['colours and clothes', 'How much is it? It is ...', 'numbers up to 100', 'this / that, big / small'],
    'The student asks the price of three items and chooses one.',
    'You are a shop assistant at a market stall.'),

  // ---------- A2 ----------
  L('A2', 'a2-weekend', 'מה עשית בסופ״ש?', 'לספר על משהו שקרה בעבר', 'past tense for everyday events',
    'Tell a short funny story about your own weekend in the past tense.',
    ['past tense of common regular verbs', '5 irregular past forms of very common verbs (like go, have, eat, see, do)', 'yesterday, last week, two days ago', 'questions in the past: did you ...?'],
    'Ask the student what they did yesterday and last weekend; insist on past forms.',
    'You are a coworker on Monday morning asking about the weekend.'),
  L('A2', 'a2-plans', 'תוכניות לעתיד', 'לדבר על תוכניות', 'future plans',
    'Tell the student about a crazy plan you have for next summer.',
    ['the main future form for plans (like "going to")', 'tomorrow, next week, next year', 'I want to / I would like to', 'maybe, probably'],
    'Ask about the student\'s plans for the weekend, next month and next year.',
    'You are a friend trying to make plans to meet this week.'),
  L('A2', 'a2-restaurant', 'במסעדה', 'להזמין במסעדה ולבקש דברים', 'ordering at a restaurant',
    'Ask the student about their favourite restaurant.',
    ['starter, main course, dessert, the bill', 'Could I have ...? Can I get ...?', 'polite requests and thanks', 'there is a problem with ...'],
    'The student practises three polite requests you prompt one at a time.',
    'You are a slightly forgetful waiter; the student orders a full meal and asks for the bill.'),
  L('A2', 'a2-health', 'אצל הרופא', 'לתאר איך מרגישים', 'health and the body',
    'Pretend you have a terrible cold and ask for sympathy.',
    ['body parts', 'I have a headache / a sore throat / a fever', 'How long have you ...? since / for (simple use)', 'you should / you shouldn\'t'],
    'Describe symptoms; the student gives advice with "should".',
    'You are a doctor; the student is the patient describing a problem.'),
  L('A2', 'a2-travel', 'טיול', 'להסתדר בשדה תעופה ובמלון', 'travel: airport and hotel',
    'Ask about the best trip the student ever took.',
    ['ticket, passport, gate, luggage, reservation', 'I have a reservation for ...', 'What time does ... leave?', 'comparatives: cheaper, faster, better'],
    'Compare two hotels you describe; the student chooses and explains why.',
    'You are a hotel receptionist; the student checks in and has a problem with the room.'),
  L('A2', 'a2-hobbies', 'תחביבים', 'לדבר על מה שאוהבים לעשות', 'hobbies and free time',
    'Confess an embarrassing hobby of yours.',
    ['hobby words connected to the student\'s interests', 'I enjoy / I am good at / I am interested in + -ing', 'how often: always, usually, sometimes, never', 'can / can\'t for ability'],
    'Ask how often the student does things; they answer with frequency words.',
    'You meet the student at a club and try to convince them to join your hobby.'),

  // ---------- B1 ----------
  L('B1', 'b1-experience', 'כבר עשית את זה?', 'לדבר על חוויות חיים', 'life experiences (present perfect or equivalent)',
    'Share an unusual experience you "have had".',
    ['the form used for experiences up to now (present perfect in English)', 'ever / never / already / yet', 'difference from the simple past', 'been to vs. went to (or the equivalent)'],
    'Play "Have you ever...?" with five questions; follow up on every "yes".',
    'You are interviewing the student for a travel blog.'),
  L('B1', 'b1-opinion', 'מה דעתך?', 'להביע ולהצדיק דעה', 'giving opinions',
    'Make a provocative but harmless claim (e.g. pineapple belongs on pizza) and ask if they agree.',
    ['I think / In my opinion / I agree / I disagree because', 'linking words: because, so, but, although', 'polite disagreement', 'asking for opinions'],
    'Give three statements; the student agrees or disagrees with a reason.',
    'You and the student are friends choosing a movie and disagree.'),
  L('B1', 'b1-work', 'עבודה', 'לדבר על עבודה ולימודים', 'work and studies',
    'Describe your "job" as a teacher in a funny way.',
    ['job words relevant to the student\'s goal', 'responsible for, deal with, work on', 'present continuous for current projects', 'describing strengths'],
    'Ask the student to describe a normal day at work or school in detail.',
    'Job interview: you are the interviewer, three classic questions.'),
  L('B1', 'b1-story', 'לספר סיפור', 'לספר סיפור ברצף', 'storytelling in the past',
    'Start a story ("Last night something strange happened...") and stop at the exciting part.',
    ['past continuous for background (I was walking when...)', 'sequencing: suddenly, then, in the end', 'reacting: really? no way! what happened next?', 'irregular past forms'],
    'The student continues your story; then they tell a short real story.',
    'You are a friend at a café who wants every detail of the story.'),
  L('B1', 'b1-problems', 'לפתור בעיות', 'להתלונן ולבקש פתרון בנימוס', 'complaints and solutions',
    'Complain dramatically about something small that happened to you today.',
    ['I am afraid there is a problem with ...', 'Could you please ...? Would it be possible to ...?', 'refund, exchange, broken, missing', 'first conditional: if you ..., I will ...'],
    'Give three situations; the student makes a polite complaint for each.',
    'You are a customer service agent; the student returns a broken product.'),

  // ---------- B2 ----------
  L('B2', 'b2-hypothetical', 'מה היה קורה אם...', 'לדבר על מצבים דמיוניים', 'hypothetical situations',
    'Ask what the student would do with a million dollars, and answer yourself first.',
    ['second conditional (if I had..., I would...)', 'I wish ... / If only ...', 'would rather', 'imaginative vocabulary'],
    'Ask four "what would you do if" questions and push for full conditionals.',
    'You are a game-show host asking impossible questions.'),
  L('B2', 'b2-debate', 'ויכוח', 'לטעון ולשכנע', 'debating and persuading',
    'Choose a topic connected to the student\'s interests and take a strong side.',
    ['On the one hand / on the other hand', 'It could be argued that / The main reason is', 'conceding a point', 'conclusions: all in all, that\'s why'],
    'The student argues the opposite side for one minute; you challenge them.',
    'A friendly TV debate where you are the opponent.'),
  L('B2', 'b2-news', 'אקטואליה', 'לסכם ולהגיב לחדשות', 'talking about news and society (no specific current events; general topics like technology or environment)',
    'Ask how the student usually gets their news.',
    ['reported speech (they said that...)', 'passive voice for news (was announced, has been built)', 'vocabulary of technology and environment', 'expressing surprise and concern'],
    'Invent a short neutral "news item"; the student reports it back and reacts.',
    'You are a radio host; the student is a guest commenting.'),
  L('B2', 'b2-phrasal', 'ביטויים יומיומיים', 'להשתמש בביטויים טבעיים', 'idioms and natural phrases',
    'Use an idiom on purpose in your first sentence and ask if they understood.',
    ['6 very common idioms or phrasal verbs of the taught language', 'when each one is natural', 'avoiding literal translation from the native language'],
    'Describe situations; the student answers with the right phrase.',
    'Chat between friends planning a trip, full of everyday phrases.'),

  // ---------- C1 / C2 ----------
  L('C1', 'c1-nuance', 'ניואנסים', 'לדייק במשמעות ובטון', 'nuance, register and tone',
    'Say the same sentence in a formal and a slang way and ask which fits a job interview.',
    ['formal vs. informal register', 'hedging: it seems, arguably, to some extent', 'precise synonyms', 'softening criticism'],
    'Give blunt sentences; the student rewrites them politely or formally.',
    'You are a demanding manager; the student must give you difficult feedback politely.'),
  L('C1', 'c1-present', 'הצגה מול קהל', 'להציג רעיון בצורה משכנעת', 'presenting and structuring ideas',
    'Pitch a ridiculous startup idea to the student in 20 seconds.',
    ['signposting: firstly, moving on, to sum up', 'emphasis: what really matters is', 'handling questions', 'rhythm and pausing'],
    'The student pitches an idea from their own life in one minute; you ask two tough questions.',
    'You are an investor on a startup show.'),
  L('C2', 'c2-culture', 'תרבות והומור', 'להבין הומור ורמזים תרבותיים', 'culture, humour and implied meaning',
    'Tell a pun or joke in the taught language and see if the student gets it.',
    ['wordplay and double meanings', 'irony and understatement', 'cultural references', 'reading between the lines'],
    'Give ambiguous sentences; the student explains the hidden meaning.',
    'A dinner party where you keep making subtle jokes.'),
];

const ORDER: Cefr[] = ['A1', 'A2', 'B1', 'B2', 'C1', 'C2'];

/** The lessons for a level (falls back to the nearest level that has lessons). */
export function lessonsFor(level: Cefr): LessonPlan[] {
  const i = ORDER.indexOf(level);
  for (let d = 0; d < ORDER.length; d++) {
    for (const j of [i - d, i + d]) {
      const list = CURRICULUM.filter((l) => l.level === ORDER[j]);
      if (list.length) return list;
    }
  }
  return CURRICULUM;
}

/** Next lesson: the first lesson of the level not done yet, then cycles. */
export function nextLesson(level: Cefr, doneIds: string[]): LessonPlan {
  const list = lessonsFor(level);
  const fresh = list.find((l) => !doneIds.includes(l.id));
  if (fresh) return fresh;
  return list[doneIds.length % list.length];
}

export function lessonById(id: string | undefined): LessonPlan | undefined {
  return CURRICULUM.find((l) => l.id === id);
}
