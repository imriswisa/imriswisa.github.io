export interface SessionRow {
  started_at: string;
  duration_seconds: number;
}

const dayKey = (d: Date) => `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;

/** Consecutive days with at least one lesson, ending today (or yesterday if today is still open). */
export function streak(sessions: SessionRow[], now = new Date()): number {
  const days = new Set(sessions.map((s) => dayKey(new Date(s.started_at))));
  const cursor = new Date(now);
  if (!days.has(dayKey(cursor))) cursor.setDate(cursor.getDate() - 1);
  let n = 0;
  while (days.has(dayKey(cursor))) {
    n++;
    cursor.setDate(cursor.getDate() - 1);
  }
  return n;
}

/** Minutes spoken on each of the last 7 days, oldest first; the last entry is today. */
export function weekMinutes(sessions: SessionRow[], now = new Date()): number[] {
  const out: number[] = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(d.getDate() - i);
    const key = dayKey(d);
    const seconds = sessions
      .filter((s) => dayKey(new Date(s.started_at)) === key)
      .reduce((sum, s) => sum + s.duration_seconds, 0);
    out.push(seconds > 0 ? Math.max(1, Math.round(seconds / 60)) : 0);
  }
  return out;
}

export function minutesToday(sessions: SessionRow[], now = new Date()): number {
  return weekMinutes(sessions, now)[6];
}
