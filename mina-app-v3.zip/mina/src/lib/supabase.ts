import 'react-native-url-polyfill/auto';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createClient } from '@supabase/supabase-js';
import { SUPABASE_ANON_KEY, SUPABASE_URL, isBackendConfigured } from './config';

// When the project has no .env yet we still create a client (pointing nowhere) so
// imports don't crash; every screen checks `isBackendConfigured` first and shows the
// setup instructions instead of pretending to work.
export const supabase = createClient(
  isBackendConfigured ? SUPABASE_URL : 'http://localhost:54321',
  isBackendConfigured ? SUPABASE_ANON_KEY : 'not-configured',
  {
    auth: {
      storage: AsyncStorage,
      autoRefreshToken: true,
      persistSession: true,
      detectSessionInUrl: false,
    },
  },
);
