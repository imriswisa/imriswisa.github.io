// Public configuration. Only values that are safe to ship inside the app live here:
// the Supabase URL and its anon (publishable) key. The Gemini API key never reaches
// the client - it stays in the Supabase Edge Function, which hands out short-lived
// single-session tokens instead.

export const SUPABASE_URL = process.env.EXPO_PUBLIC_SUPABASE_URL ?? '';
export const SUPABASE_ANON_KEY = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY ?? '';

export const isBackendConfigured =
  SUPABASE_URL.startsWith('http') && SUPABASE_ANON_KEY.length > 20;

/** Gemini Live WebSocket endpoint used with ephemeral tokens. */
export const LIVE_WS_URL =
  'wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContentConstrained';

export const MIC_SAMPLE_RATE = 16000;
export const VOICE_SAMPLE_RATE = 24000;
