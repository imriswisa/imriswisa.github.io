import type { Cefr } from './live/tools';

export interface Scenario {
  id: string;
  emoji: string;
  title: string;
  /** Sent to the teacher: who she plays and what the student must achieve. */
  brief: string;
  goal: string;
}

export const SCENARIOS: Scenario[] = [
  { id: 'restaurant', emoji: '🍝', title: 'מסעדה', goal: 'להזמין ארוחה ולבקש חשבון', brief: 'You are a waiter in a busy restaurant. The student must order a starter, a main dish and a drink, ask one question about the menu, and ask for the bill.' },
  { id: 'airport', emoji: '✈️', title: 'שדה תעופה', goal: 'לעשות צ׳ק-אין ולעבור ביקורת', brief: 'You are an airline check-in agent, then a border officer. The student must check in, choose a seat, handle an overweight bag, and answer the officer\'s questions about their trip.' },
  { id: 'hotel', emoji: '🏨', title: 'מלון', goal: 'לעשות צ׳ק-אין ולפתור בעיה בחדר', brief: 'You are a hotel receptionist. The student must check in, ask about breakfast and Wi-Fi, and report a problem in the room and get it fixed.' },
  { id: 'shopping', emoji: '🛍️', title: 'קניות', goal: 'למצוא מידה ולבקש הנחה', brief: 'You are a shop assistant in a clothing store. The student must ask for a different size and colour, ask the price, and try to get a discount.' },
  { id: 'interview', emoji: '💼', title: 'ראיון עבודה', goal: 'להציג את עצמך ולענות על שאלות', brief: 'You are a friendly but professional hiring manager. The student must introduce themselves, describe their experience, answer two typical interview questions and ask one question back.' },
  { id: 'gym', emoji: '🏋️', title: 'חדר כושר', goal: 'להירשם ולבקש עזרה במכשיר', brief: 'You are a gym trainer at the front desk. The student must ask about membership prices, ask how to use a machine, and describe their fitness goal.' },
  { id: 'meet', emoji: '👋', title: 'להכיר אנשים', goal: 'לנהל שיחת היכרות', brief: 'You are a friendly stranger at a party. The student must introduce themselves, ask you three questions about yourself, and find one thing you have in common.' },
  { id: 'school', emoji: '🎒', title: 'בית ספר', goal: 'לדבר עם מורה על מטלה', brief: 'You are a teacher at an international school. The student must ask about a homework assignment, explain why it is late, and agree on a new deadline.' },
  { id: 'travel', emoji: '🗺️', title: 'טיול', goal: 'לשאול איך מגיעים', brief: 'You are a local on the street in London. The student is a lost tourist who must ask for directions to a museum, ask about public transport and thank you politely.' },
  { id: 'sports', emoji: '⚽', title: 'ספורט', goal: 'לדבר על משחק', brief: 'You are a football fan in a pub watching a match. The student must talk about their favourite team, react to the game and make a prediction.' },
];

export interface GrammarTopic {
  level: Cefr;
  title: string;
  topic: string;
}

export const GRAMMAR: GrammarTopic[] = [
  { level: 'A1', title: 'am / is / are', topic: 'the verb "to be" in the present: am, is, are' },
  { level: 'A1', title: 'הווה פשוט', topic: 'present simple, including he/she/it + s' },
  { level: 'A1', title: 'a / an / the', topic: 'articles: a, an, the (Hebrew speakers often drop "a")' },
  { level: 'A2', title: 'עבר פשוט: go → went', topic: 'past simple with regular and irregular verbs' },
  { level: 'A2', title: 'הווה ממושך', topic: 'present continuous vs present simple' },
  { level: 'A2', title: 'much / many / a lot', topic: 'countable and uncountable nouns: much, many, a lot of, some, any' },
  { level: 'B1', title: 'Present Perfect', topic: 'present perfect vs past simple (a tense Hebrew does not have)' },
  { level: 'B1', title: 'עתיד: will / going to', topic: 'future forms: will vs going to' },
  { level: 'B1', title: 'מילות יחס', topic: 'prepositions of time and place: in, on, at' },
  { level: 'B2', title: 'משפטי תנאי', topic: 'first and second conditionals' },
  { level: 'B2', title: 'סביל (Passive)', topic: 'the passive voice' },
  { level: 'C1', title: 'תנאי שלישי ומעורב', topic: 'third and mixed conditionals' },
  { level: 'C1', title: 'Phrasal verbs', topic: 'common phrasal verbs in natural conversation' },
];

export const LEVELS: { id: Cefr; title: string; hint: string }[] = [
  { id: 'A1', title: 'מתחיל מאפס', hint: 'לא יודע/ת כלום, או כמה מילים בודדות' },
  { id: 'A2', title: 'בסיסי', hint: 'מסתדר במשפטים פשוטים' },
  { id: 'B1', title: 'בינוני', hint: 'מנהל שיחה על נושאים מוכרים' },
  { id: 'B2', title: 'בינוני-גבוה', hint: 'מדבר די בחופשיות, עם טעויות' },
  { id: 'C1', title: 'מתקדם', hint: 'שוטף, רוצה ללטש' },
  { id: 'C2', title: 'שליטה מלאה', hint: 'כמעט כמו שפת אם' },
];

export const INTERESTS = ['ספורט', 'טכנולוגיה', 'מוזיקה', 'סרטים וסדרות', 'טיולים', 'אוכל', 'עסקים', 'גיימינג', 'אופנה', 'מדע', 'כושר', 'משפחה'];

export const GOALS = ['עבודה וקריירה', 'טיולים בחו״ל', 'לימודים', 'שיחות יומיומיות', 'ראיונות עבודה', 'סתם בשביל הכיף'];
