// Pure PCM helpers shared by the web and native audio engines. No platform APIs here,
// so everything in this file is unit-tested in tests/pcm.test.ts.

const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
const B64_LOOKUP = (() => {
  const t = new Uint8Array(256).fill(255);
  for (let i = 0; i < B64.length; i++) t[B64.charCodeAt(i)] = i;
  return t;
})();

export function bytesToBase64(bytes: Uint8Array): string {
  let out = '';
  let i = 0;
  for (; i + 2 < bytes.length; i += 3) {
    const n = (bytes[i] << 16) | (bytes[i + 1] << 8) | bytes[i + 2];
    out += B64[(n >> 18) & 63] + B64[(n >> 12) & 63] + B64[(n >> 6) & 63] + B64[n & 63];
  }
  if (i + 1 === bytes.length) {
    const n = bytes[i] << 16;
    out += B64[(n >> 18) & 63] + B64[(n >> 12) & 63] + '==';
  } else if (i + 2 === bytes.length) {
    const n = (bytes[i] << 16) | (bytes[i + 1] << 8);
    out += B64[(n >> 18) & 63] + B64[(n >> 12) & 63] + B64[(n >> 6) & 63] + '=';
  }
  return out;
}

export function base64ToBytes(b64: string): Uint8Array {
  let len = b64.length;
  while (len > 0 && b64[len - 1] === '=') len--;
  const out = new Uint8Array(Math.floor((len * 3) / 4));
  let o = 0;
  let acc = 0;
  let bits = 0;
  for (let i = 0; i < len; i++) {
    const v = B64_LOOKUP[b64.charCodeAt(i)];
    if (v === 255) continue; // skip whitespace / url-safe leftovers
    acc = (acc << 6) | v;
    bits += 6;
    if (bits >= 8) {
      bits -= 8;
      out[o++] = (acc >> bits) & 0xff;
    }
  }
  return o === out.length ? out : out.subarray(0, o);
}

/** Little-endian 16-bit PCM bytes -> samples (copies, so odd offsets are safe). */
export function bytesToInt16(bytes: Uint8Array): Int16Array {
  const n = bytes.length >> 1;
  const out = new Int16Array(n);
  for (let i = 0; i < n; i++) {
    const v = bytes[2 * i] | (bytes[2 * i + 1] << 8);
    out[i] = v >= 0x8000 ? v - 0x10000 : v;
  }
  return out;
}

export function int16ToBytes(pcm: Int16Array): Uint8Array {
  const out = new Uint8Array(pcm.length * 2);
  for (let i = 0; i < pcm.length; i++) {
    const v = pcm[i];
    out[2 * i] = v & 0xff;
    out[2 * i + 1] = (v >> 8) & 0xff;
  }
  return out;
}

export function floatToInt16(f: Float32Array): Int16Array {
  const out = new Int16Array(f.length);
  for (let i = 0; i < f.length; i++) {
    const s = Math.max(-1, Math.min(1, f[i]));
    out[i] = s < 0 ? Math.round(s * 0x8000) : Math.round(s * 0x7fff);
  }
  return out;
}

export function int16ToFloat(pcm: Int16Array): Float32Array<ArrayBuffer> {
  const out = new Float32Array(pcm.length);
  for (let i = 0; i < pcm.length; i++) out[i] = pcm[i] / 0x8000;
  return out;
}

export function rms(pcm: Int16Array, from = 0, to = pcm.length): number {
  if (to <= from) return 0;
  let sum = 0;
  for (let i = from; i < to; i++) {
    const s = pcm[i] / 0x8000;
    sum += s * s;
  }
  return Math.sqrt(sum / (to - from));
}

/**
 * Streaming linear resampler (mono). Keeps its phase between calls so consecutive
 * microphone blocks join without clicks. Used to bring 44.1/48 kHz browser capture
 * down to the 16 kHz the Live API expects.
 */
export class LinearResampler {
  // Read position relative to the current block. A value in (-1, 0) lies between
  // the previous block's final sample and this block's first one.
  private pos = 0;
  private last = 0;
  private readonly step: number;

  constructor(inRate: number, outRate: number) {
    this.step = inRate / outRate;
  }

  process(input: Float32Array): Float32Array {
    if (this.step === 1 || input.length === 0) return input;
    const out = new Float32Array(Math.ceil((input.length - this.pos) / this.step) + 1);
    let n = 0;
    let pos = this.pos;
    const lastIndex = input.length - 1;
    while (pos <= lastIndex) {
      const i = Math.floor(pos);
      const frac = pos - i;
      const a = i < 0 ? this.last : input[i];
      const b = i + 1 <= lastIndex ? input[i + 1] : a;
      out[n++] = a + (b - a) * frac;
      pos += this.step;
    }
    this.pos = pos - input.length;
    this.last = input[lastIndex];
    return out.subarray(0, n);
  }
}

/**
 * Remembers how loud each ~40 ms slice of queued speech is and when it will play,
 * so the character's mouth can follow the audio that is actually coming out of the
 * speaker rather than the moment the bytes arrived from the network.
 */
export class LevelTimeline {
  private slices: { start: number; end: number; level: number }[] = [];
  private cursor = 0; // ms timestamp where the next queued audio will start

  /** Queue `pcm` (at `sampleRate`) for playback; returns the scheduled start time in ms. */
  push(pcm: Int16Array, sampleRate: number, now: number): number {
    const start = Math.max(this.cursor, now);
    const win = Math.round(sampleRate * 0.04);
    let t = start;
    for (let i = 0; i < pcm.length; i += win) {
      const to = Math.min(pcm.length, i + win);
      const dur = ((to - i) / sampleRate) * 1000;
      this.slices.push({ start: t, end: t + dur, level: rms(pcm, i, to) });
      t += dur;
    }
    this.cursor = t;
    return start;
  }

  /** 0..1 loudness of whatever is playing at `now`. */
  levelAt(now: number): number {
    while (this.slices.length && this.slices[0].end <= now) this.slices.shift();
    const s = this.slices[0];
    if (!s || s.start > now) return 0;
    return Math.min(1, s.level * 4.5);
  }

  isPlaying(now: number): boolean {
    return this.cursor > now;
  }

  /** ms of audio still waiting to be heard. */
  pendingMs(now: number): number {
    return Math.max(0, this.cursor - now);
  }

  clear(): void {
    this.slices = [];
    this.cursor = 0;
  }
}

/** UTF-8 decode without relying on TextDecoder (missing on some Hermes builds). */
export function utf8Decode(bytes: Uint8Array): string {
  let out = '';
  let i = 0;
  while (i < bytes.length) {
    const b = bytes[i++];
    let cp: number;
    if (b < 0x80) cp = b;
    else if (b < 0xe0) cp = ((b & 0x1f) << 6) | (bytes[i++] & 0x3f);
    else if (b < 0xf0) cp = ((b & 0x0f) << 12) | ((bytes[i++] & 0x3f) << 6) | (bytes[i++] & 0x3f);
    else
      cp =
        ((b & 0x07) << 18) |
        ((bytes[i++] & 0x3f) << 12) |
        ((bytes[i++] & 0x3f) << 6) |
        (bytes[i++] & 0x3f);
    out += String.fromCodePoint(cp);
  }
  return out;
}
