import {
  AudioBufferQueueSourceNode,
  AudioContext,
  AudioManager,
  AudioRecorder,
} from 'react-native-audio-api';
import { MIC_SAMPLE_RATE, VOICE_SAMPLE_RATE } from '../config';
import { LevelTimeline, floatToInt16, int16ToFloat, rms } from './pcm';
import { AudioEngine, AudioUnavailableError, MicPermissionError } from './types';

// Native (iOS / Android) engine. Needs a development build - the audio module is
// native code, so it is not available inside Expo Go.
class NativeAudioEngine implements AudioEngine {
  private ctx: AudioContext | null = null;
  private queue: AudioBufferQueueSourceNode | null = null;
  private recorder: AudioRecorder | null = null;
  private timeline = new LevelTimeline();
  private muted = false;
  private micLevel = 0;

  async start(onMicChunk: (pcm: Int16Array) => void): Promise<void> {
    const permission = await AudioManager.requestRecordingPermissions();
    if (permission !== 'Granted') throw new MicPermissionError();

    // "voiceChat" + voice processing turns on the phone's echo canceller, which is
    // what makes it possible to interrupt Mina over the loudspeaker.
    AudioManager.setSystemOptions({
      ios: {
        category: 'playAndRecord',
        mode: 'voiceChat',
        options: ['defaultToSpeaker', 'allowBluetoothHFP'],
      },
      android: { mode: 'inCommunication', communicationDevice: 'speaker' },
    });
    await AudioManager.setAudioSessionActivity(true);

    this.ctx = new AudioContext({ sampleRate: VOICE_SAMPLE_RATE });
    this.startQueue();

    const recorder = new AudioRecorder({
      androidInputPreset: 'voiceCommunication',
      iosVoiceProcessing: true,
    });
    this.recorder = recorder;
    const registered = recorder.onAudioReady(
      { sampleRate: MIC_SAMPLE_RATE, bufferLength: MIC_SAMPLE_RATE / 20, channelCount: 1 },
      ({ buffer, numFrames }) => {
        const pcm = floatToInt16(buffer.getChannelData(0).subarray(0, numFrames));
        this.micLevel = this.muted ? 0 : Math.min(1, rms(pcm) * 6);
        onMicChunk(this.muted ? new Int16Array(pcm.length) : pcm);
      },
    );
    if (registered.status === 'error') throw new AudioUnavailableError(registered.message);
    const started = await recorder.start();
    if (started.status === 'error') throw new AudioUnavailableError(started.message);
  }

  private startQueue(): void {
    if (!this.ctx) return;
    this.queue = this.ctx.createBufferQueueSource();
    this.queue.connect(this.ctx.destination);
    this.queue.start();
  }

  play(pcm: Int16Array): void {
    if (!this.ctx || !this.queue || pcm.length === 0) return;
    const buffer = this.ctx.createBuffer(1, pcm.length, VOICE_SAMPLE_RATE);
    buffer.copyToChannel(int16ToFloat(pcm), 0);
    this.queue.enqueueBuffer(buffer);
    this.timeline.push(pcm, VOICE_SAMPLE_RATE, Date.now());
  }

  flush(): void {
    this.queue?.clearBuffers();
    this.timeline.clear();
  }

  setMuted(muted: boolean): void {
    this.muted = muted;
  }

  outputLevel(): number {
    return this.timeline.levelAt(Date.now());
  }

  inputLevel(): number {
    return this.micLevel;
  }

  isPlaying(): boolean {
    return this.timeline.isPlaying(Date.now());
  }

  async stop(): Promise<void> {
    this.timeline.clear();
    const recorder = this.recorder;
    this.recorder = null;
    if (recorder) {
      recorder.clearOnAudioReady();
      await recorder.stop().catch(() => {});
    }
    try {
      this.queue?.stop();
    } catch {}
    this.queue = null;
    const ctx = this.ctx;
    this.ctx = null;
    if (ctx) await ctx.close().catch(() => {});
    await AudioManager.setAudioSessionActivity(false).catch(() => {});
  }
}

export function createAudioEngine(): AudioEngine {
  return new NativeAudioEngine();
}

/** Native audio needs no tap to unlock; these exist so shared code can call them. */
export function primeAudio(): void {}
export function installAudioUnlock(): void {}
