export class MicPermissionError extends Error {
  constructor() {
    super('microphone-permission-denied');
    this.name = 'MicPermissionError';
  }
}

export class AudioUnavailableError extends Error {
  constructor(detail: string) {
    super(detail);
    this.name = 'AudioUnavailableError';
  }
}

/**
 * Full-duplex audio: captures the microphone as 16 kHz mono PCM while playing the
 * teacher's 24 kHz mono PCM, with echo cancellation so she doesn't hear herself.
 */
export interface AudioEngine {
  /** Ask for the microphone and start streaming chunks. Throws MicPermissionError. */
  start(onMicChunk: (pcm16k: Int16Array) => void): Promise<void>;
  /** Queue teacher speech (24 kHz mono) right after whatever is already queued. */
  play(pcm24k: Int16Array): void;
  /** Drop everything queued - used the instant the student interrupts. */
  flush(): void;
  setMuted(muted: boolean): void;
  /** 0..1 loudness of the speech coming out of the speaker right now. */
  outputLevel(): number;
  /** 0..1 loudness of the microphone right now. */
  inputLevel(): number;
  isPlaying(): boolean;
  /** true when the platform is holding audio back until the user taps (iPhone web). */
  isBlocked?(): boolean;
  /** Must be called from a tap handler. */
  unblock?(): Promise<void>;
  stop(): Promise<void>;
}
