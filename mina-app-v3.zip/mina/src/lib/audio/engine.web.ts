import { MIC_SAMPLE_RATE, VOICE_SAMPLE_RATE } from '../config';
import { LevelTimeline, LinearResampler, floatToInt16, int16ToFloat, rms } from './pcm';
import { AudioEngine, AudioUnavailableError, MicPermissionError } from './types';

// The capture worklet just forwards raw microphone blocks to the main thread.
const WORKLET = `
class MicTap extends AudioWorkletProcessor {
  process(inputs) {
    const ch = inputs[0] && inputs[0][0];
    if (ch && ch.length) this.port.postMessage(ch.slice(0));
    return true;
  }
}
registerProcessor('mic-tap', MicTap);
`;

// iPhone Safari only lets a page start audio from inside a tap. The lesson starts a
// moment after the tap (after navigation and the microphone prompt), so we create one
// shared AudioContext on the user's taps and reuse it for every lesson.
let shared: AudioContext | null = null;

function sharedContext(): AudioContext {
  if (!shared || shared.state === 'closed') {
    const Ctx: typeof AudioContext = (window as any).AudioContext ?? (window as any).webkitAudioContext;
    shared = new Ctx();
  }
  return shared;
}

/** Call from any tap: creates/resumes the shared context and plays one silent sample. */
export function primeAudio(): void {
  if (typeof window === 'undefined') return;
  try {
    const ctx = sharedContext();
    if (ctx.state !== 'running') void ctx.resume().catch(() => {});
    const buf = ctx.createBuffer(1, 1, ctx.sampleRate);
    const src = ctx.createBufferSource();
    src.buffer = buf;
    src.connect(ctx.destination);
    src.start();
  } catch {}
}

let listening = false;
/** Prime audio on every tap anywhere in the app (web only). */
export function installAudioUnlock(): void {
  if (listening || typeof document === 'undefined') return;
  listening = true;
  const handler = () => primeAudio();
  document.addEventListener('pointerdown', handler, { capture: true });
  document.addEventListener('touchend', handler, { capture: true });
  document.addEventListener('keydown', handler, { capture: true });
}

class WebAudioEngine implements AudioEngine {
  private ctx: AudioContext | null = null;
  private stream: MediaStream | null = null;
  private tap: AudioWorkletNode | null = null;
  private mic: MediaStreamAudioSourceNode | null = null;
  private sink: GainNode | null = null;
  private sources = new Set<AudioBufferSourceNode>();
  private nextTime = 0;
  private timeline = new LevelTimeline();
  private muted = false;
  private micLevel = 0;

  async start(onMicChunk: (pcm: Int16Array) => void): Promise<void> {
    if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
      throw new AudioUnavailableError('This browser cannot capture audio (needs HTTPS or localhost).');
    }
    try {
      this.stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true, channelCount: 1 },
      });
    } catch (e: any) {
      if (e?.name === 'NotAllowedError' || e?.name === 'SecurityError') throw new MicPermissionError();
      throw new AudioUnavailableError(e?.message ?? 'Microphone unavailable');
    }

    const ctx = sharedContext();
    this.ctx = ctx;
    if (ctx.state !== 'running') await Promise.race([ctx.resume(), new Promise((r) => setTimeout(r, 600))]).catch(() => {});

    if (!(ctx as any).__minaWorklet) {
      const url = URL.createObjectURL(new Blob([WORKLET], { type: 'application/javascript' }));
      await ctx.audioWorklet.addModule(url);
      URL.revokeObjectURL(url);
      (ctx as any).__minaWorklet = true;
    }

    const resampler = new LinearResampler(ctx.sampleRate, MIC_SAMPLE_RATE);
    const CHUNK = MIC_SAMPLE_RATE / 20; // 50 ms
    let pending = new Int16Array(0);

    const mic = ctx.createMediaStreamSource(this.stream);
    this.mic = mic;
    this.tap = new AudioWorkletNode(ctx, 'mic-tap');
    this.tap.port.onmessage = (ev: MessageEvent<Float32Array>) => {
      const pcm = floatToInt16(resampler.process(ev.data));
      const merged = new Int16Array(pending.length + pcm.length);
      merged.set(pending);
      merged.set(pcm, pending.length);
      let off = 0;
      while (merged.length - off >= CHUNK) {
        const chunk = merged.slice(off, off + CHUNK);
        off += CHUNK;
        this.micLevel = this.muted ? 0 : Math.min(1, rms(chunk) * 6);
        // While muted we send silence rather than nothing, so the server's voice
        // activity detection keeps a steady clock.
        onMicChunk(this.muted ? new Int16Array(CHUNK) : chunk);
      }
      pending = merged.slice(off);
    };
    mic.connect(this.tap);
    // Worklets only run while connected to the graph; route through a silent gain.
    const sink = ctx.createGain();
    sink.gain.value = 0;
    this.sink = sink;
    this.tap.connect(sink).connect(ctx.destination);
  }

  play(pcm: Int16Array): void {
    const ctx = this.ctx;
    if (!ctx || pcm.length === 0) return;
    const buf = ctx.createBuffer(1, pcm.length, VOICE_SAMPLE_RATE);
    buf.getChannelData(0).set(int16ToFloat(pcm));
    const src = ctx.createBufferSource();
    src.buffer = buf;
    src.connect(ctx.destination);
    const startAt = Math.max(this.nextTime, ctx.currentTime + 0.03);
    src.start(startAt);
    this.nextTime = startAt + buf.duration;
    this.sources.add(src);
    src.onended = () => this.sources.delete(src);
    this.timeline.push(pcm, VOICE_SAMPLE_RATE, performance.now() + (startAt - ctx.currentTime) * 1000);
  }

  flush(): void {
    for (const s of this.sources) {
      try {
        s.onended = null;
        s.stop();
      } catch {}
    }
    this.sources.clear();
    this.nextTime = 0;
    this.timeline.clear();
  }

  setMuted(muted: boolean): void {
    this.muted = muted;
  }

  outputLevel(): number {
    return this.timeline.levelAt(performance.now());
  }

  inputLevel(): number {
    return this.micLevel;
  }

  isPlaying(): boolean {
    return this.timeline.isPlaying(performance.now());
  }

  isBlocked(): boolean {
    return !!this.ctx && this.ctx.state !== 'running';
  }

  async unblock(): Promise<void> {
    primeAudio();
    await this.ctx?.resume().catch(() => {});
  }

  async stop(): Promise<void> {
    this.flush();
    this.tap?.port.close();
    this.tap?.disconnect();
    this.tap = null;
    this.mic?.disconnect();
    this.mic = null;
    this.sink?.disconnect();
    this.sink = null;
    this.stream?.getTracks().forEach((t) => t.stop());
    this.stream = null;
    // The shared context stays open (and unlocked) for the next lesson.
    this.ctx = null;
  }
}

export function createAudioEngine(): AudioEngine {
  return new WebAudioEngine();
}
