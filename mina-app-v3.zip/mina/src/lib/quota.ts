// When Gemini's free quota runs out we tell the student exactly when they can come back.
// Google resets the daily quota at midnight Pacific time; we show that moment in Israel time.

export type QuotaScope = 'minute' | 'day' | 'unknown';

export interface QuotaInfo {
  scope: QuotaScope;
  /** Seconds Google asked us to wait, when it said. */
  retryAfterSec: number | null;
  /** When the quota was hit (ms). */
  at: number;
}

function parts(date: Date, timeZone: string) {
  const p = new Intl.DateTimeFormat('en-US', {
    timeZone,
    hourCycle: 'h23',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  }).formatToParts(date);
  const get = (t: string) => Number(p.find((x) => x.type === t)?.value);
  return { y: get('year'), m: get('month'), d: get('day'), h: get('hour') % 24, min: get('minute'), s: get('second') };
}

/** Minutes the time zone is ahead of UTC at that moment. */
export function tzOffsetMinutes(date: Date, timeZone: string): number {
  const p = parts(date, timeZone);
  const asUtc = Date.UTC(p.y, p.m - 1, p.d, p.h, p.min, p.s);
  return Math.round((asUtc - Math.floor(date.getTime() / 1000) * 1000) / 60000);
}

/** The next midnight in Los Angeles after `now`. */
export function nextDailyReset(now: Date): Date {
  const tz = 'America/Los_Angeles';
  const p = parts(now, tz);
  const midnightLocalAsUtc = Date.UTC(p.y, p.m - 1, p.d + 1, 0, 0, 0);
  // Two passes so a daylight-saving change at the boundary still lands on midnight.
  let guess = new Date(midnightLocalAsUtc - tzOffsetMinutes(now, tz) * 60000);
  guess = new Date(midnightLocalAsUtc - tzOffsetMinutes(guess, tz) * 60000);
  return guess;
}

/** "10:00" and whether that is today or tomorrow, in Israel time. */
export function israelTime(date: Date, now: Date): { time: string; day: 'היום' | 'מחר' | 'מחרתיים' } {
  const tz = 'Asia/Jerusalem';
  const a = parts(date, tz);
  const b = parts(now, tz);
  const dayDiff = Math.round((Date.UTC(a.y, a.m - 1, a.d) - Date.UTC(b.y, b.m - 1, b.d)) / 86400000);
  const time = `${String(a.h).padStart(2, '0')}:${String(a.min).padStart(2, '0')}`;
  return { time, day: dayDiff <= 0 ? 'היום' : dayDiff === 1 ? 'מחר' : 'מחרתיים' };
}

/** Seconds to wait for a per-minute limit (Google's hint, or a minute). */
export function minuteWait(q: QuotaInfo): number {
  return Math.min(300, Math.max(5, q.retryAfterSec ?? 60));
}

export function formatCountdown(sec: number): string {
  const s = Math.max(0, Math.ceil(sec));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}

export function scopeFromText(text: string): QuotaScope {
  if (/per ?day|daily|PerDay/i.test(text)) return 'day';
  if (/per ?minute|PerMinute/i.test(text)) return 'minute';
  return 'unknown';
}
