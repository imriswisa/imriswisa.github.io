import { useFocusEffect } from 'expo-router';
import { useCallback, useState } from 'react';
import type { SessionRow as BaseRow } from './stats';

export interface SessionRow extends BaseRow {
  lesson_id: string | null;
}
import { supabase } from './supabase';

export interface MistakeRow {
  id: string;
  wrong: string;
  correct: string;
  explanation_he: string | null;
  category: string;
  times_seen: number;
}

export interface VocabRow {
  id: string;
  word: string;
  translation_he: string;
  example: string | null;
}

interface Data {
  loading: boolean;
  error: boolean;
  sessions: SessionRow[];
  mistakes: MistakeRow[];
  vocabulary: VocabRow[];
}

/** Loads the student's history each time a tab comes into focus. */
export function useLearningData(): Data & { reload: () => void } {
  const [data, setData] = useState<Data>({ loading: true, error: false, sessions: [], mistakes: [], vocabulary: [] });

  const load = useCallback(() => {
    let alive = true;
    (async () => {
      const [s, m, v] = await Promise.all([
        supabase.from('lesson_sessions').select('started_at, duration_seconds, lesson_id').order('started_at', { ascending: false }).limit(200),
        supabase.from('mistakes').select('id, wrong, correct, explanation_he, category, times_seen').order('times_seen', { ascending: false }).order('last_seen', { ascending: false }).limit(100),
        supabase.from('vocabulary').select('id, word, translation_he, example').order('created_at', { ascending: false }).limit(300),
      ]);
      if (!alive) return;
      setData({
        loading: false,
        error: !!(s.error || m.error || v.error),
        sessions: (s.data ?? []) as SessionRow[],
        mistakes: (m.data ?? []) as MistakeRow[],
        vocabulary: (v.data ?? []) as VocabRow[],
      });
    })().catch(() => alive && setData((d) => ({ ...d, loading: false, error: true })));
    return () => {
      alive = false;
    };
  }, []);

  useFocusEffect(load);
  return { ...data, reload: load };
}
