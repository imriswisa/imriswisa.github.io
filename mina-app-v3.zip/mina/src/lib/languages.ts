// Languages the app can teach in. `he` is the Hebrew name shown in the app, `en` the
// English name the teacher's instructions use, `rtl` the reading direction.

export interface Language {
  code: string;
  he: string;
  native: string;
  en: string;
  flag: string;
  rtl: boolean;
}

export const LANGUAGES: Language[] = [
  { code: 'he', he: 'עברית', native: 'עברית', en: 'Hebrew', flag: '🇮🇱', rtl: true },
  { code: 'en', he: 'אנגלית', native: 'English', en: 'English', flag: '🇬🇧', rtl: false },
  { code: 'es', he: 'ספרדית', native: 'Español', en: 'Spanish', flag: '🇪🇸', rtl: false },
  { code: 'fr', he: 'צרפתית', native: 'Français', en: 'French', flag: '🇫🇷', rtl: false },
  { code: 'de', he: 'גרמנית', native: 'Deutsch', en: 'German', flag: '🇩🇪', rtl: false },
  { code: 'it', he: 'איטלקית', native: 'Italiano', en: 'Italian', flag: '🇮🇹', rtl: false },
  { code: 'ar', he: 'ערבית', native: 'العربية', en: 'Arabic', flag: '🇸🇦', rtl: true },
  { code: 'ru', he: 'רוסית', native: 'Русский', en: 'Russian', flag: '🇷🇺', rtl: false },
  { code: 'pt', he: 'פורטוגזית', native: 'Português', en: 'Portuguese', flag: '🇧🇷', rtl: false },
];

export function lang(code: string | null | undefined): Language {
  return LANGUAGES.find((l) => l.code === code) ?? LANGUAGES[1];
}

/** Mina's voices (Gemini prebuilt voices). */
export const VOICES = [
  { id: 'Aoede', he: 'אאודה', hint: 'חמה וקלילה' },
  { id: 'Leda', he: 'לדה', hint: 'צעירה ושמחה' },
  { id: 'Kore', he: 'קורה', hint: 'בטוחה וברורה' },
  { id: 'Zephyr', he: 'זפיר', hint: 'אנרגטית ובהירה' },
] as const;
export type VoiceId = (typeof VOICES)[number]['id'];
