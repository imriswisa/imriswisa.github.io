import { useAuth } from '../store/auth';
import { lang } from './languages';

/** The student's languages: what they speak and what they are learning. */
export function useLangs() {
  const native = useAuth((s) => s.profile?.native_language);
  const target = useAuth((s) => s.profile?.target_language);
  return { native: lang(native ?? 'he'), target: lang(target ?? 'en') };
}
