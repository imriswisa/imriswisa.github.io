import React, { useEffect, useRef } from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import Animated, { FadeIn, FadeInDown, LinearTransition } from 'react-native-reanimated';
import { splitHighlights, type BoardBlock } from '../lib/live/tools';
import { useBoard } from '../store/board';
import { useLangs } from '../lib/useLangs';
import { font, radius, useTheme, type Theme } from '../theme';
import { T } from './ui';

/** The board Mina writes on. Its content comes only from her tool calls. */
export function Whiteboard() {
  const t = useTheme();
  const nativeLtr = !useLangs().native.rtl;
  const title = useBoard((s) => s.title);
  const blocks = useBoard((s) => s.blocks);
  const scroll = useRef<React.ComponentRef<typeof ScrollView>>(null);

  useEffect(() => {
    const id = setTimeout(() => scroll.current?.scrollToEnd({ animated: true }), 120);
    return () => clearTimeout(id);
  }, [blocks.length]);

  return (
    <View style={[styles.board, { backgroundColor: t.board, borderColor: t.line }]}>
      <ScrollView ref={scroll} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {blocks.length === 0 ? (
          <T v="soft" center style={{ marginTop: 18, opacity: 0.7 }}>
            הלוח של מינה. מה שהיא מסבירה יופיע כאן.
          </T>
        ) : null}
        {title ? (
          <Animated.View entering={FadeIn.duration(250)}>
            <T v="h2">{title}</T>
          </Animated.View>
        ) : null}
        {blocks.map((b) => (
          // Native-language text uses T, which reads right-to-left; for a left-to-right
          // native language the board flips it below.
          <Animated.View key={b.id} entering={FadeInDown.duration(380)} layout={LinearTransition.duration(220)}>
            <NativeDir.Provider value={nativeLtr}>
              <Block block={b} t={t} />
            </NativeDir.Provider>
          </Animated.View>
        ))}
      </ScrollView>
    </View>
  );
}

function En({ children, t, size = 22, color }: { children: React.ReactNode; t: Theme; size?: number; color?: string }) {
  const rtl = useLangs().target.rtl;
  return (
    <Text
      style={[
        styles.en,
        { fontSize: size, lineHeight: size * 1.35, color: color ?? t.ink },
        rtl && { writingDirection: 'rtl', textAlign: 'right' },
      ]}
    >
      {children}
    </Text>
  );
}

function Highlighted({ text, words, t, size }: { text: string; words?: string[]; t: Theme; size?: number }) {
  return (
    <En t={t} size={size}>
      {splitHighlights(text, words).map((p, i) =>
        p.hit ? (
          <Text key={i} style={{ backgroundColor: t.marker, fontFamily: font.bold }}>
            {p.text}
          </Text>
        ) : (
          p.text
        ),
      )}
    </En>
  );
}

const NativeDir = React.createContext(false);

/** Text in the student's own language. */
function N(props: React.ComponentProps<typeof T>) {
  const ltr = React.useContext(NativeDir);
  return <T {...props} ltr={ltr} />;
}

function Block({ block: b, t }: { block: BoardBlock; t: Theme }) {
  switch (b.kind) {
    case 'word':
      return (
        <View style={[styles.wordCard, { backgroundColor: t.lavender }]}>
          {b.emoji ? <Text style={styles.emoji}>{b.emoji}</Text> : null}
          <View style={{ flex: 1 }}>
            {b.en ? <En t={t} size={28}>{b.en}</En> : null}
            {b.he ? <N v="label">{b.he}</N> : null}
          </View>
        </View>
      );
    case 'sentence':
      return (
        <View style={styles.block}>
          {b.en ? <Highlighted text={b.en} words={b.highlight} t={t} /> : null}
          {b.he ? <N v="soft">{b.he}</N> : null}
        </View>
      );
    case 'rule':
      return (
        <View style={[styles.rule, { backgroundColor: t.butter }]}>
          {b.he ? <N v="label">{b.he}</N> : null}
          {b.en ? <Highlighted text={b.en} words={b.highlight} t={t} size={19} /> : null}
        </View>
      );
    case 'correction':
      return (
        <View style={styles.block}>
          {b.wrong ? (
            <View style={styles.line}>
              <Text style={[styles.mark, { color: t.bad }]}>✗</Text>
              <En t={t} size={20} color={t.bad}>
                <Text style={{ textDecorationLine: 'line-through' }}>{b.wrong}</Text>
              </En>
            </View>
          ) : null}
          {b.en ? (
            <View style={styles.line}>
              <Text style={[styles.mark, { color: t.good }]}>✓</Text>
              <View style={{ flex: 1 }}>
                <Highlighted text={b.en} words={b.highlight} t={t} />
              </View>
            </View>
          ) : null}
          {b.he ? <N v="soft">{b.he}</N> : null}
        </View>
      );
    case 'fill_blank':
      return (
        <View style={[styles.rule, { backgroundColor: t.mint }]}>
          <T v="small">השלימו את החסר</T>
          {b.en ? (
            <En t={t}>
              {b.revealed && b.answer
                ? splitHighlights(b.en.replace(/_{2,}/, b.answer), [b.answer]).map((p, i) =>
                    p.hit ? (
                      <Text key={i} style={{ color: t.good, fontFamily: font.bold }}>
                        {p.text}
                      </Text>
                    ) : (
                      p.text
                    ),
                  )
                : b.en}
            </En>
          ) : null}
          {b.he ? <N v="soft">{b.he}</N> : null}
        </View>
      );
    case 'pronunciation':
      return (
        <View style={[styles.rule, { backgroundColor: t.sky }]}>
          <T v="small">איך אומרים</T>
          {b.en ? <En t={t} size={26}>{b.en}</En> : null}
          {b.he ? <N v="label">{b.he}</N> : null}
        </View>
      );
    case 'word_by_word':
      return (
        <View style={styles.block}>
          <View style={styles.pairs}>
            {(b.pairs ?? []).map((p, i) => (
              <View key={i} style={[styles.pair, { backgroundColor: t.cardAlt }]}>
                <Text style={[styles.en, { fontSize: 18, color: t.ink }]}>{p.en}</Text>
                <Text style={{ fontFamily: font.regular, fontSize: 14, color: t.inkSoft }}>{p.he}</Text>
              </View>
            ))}
          </View>
          {b.he ? <N v="soft">{b.he}</N> : null}
        </View>
      );
    case 'note':
    default:
      return (
        <View style={[styles.note, { borderColor: t.bad }]}>
          <Text style={[styles.arrow, { color: t.bad }]}>↳</Text>
          <View style={{ flex: 1 }}>
            {b.he ? <N style={{ fontStyle: 'italic', color: t.bad }}>{b.he}</N> : null}
            {b.en ? <En t={t} size={18} color={t.bad}>{b.en}</En> : null}
          </View>
        </View>
      );
  }
}

const styles = StyleSheet.create({
  board: { flex: 1, borderRadius: radius.lg, borderWidth: StyleSheet.hairlineWidth, overflow: 'hidden' },
  content: { padding: 18, gap: 14, direction: 'rtl' },
  en: { fontFamily: font.medium, writingDirection: 'ltr', textAlign: 'left' },
  block: { gap: 4 },
  wordCard: { flexDirection: 'row', alignItems: 'center', gap: 14, borderRadius: radius.md, padding: 14 },
  emoji: { fontSize: 40 },
  rule: { borderRadius: radius.md, padding: 14, gap: 6 },
  line: { flexDirection: 'row', alignItems: 'flex-start', gap: 8, direction: 'ltr' },
  mark: { fontSize: 20, fontFamily: font.bold, width: 22, textAlign: 'center' },
  pairs: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, direction: 'ltr' },
  pair: { borderRadius: radius.sm, paddingHorizontal: 10, paddingVertical: 6, alignItems: 'center' },
  note: { flexDirection: 'row', gap: 8, borderRightWidth: 3, paddingRight: 10, transform: [{ rotate: '-0.6deg' }] },
  arrow: { fontSize: 22, fontFamily: font.bold },
});
