import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { formatCountdown, israelTime, minuteWait, nextDailyReset, type QuotaInfo } from '../lib/quota';
import { font, radius, useTheme } from '../theme';
import { Button, T } from './ui';

/**
 * Shown when Gemini's free quota is used up: how long to wait and, for the daily
 * quota, the exact time in Israel when it renews.
 */
export function QuotaWait({ quota, onRetry }: { quota: QuotaInfo; onRetry?: () => void }) {
  const t = useTheme();
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  const reset = nextDailyReset(new Date(quota.at));
  const daily = israelTime(reset, new Date(now));
  const hoursLeft = Math.max(0, (reset.getTime() - now) / 3600000);
  const dailyLine = `המכסה היומית מתחדשת ${daily.day} ב-${daily.time} (שעון ישראל)${hoursLeft >= 1 ? `, בעוד כ-${Math.round(hoursLeft)} שעות` : ''}.`;

  if (quota.scope === 'day') {
    return (
      <View style={[styles.box, { backgroundColor: t.butter }]}>
        <T v="label" center style={{ color: t.ink }}>
          נגמרה המכסה החינמית להיום
        </T>
        <Text style={[styles.big, { color: t.ink }]}>{daily.time}</Text>
        <T center style={{ color: t.ink }}>
          {dailyLine}
        </T>
      </View>
    );
  }

  const left = minuteWait(quota) - (now - quota.at) / 1000;
  const ready = left <= 0;
  return (
    <View style={[styles.box, { backgroundColor: t.butter }]}>
      <T v="label" center style={{ color: t.ink }}>
        {ready ? 'אפשר לנסות שוב' : 'רגע, הגענו למגבלה לדקה. חכו:'}
      </T>
      <Text style={[styles.big, { color: t.ink }]}>{formatCountdown(left)}</Text>
      {quota.scope === 'unknown' ? (
        <T v="small" center style={{ color: t.ink }}>
          אם גם אז זה לא עובד, נגמרה המכסה היומית. {dailyLine}
        </T>
      ) : null}
      {onRetry ? <Button title={ready ? 'לנסות שוב עכשיו' : 'ממתינים…'} disabled={!ready} onPress={onRetry} /> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  box: { borderRadius: radius.lg, padding: 18, gap: 8, alignItems: 'stretch' },
  big: { fontFamily: font.black, fontSize: 48, lineHeight: 58, textAlign: 'center', writingDirection: 'ltr' },
});
