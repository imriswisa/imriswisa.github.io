import React, { useEffect } from 'react';
import Animated, {
  Easing,
  cancelAnimation,
  useAnimatedProps,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withSequence,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import Svg, { Circle, Ellipse, Path } from 'react-native-svg';
import type { Emotion } from '../lib/live/tools';
import { useTheme } from '../theme';

export type TalkState = 'idle' | 'listening' | 'thinking' | 'speaking';

const AnimatedPath = Animated.createAnimatedComponent(Path);
const AnimatedEllipse = Animated.createAnimatedComponent(Ellipse);
const AnimatedCircle = Animated.createAnimatedComponent(Circle);

interface Face {
  eye: number; // eye openness (1 = normal)
  browL: number; // degrees; positive = inner end lower (stern)
  browR: number;
  browY: number; // px; negative = raised
  smile: number; // -1 frown .. 1 big smile
  width: number; // half mouth width
  open: number; // resting mouth openness 0..1
  blush: number;
  tilt: number; // head tilt in degrees
}

const FACES: Record<Emotion, Face> = {
  neutral: { eye: 1, browL: 0, browR: 0, browY: 0, smile: 0.35, width: 17, open: 0, blush: 0.25, tilt: 0 },
  happy: { eye: 0.95, browL: -3, browR: -3, browY: -2, smile: 0.85, width: 22, open: 0.1, blush: 0.5, tilt: 0 },
  laughing: { eye: 0.16, browL: -6, browR: -6, browY: -5, smile: 1, width: 26, open: 0.75, blush: 0.75, tilt: -3 },
  excited: { eye: 1.25, browL: -4, browR: -4, browY: -8, smile: 1, width: 24, open: 0.45, blush: 0.6, tilt: 0 },
  surprised: { eye: 1.4, browL: 0, browR: 0, browY: -11, smile: 0, width: 9, open: 0.85, blush: 0.2, tilt: 0 },
  confused: { eye: 1, browL: -14, browR: 9, browY: -2, smile: -0.2, width: 13, open: 0, blush: 0.15, tilt: 6 },
  annoyed: { eye: 0.55, browL: 17, browR: 17, browY: 5, smile: -0.5, width: 15, open: 0, blush: 0.1, tilt: -2 },
  encouraging: { eye: 1, browL: -6, browR: -6, browY: -5, smile: 0.7, width: 20, open: 0.05, blush: 0.5, tilt: 5 },
};

const SPRING = { damping: 14, stiffness: 160, mass: 0.7 };

/**
 * Mina's face. It is drawn from a handful of animated numbers (eye openness, brow
 * angle, smile, mouth opening...) so every emotion blends smoothly into the next and
 * the mouth can follow the real loudness of her voice.
 */
export function Mina({
  size = 220,
  emotion = 'neutral',
  talk = 'idle',
  getLevel,
}: {
  size?: number;
  emotion?: Emotion;
  talk?: TalkState;
  /** Returns 0..1 loudness of the speech being played right now. */
  getLevel?: () => number;
}) {
  const t = useTheme();
  const eye = useSharedValue(1);
  const blink = useSharedValue(1);
  const browL = useSharedValue(0);
  const browR = useSharedValue(0);
  const browY = useSharedValue(0);
  const smile = useSharedValue(0.35);
  const width = useSharedValue(17);
  const open = useSharedValue(0);
  const blush = useSharedValue(0.25);
  const tilt = useSharedValue(0);
  const lookX = useSharedValue(0);
  const lookY = useSharedValue(0);
  const level = useSharedValue(0);
  const breathe = useSharedValue(0);
  const bounce = useSharedValue(0);

  // Emotion + conversation state -> target face.
  useEffect(() => {
    const f = FACES[emotion];
    const listening = talk === 'listening';
    const thinking = talk === 'thinking';
    eye.value = withSpring(f.eye * (listening ? 1.08 : 1), SPRING);
    browL.value = withSpring(f.browL, SPRING);
    browR.value = withSpring(f.browR, SPRING);
    browY.value = withSpring(f.browY + (listening ? -2 : 0) + (thinking ? -3 : 0), SPRING);
    smile.value = withSpring(f.smile, SPRING);
    width.value = withSpring(f.width, SPRING);
    open.value = withSpring(f.open, SPRING);
    blush.value = withTiming(f.blush, { duration: 300 });
    tilt.value = withSpring(f.tilt + (listening ? -4 : 0) + (thinking ? 3 : 0), SPRING);
    lookX.value = withSpring(thinking ? 5 : 0, SPRING);
    lookY.value = withSpring(thinking ? -5 : 0, SPRING);

    cancelAnimation(bounce);
    if (emotion === 'laughing') {
      bounce.value = withRepeat(withSequence(withTiming(-5, { duration: 110 }), withTiming(0, { duration: 110 })), -1);
    } else if (emotion === 'excited') {
      bounce.value = withRepeat(withSequence(withTiming(-7, { duration: 220 }), withTiming(0, { duration: 220 })), 3);
    } else {
      bounce.value = withTiming(0, { duration: 150 });
    }
  }, [emotion, talk]);

  // She is alive even when nobody speaks: breathing and irregular blinking.
  useEffect(() => {
    breathe.value = withRepeat(withTiming(1, { duration: 2400, easing: Easing.inOut(Easing.sin) }), -1, true);
    let timer: ReturnType<typeof setTimeout>;
    const scheduleBlink = () => {
      timer = setTimeout(() => {
        const double = Math.random() < 0.2;
        const one = [withTiming(0.05, { duration: 70 }), withTiming(1, { duration: 110 })];
        blink.value = withSequence(...(double ? [...one, ...one] : one));
        scheduleBlink();
      }, 2400 + Math.random() * 3200);
    };
    scheduleBlink();
    return () => {
      clearTimeout(timer);
      cancelAnimation(breathe);
    };
  }, []);

  // Lip sync: sample the loudness of the audio that is playing right now.
  useEffect(() => {
    if (!getLevel) return;
    const id = setInterval(() => {
      level.value = withTiming(getLevel(), { duration: 70 });
    }, 40);
    return () => {
      clearInterval(id);
      level.value = 0;
    };
  }, [getLevel]);

  const body = useAnimatedStyle(() => ({
    transform: [
      { translateY: bounce.value },
      { rotate: `${tilt.value}deg` },
      { scale: 1 + breathe.value * 0.018 },
    ],
  }));

  const leftEye = useAnimatedProps(() => ({
    ry: Math.max(0.8, 11 * eye.value * blink.value),
    cx: 72 + lookX.value,
    cy: 94 + lookY.value,
  }));
  const rightEye = useAnimatedProps(() => ({
    ry: Math.max(0.8, 11 * eye.value * blink.value),
    cx: 128 + lookX.value,
    cy: 94 + lookY.value,
  }));
  const glintL = useAnimatedProps(() => ({
    cx: 75 + lookX.value,
    cy: 90 + lookY.value,
    opacity: eye.value * blink.value > 0.5 ? 1 : 0,
  }));
  const glintR = useAnimatedProps(() => ({
    cx: 131 + lookX.value,
    cy: 90 + lookY.value,
    opacity: eye.value * blink.value > 0.5 ? 1 : 0,
  }));

  const leftBrow = useAnimatedProps(() => {
    const dy = Math.sin((browL.value * Math.PI) / 180) * 11;
    const y = 70 + browY.value;
    return { d: `M 60 ${y - dy} Q 72 ${y - 3} 84 ${y + dy}` };
  });
  const rightBrow = useAnimatedProps(() => {
    const dy = Math.sin((browR.value * Math.PI) / 180) * 11;
    const y = 70 + browY.value;
    return { d: `M 116 ${y + dy} Q 128 ${y - 3} 140 ${y - dy}` };
  });

  const mouth = useAnimatedProps(() => {
    const o = Math.min(1, open.value + level.value * 0.9);
    const w = width.value * (1 - level.value * 0.12);
    const y = 133;
    const upper = y + smile.value * 9 - o * 3;
    const lower = y + smile.value * 9 + o * 30 + Math.max(0, smile.value) * 5;
    return { d: `M ${100 - w} ${y} Q 100 ${upper} ${100 + w} ${y} Q 100 ${lower} ${100 - w} ${y} Z` };
  });

  const cheeks = useAnimatedProps(() => ({ opacity: blush.value }));

  return (
    <Animated.View
      accessible
      accessibilityRole="image"
      accessibilityLabel="מינה, המורה"
      style={[{ width: size, height: size }, body]}
    >
      <Svg width={size} height={size} viewBox="0 0 200 200">
        {/* hair curl */}
        <Path d="M 96 30 C 92 12 118 8 114 26 C 112 34 102 34 104 26" stroke={t.minaInk} strokeWidth={5} strokeLinecap="round" fill="none" />
        {/* head */}
        <Path
          d="M 100 28 C 150 28 178 58 178 106 C 178 152 148 180 100 180 C 52 180 22 152 22 106 C 22 58 50 28 100 28 Z"
          fill={t.mina}
        />
        <AnimatedCircle cx={54} cy={120} r={13} fill="#FF9FB0" animatedProps={cheeks} />
        <AnimatedCircle cx={146} cy={120} r={13} fill="#FF9FB0" animatedProps={cheeks} />
        <AnimatedEllipse rx={8.5} fill={t.minaInk} animatedProps={leftEye} />
        <AnimatedEllipse rx={8.5} fill={t.minaInk} animatedProps={rightEye} />
        <AnimatedCircle r={2.6} fill="#FFFFFF" animatedProps={glintL} />
        <AnimatedCircle r={2.6} fill="#FFFFFF" animatedProps={glintR} />
        <AnimatedPath stroke={t.minaInk} strokeWidth={5} strokeLinecap="round" fill="none" animatedProps={leftBrow} />
        <AnimatedPath stroke={t.minaInk} strokeWidth={5} strokeLinecap="round" fill="none" animatedProps={rightBrow} />
        <AnimatedPath
          fill={t.minaInk}
          stroke={t.minaInk}
          strokeWidth={5}
          strokeLinejoin="round"
          strokeLinecap="round"
          animatedProps={mouth}
        />
      </Svg>
    </Animated.View>
  );
}
