import * as Haptics from 'expo-haptics';
import React from 'react';
import {
  ActivityIndicator,
  Platform,
  Pressable,
  ScrollView,
  StyleProp,
  StyleSheet,
  Text,
  TextProps,
  TextStyle,
  View,
  ViewStyle,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { font, radius, useTheme } from '../theme';

export function tap() {
  if (Platform.OS !== 'web') Haptics.selectionAsync().catch(() => {});
}

type Variant = 'body' | 'soft' | 'title' | 'h2' | 'label' | 'small';

/** App text: Heebo, right-to-left by default (pass ltr for English content). */
export function T({
  v = 'body',
  ltr,
  center,
  style,
  ...rest
}: TextProps & { v?: Variant; ltr?: boolean; center?: boolean }) {
  const t = useTheme();
  const base: Record<Variant, TextStyle> = {
    body: { fontFamily: font.regular, fontSize: 17, lineHeight: 26, color: t.ink },
    soft: { fontFamily: font.regular, fontSize: 15, lineHeight: 22, color: t.inkSoft },
    small: { fontFamily: font.medium, fontSize: 13, lineHeight: 18, color: t.inkSoft },
    label: { fontFamily: font.medium, fontSize: 16, lineHeight: 22, color: t.ink },
    h2: { fontFamily: font.bold, fontSize: 21, lineHeight: 28, color: t.ink },
    title: { fontFamily: font.black, fontSize: 32, lineHeight: 40, color: t.ink },
  };
  return (
    <Text
      {...rest}
      style={[
        base[v],
        { writingDirection: ltr ? 'ltr' : 'rtl', textAlign: center ? 'center' : ltr ? 'left' : 'right' },
        style,
      ]}
    />
  );
}

export function Screen({
  children,
  scroll = true,
  style,
}: {
  children: React.ReactNode;
  scroll?: boolean;
  style?: StyleProp<ViewStyle>;
}) {
  const t = useTheme();
  const insets = useSafeAreaInsets();
  const pad = { paddingTop: insets.top + 18, paddingBottom: insets.bottom + 28, paddingHorizontal: 20 };
  if (!scroll) {
    return <View style={[styles.rtl, { flex: 1, backgroundColor: t.bg }, pad, style]}>{children}</View>;
  }
  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: t.bg }}
      contentContainerStyle={[styles.rtl, styles.column, pad, style]}
      keyboardShouldPersistTaps="handled"
      showsVerticalScrollIndicator={false}
    >
      {children}
    </ScrollView>
  );
}

export function Card({
  children,
  color,
  onPress,
  style,
  label,
}: {
  children: React.ReactNode;
  color?: string;
  onPress?: () => void;
  style?: StyleProp<ViewStyle>;
  label?: string;
}) {
  const t = useTheme();
  const body = [styles.card, { backgroundColor: color ?? t.card, borderColor: t.line }, style];
  if (!onPress) return <View style={body}>{children}</View>;
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      onPress={() => {
        tap();
        onPress();
      }}
      style={({ pressed }) => [body, pressed && { transform: [{ scale: 0.985 }], opacity: 0.92 }]}
    >
      {children}
    </Pressable>
  );
}

export function Button({
  title,
  onPress,
  kind = 'primary',
  disabled,
  busy,
  style,
}: {
  title: string;
  onPress: () => void;
  kind?: 'primary' | 'ghost' | 'danger';
  disabled?: boolean;
  busy?: boolean;
  style?: StyleProp<ViewStyle>;
}) {
  const t = useTheme();
  const bg = kind === 'primary' ? t.primary : kind === 'danger' ? t.bad : 'transparent';
  const fg = kind === 'ghost' ? t.ink : kind === 'danger' ? '#FFFFFF' : t.onPrimary;
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ disabled: !!disabled || !!busy, busy: !!busy }}
      disabled={disabled || busy}
      onPress={() => {
        tap();
        onPress();
      }}
      style={({ pressed }) => [
        styles.button,
        { backgroundColor: bg, borderColor: kind === 'ghost' ? t.line : bg, opacity: disabled ? 0.4 : pressed ? 0.85 : 1 },
        style,
      ]}
    >
      {busy ? (
        <ActivityIndicator color={fg} />
      ) : (
        <Text style={{ fontFamily: font.bold, fontSize: 17, color: fg }}>{title}</Text>
      )}
    </Pressable>
  );
}

export function Chip({
  label,
  selected,
  onPress,
  color,
}: {
  label: string;
  selected?: boolean;
  onPress?: () => void;
  color?: string;
}) {
  const t = useTheme();
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ selected: !!selected }}
      disabled={!onPress}
      onPress={() => {
        tap();
        onPress?.();
      }}
      style={[
        styles.chip,
        { backgroundColor: selected ? t.primary : color ?? t.card, borderColor: selected ? t.primary : t.line },
      ]}
    >
      <Text style={{ fontFamily: font.medium, fontSize: 15, color: selected ? t.onPrimary : t.ink }}>{label}</Text>
    </Pressable>
  );
}

export function Row({ children, style }: { children: React.ReactNode; style?: StyleProp<ViewStyle> }) {
  return <View style={[styles.row, style]}>{children}</View>;
}

export function Notice({ text, tone = 'info' }: { text: string; tone?: 'info' | 'bad' }) {
  const t = useTheme();
  return (
    <View
      accessibilityRole="alert"
      style={[styles.notice, { backgroundColor: tone === 'bad' ? t.peach : t.sky }]}
    >
      <T v="soft" style={{ color: t.ink }}>
        {text}
      </T>
    </View>
  );
}

const styles = StyleSheet.create({
  rtl: { direction: 'rtl' },
  column: { gap: 14, flexGrow: 1 },
  card: { borderRadius: radius.lg, padding: 18, borderWidth: StyleSheet.hairlineWidth, gap: 6 },
  button: {
    minHeight: 54,
    borderRadius: radius.pill,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 22,
    borderWidth: 1,
  },
  chip: { paddingHorizontal: 16, paddingVertical: 10, borderRadius: radius.pill, borderWidth: 1 },
  row: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, alignItems: 'center' },
  notice: { borderRadius: radius.md, padding: 14 },
});
