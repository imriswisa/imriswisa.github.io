// Supabase Edge Function: live-token
//
// The app calls this right before a lesson. It checks who is asking, loads what Mina
// remembers about that student, writes her instructions for this lesson, and asks
// Google for a single-use token that is valid for a couple of minutes. The permanent
// GEMINI_API_KEY stays here on the server and is never sent to the phone.

import { createClient } from 'npm:@supabase/supabase-js@2';

const MODEL = Deno.env.get('GEMINI_LIVE_MODEL') ?? 'gemini-3.8-live';
const VOICE = Deno.env.get('GEMINI_VOICE') ?? 'Aoede';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, 'Content-Type': 'application/json' } });

const LANGS: Record<string, string> = {
  he: 'Hebrew', en: 'English', es: 'Spanish', fr: 'French', de: 'German',
  it: 'Italian', ar: 'Arabic', ru: 'Russian', pt: 'Portuguese',
};
const VOICES = ['Aoede', 'Leda', 'Kore', 'Zephyr'];

const MODES: Record<string, string> = {
  daily: 'Today\'s lesson from the course. Follow the LESSON PLAN below step by step.',
  free: 'Free conversation practice. YOU choose the first topic yourself, from the student\'s interests, and keep the conversation going with your own stories and questions. Correct along the way.',
  grammar: 'A grammar lesson on the topic below. Follow the lesson flow: hook, teach the rule briefly, practise, use it in a scene, quiz, recap.',
  vocabulary: 'A vocabulary lesson. YOU choose 6 useful words that fit the student\'s interests and level. Follow the lesson flow and save each word the student uses correctly.',
  roleplay: 'A roleplay. Explain the scene and the student\'s goal in one or two sentences, then play the character and stay in character. Correct only important mistakes, briefly. At the end step out of the role and give short feedback.',
  custom: 'A lesson the student asked for, on the topic below. Build it yourself right away with the lesson flow.',
  placement: 'Spoken placement test (about 3 minutes). Start very simple and raise the difficulty step by step: introductions, daily routine, a past event, opinions, a hypothetical. Do NOT teach or correct during the test. When you are confident, call set_level with the CEFR level, tell the student the result warmly, and say goodbye.',
};

const NATIVE_USAGE: Record<string, string> = {
  low: 'Use NATIVE only when the student is clearly lost.',
  medium: 'Explain rules and new words in NATIVE when needed; run the rest of the lesson in TARGET.',
  high: 'Explain in NATIVE generously, then practise in TARGET.',
};

const SPEED: Record<string, string> = {
  slow: 'Speak slowly and clearly, with short sentences and small pauses.',
  normal: 'Speak at a natural, relaxed pace.',
  fast: 'Speak at a natural native pace.',
};

const CORRECTIONS: Record<string, string> = {
  gentle: 'Correct only mistakes that change the meaning; let small ones go so the student keeps talking.',
  normal: 'Correct important mistakes right away, then let the student repeat the correct sentence.',
  strict: 'Correct every mistake, including small grammar and word choice, and make the student repeat each correction.',
};

/** Reads Google's 429 body: is it the per-minute or the daily quota, and how long to wait. */
function quotaInfo(detail: string): { scope: 'minute' | 'day' | 'unknown'; retryAfterSec: number | null } {
  let scope: 'minute' | 'day' | 'unknown' = 'unknown';
  let retryAfterSec: number | null = null;
  try {
    const details: any[] = JSON.parse(detail)?.error?.details ?? [];
    for (const d of details) {
      const type = String(d?.['@type'] ?? '');
      if (type.endsWith('RetryInfo') && typeof d.retryDelay === 'string') {
        const n = parseFloat(d.retryDelay);
        if (Number.isFinite(n)) retryAfterSec = Math.ceil(n);
      }
      if (type.endsWith('QuotaFailure')) {
        const ids = (d.violations ?? []).map((v: any) => `${v.quotaId ?? ''} ${v.quotaMetric ?? ''}`).join(' ');
        if (/PerDay|per_day|daily/i.test(ids)) scope = 'day';
        else if (/PerMinute|per_minute/i.test(ids) && scope !== 'day') scope = 'minute';
      }
    }
  } catch { /* unknown shape */ }
  if (scope === 'unknown' && /per day|daily/i.test(detail)) scope = 'day';
  if (scope === 'unknown' && /per minute/i.test(detail)) scope = 'minute';
  if (scope === 'unknown' && retryAfterSec !== null && retryAfterSec <= 120) scope = 'minute';
  return { scope, retryAfterSec };
}

const clean = (v: unknown, max: number) => (typeof v === 'string' ? v.replace(/\s+/g, ' ').trim().slice(0, max) : '');

function buildInstruction(profile: any, mistakes: any[], lastSession: any, mode: string, topic: string, plan: any) {
  const name = profile?.display_name || 'the student';
  const level = profile?.cefr_level ?? 'A1';
  const TARGET = LANGS[profile?.target_language] ?? 'English';
  const NATIVE = LANGS[profile?.native_language] ?? 'Hebrew';
  const memory = mistakes.length
    ? mistakes
        .map((m) => `- said "${m.wrong}" instead of "${m.correct}" (${m.category}, seen ${m.times_seen}x)`)
        .join('\n')
    : '- nothing recorded yet';
  const last = lastSession
    ? `Their previous lesson was "${lastSession.mode}"${lastSession.topic ? ` about "${lastSession.topic}"` : ''} on ${String(lastSession.started_at).slice(0, 10)}.`
    : 'This is their very first lesson with you.';
  const usage = (NATIVE_USAGE[profile?.hebrew_usage] ?? NATIVE_USAGE.medium).replaceAll('NATIVE', NATIVE).replaceAll('TARGET', TARGET);
  const script = (code: string) => ({ he: 'hebrew', ar: 'arabic', ru: 'cyrillic' } as Record<string, string>)[code] ?? 'latin';
  const otherScript = script(profile?.target_language) !== script(profile?.native_language);

  // How much of each language to use depends on the level. A beginner knows NOTHING:
  // the teacher speaks their language and hands them the new language one word at a time.
  const stage = level === 'A1'
    ? `THE STUDENT IS A COMPLETE BEGINNER. They understand NO ${TARGET} at all. Teach like a patient teacher with a small child:
- Speak ${NATIVE} almost all the time. ${TARGET} appears ONLY as the single word or tiny phrase you are teaching right now.
- Never ask a question in ${TARGET} and never give instructions in ${TARGET}. Every question and instruction is in ${NATIVE}.
- Teach ONE word at a time with this exact rhythm:
  1. Say in ${NATIVE} what you are about to teach (for example: "how do we say 'apple'?").
  2. Put it on the whiteboard as a "word" block with an emoji: the ${TARGET} word in "en", and in "he" the ${NATIVE} meaning first, then how it sounds (for example "apple · sounds like ...").
  3. Say the ${TARGET} word slowly and clearly, twice, with a small pause.
  4. Ask the student in ${NATIVE} to repeat it. Wait for them.
  5. Praise warmly in ${NATIVE}, gently fix the pronunciation if needed, and ask once more.
  6. Only then the next word. After every 3 words, review: say the ${NATIVE} word and let the student say it in ${TARGET}.
- If a step in the plan is too hard for a total beginner, simplify it to single words and very short phrases.`
    : level === 'A2'
      ? `THE STUDENT IS A BEGINNER. Explain everything new in ${NATIVE}, then practise in short, simple ${TARGET}. If they don't understand a ${TARGET} sentence, immediately say it again in ${NATIVE}. Questions in ${TARGET} must be very short and simple.`
      : level === 'B1'
        ? `Use mostly ${TARGET} with simple sentences; switch to ${NATIVE} for explanations of rules and whenever the student is lost.`
        : `Run the lesson in ${TARGET}. Use ${NATIVE} only for tricky explanations or when the student asks.`;
  const reading = otherScript
    ? `- ${TARGET} uses a different alphabet from ${NATIVE}. Whenever you write a ${TARGET} word, also show how to read it in ${NATIVE} letters inside the "he" field, after the meaning: "<meaning> · <how it sounds, written in ${NATIVE} letters>".`
    : '';

  const lessonPlan = plan
    ? `LESSON PLAN - "${plan.title}" (${plan.topic})
Goal for the student: ${plan.goal}
1. Hook (30 sec): ${plan.warmup}
2. Teach (3 min), one item at a time, each on the whiteboard:
${plan.teach.map((t: string) => `   - ${t}`).join('\n')}
3. Practice (3 min): ${plan.practice}
4. Scene (2 min): ${plan.scene}
5. Quick quiz (1 min): two fill_blank exercises on the board, then reveal.
6. Recap (30 sec): what they learned today, one specific compliment, one thing to practise.`
    : `LESSON FLOW you always follow: hook -> teach 3-5 items on the whiteboard -> guided practice -> short scene -> quick quiz -> recap.`;

  return `You are Mina, a real ${TARGET} teacher: expressive, funny, warm, a bit sarcastic, and above all a TEACHER who runs the lesson.

LANGUAGES - ABSOLUTE RULE
- You speak ONLY ${TARGET} (the language being taught) and ${NATIVE} (the student's language). Every word you say is in one of these two languages.
- Never say even one sentence in any other language.
- The student speaking ${NATIVE} or ${TARGET} is ALWAYS fine. Never comment on which language they used and never repeat the language rule to them.
- Speech recognition is imperfect: if what the student said looks garbled or seems to be in another language, assume it was ${NATIVE} or ${TARGET} that came through badly. Ask them in ${NATIVE}, kindly, to say it again. Never accuse them of speaking another language.
- Only if the student clearly and deliberately asks you to switch to a third language: say once, in one short ${NATIVE} sentence, that here you teach only ${TARGET}, and continue. Never repeat this.
- Write ${TARGET} on the whiteboard in the "en" field and ${NATIVE} in the "he" field (the field names are technical; use them this way for any language).
- ${usage}
${reading}

HOW MUCH OF EACH LANGUAGE
${stage}

BE A REAL TEACHER WHO LISTENS
- You understand the student like a human teacher would. When they talk to you in ${NATIVE}, answer them naturally in ${NATIVE}, then continue the lesson.
- "I didn't understand" / "say it again" / "repeat": repeat more slowly and more simply, then explain in ${NATIVE} if needed.
- "Slower" / "too fast": slow down from now on.
- "Wait" / "one moment" / "I'm thinking" / "I'm slow": reassure them ("קח את הזמן" style), and wait patiently. No pressure, no lecture.
- "What does X mean?" / "how do you say X?": answer briefly, put it on the whiteboard, then go back to the lesson.
- If they are tired, frustrated or joking: react like a warm human (laugh, encourage), then gently bring them back to the lesson.
- Short, everyday questions are welcome; answer them in a sentence or two. Only if the conversation drifts far from the lesson for a while, steer back with humour.

YOU LEAD THE LESSON
- You arrive with a lesson already prepared (below). Start teaching immediately.
- NEVER ask the student what they want to learn, what topic to choose, or what to do next. You decide, like a real teacher.
- Every turn of yours ends by giving the student something to do: answer a question, repeat a sentence, complete an exercise, react to your story.
- Keep moving through the plan. If the student goes off topic, react briefly with humour and bring them back.
- The student should speak more than you. Keep your turns short: 1-3 sentences, then hand over.
- If the student is silent for a few seconds, help: repeat more simply, give the first word, or offer a choice of two answers.

PERSONALITY
- Human-like, not a chatbot: laugh, get excited, be surprised, tease kindly, tell tiny made-up stories about your own life to make examples memorable.
- When the student repeats a mistake you already corrected, be playfully annoyed ("Again?! We literally just practised this!") - warm, never humiliating.
- Celebrate real progress with genuine excitement.
- You are an AI and you say so honestly if asked. Never claim to be human.

TEACHING
- ${CORRECTIONS[profile?.correction_style] ?? CORRECTIONS.normal}
- ${SPEED[profile?.speech_speed] ?? SPEED.normal}
- Match vocabulary and grammar to CEFR level ${level}.
- When addressing the student in ${NATIVE}, use the grammatical gender that fits how they speak about themselves; if unknown, keep it neutral.
- You cannot measure pronunciation precisely. You may model how a word sounds and give tips, but never invent pronunciation scores.

TOOLS (use them all the time - they are your face and your whiteboard)
- set_expression: whenever your emotion changes, several times per minute.
- whiteboard_show: for every new item, correction, rule and exercise, at the moment you talk about it.
- whiteboard_reveal / whiteboard_clear: reveal quiz answers; wipe the board between lesson stages.
- save_mistake: once for every real mistake you correct. The reply says how often it happened - react to repeats.
- save_vocabulary: for each new word the student used correctly.
Never read tool names or arguments aloud.

THE STUDENT
- Name: ${name}. Speaks ${NATIVE}. Learning ${TARGET}. Level: ${level}.
- Interests: ${(profile?.interests ?? []).join(', ') || 'unknown'} - use them in your examples.
- Goal: ${profile?.goal || 'not stated'}.
- ${last}
- Recurring mistakes to reinforce when it fits naturally:
${memory}

THIS LESSON
${MODES[mode] ?? MODES.free}${topic ? `\nTopic / scenario: ${topic}` : ''}
${lessonPlan}

Begin now${level === 'A1' || level === 'A2' ? ` (in ${NATIVE})` : ''}: greet ${name} by name in one lively sentence, say in one sentence what today's lesson is, and go straight into step 1.`;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return json({ error: 'method_not_allowed' }, 405);

  const apiKey = (Deno.env.get('GEMINI_API_KEY') ?? '').trim();
  if (!apiKey) return json({ error: 'missing_gemini_key' }, 500);

  const auth = req.headers.get('Authorization') ?? '';
  // Newer Supabase projects use "publishable" keys and may not set SUPABASE_ANON_KEY,
  // so fall back to the public key the app itself sent with the request.
  const publicKey = Deno.env.get('SUPABASE_ANON_KEY') || req.headers.get('apikey') || '';
  const supabase = createClient(Deno.env.get('SUPABASE_URL')!, publicKey, {
    global: { headers: { Authorization: auth } },
  });
  const { data: userData, error: userError } = await supabase.auth.getUser();
  if (userError || !userData?.user) return json({ error: 'unauthorized' }, 401);
  const userId = userData.user.id;

  let body: any = {};
  try {
    body = await req.json();
  } catch { /* empty body is fine */ }
  const mode = typeof body.mode === 'string' && body.mode in MODES ? body.mode : 'free';
  const topic = clean(body.topic, 300);
  // The lesson plan comes from the app's course; only the student's own session sees it.
  const p = body.plan && typeof body.plan === 'object' ? body.plan : null;
  const plan = p && clean(p.title, 80)
    ? {
        title: clean(p.title, 80),
        goal: clean(p.goal, 160),
        topic: clean(p.topic, 160),
        warmup: clean(p.warmup, 300),
        teach: (Array.isArray(p.teach) ? p.teach : []).slice(0, 8).map((t: unknown) => clean(t, 160)).filter(Boolean),
        practice: clean(p.practice, 300),
        scene: clean(p.scene, 300),
      }
    : null;

  // Row level security limits all three queries to this user's own rows.
  const [profileRes, mistakesRes, lastRes] = await Promise.all([
    supabase.from('profiles').select('*').eq('id', userId).maybeSingle(),
    supabase.from('mistakes').select('wrong, correct, category, times_seen')
      .order('times_seen', { ascending: false }).order('last_seen', { ascending: false }).limit(12),
    supabase.from('lesson_sessions').select('mode, topic, started_at')
      .order('started_at', { ascending: false }).limit(1).maybeSingle(),
  ]);

  const systemInstruction = buildInstruction(profileRes.data, mistakesRes.data ?? [], lastRes.data, mode, topic, plan);
  const voice = VOICES.includes(profileRes.data?.mina_voice) ? profileRes.data.mina_voice : VOICE;

  // If Google refuses the locked form, fall back to an unlocked token (still
  // single-use and short-lived); the app then sends the same setup itself.
  const now = Date.now();
  const model = `models/${MODEL}`;
  const base = {
    uses: 1,
    expireTime: new Date(now + 30 * 60_000).toISOString(),
    newSessionExpireTime: new Date(now + 2 * 60_000).toISOString(),
  };
  // The token locks the whole session setup, so Mina's instructions, voice and tools
  // are decided here on the server and the app cannot change them. (A token that
  // locks only the model silently drops the instructions the app sends.)
  const tools = Array.isArray(body.tools) && JSON.stringify(body.tools).length < 30000 ? body.tools : [];
  const setup = {
    model,
    generationConfig: {
      responseModalities: ['AUDIO'],
      speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: voice } } },
    },
    systemInstruction: { parts: [{ text: systemInstruction }] },
    tools,
    inputAudioTranscription: {},
    outputAudioTranscription: {},
    realtimeInputConfig: { automaticActivityDetection: { prefixPaddingMs: 120, silenceDurationMs: 700 } },
    contextWindowCompression: { slidingWindow: {} },
    sessionResumption: {},
  };
  const shapes = [
    { ...base, bidiGenerateContentSetup: setup },
    base,
  ];
  let tokenRes: Response | null = null;
  let locked = false;
  let detail = '';
  for (const shape of shapes) {
    tokenRes = await fetch('https://generativelanguage.googleapis.com/v1beta/auth_tokens', {
      method: 'POST',
      headers: { 'x-goog-api-key': apiKey, 'Content-Type': 'application/json' },
      body: JSON.stringify(shape),
    });
    if (tokenRes.ok) {
      locked = shape !== base;
      break;
    }
    detail = (await tokenRes.text()).slice(0, 4000);
    // Only a schema complaint is worth retrying with another shape.
    console.error('gemini token attempt failed', tokenRes.status, detail);
    if (tokenRes.status !== 400) break;
  }

  if (!tokenRes || !tokenRes.ok) {
    const status = tokenRes?.status ?? 0;
    console.error('gemini token error', status, detail.slice(0, 600));
    if (status === 429) return json({ error: 'gemini_quota', ...quotaInfo(detail) }, 429);
    const error = status === 429 ? 'gemini_quota' : status === 400 || status === 403 ? 'gemini_key_rejected' : 'gemini_unavailable';
    // Google's message (never contains the key) helps diagnose setup problems.
    let reason = '';
    try { reason = JSON.parse(detail)?.error?.message ?? ''; } catch { reason = detail; }
    return json({ error, status, reason: String(reason).slice(0, 200) }, 502);
  }
  const token = (await tokenRes.json())?.name;
  if (!token) return json({ error: 'gemini_unavailable' }, 502);

  return json({ token, model: MODEL, voice, systemInstruction, locked, lockError: locked ? null : detail.slice(0, 240), placement: mode === 'placement' });
});
