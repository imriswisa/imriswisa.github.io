-- Mina v2: chosen languages, teacher voice, correction style, and which lesson was taught.
alter table public.profiles add column if not exists mina_voice text not null default 'Aoede';
alter table public.profiles add column if not exists correction_style text not null default 'normal';
alter table public.lesson_sessions add column if not exists lesson_id text;

alter table public.profiles drop constraint if exists profiles_correction_style_check;
alter table public.profiles add constraint profiles_correction_style_check
  check (correction_style in ('gentle','normal','strict'));
alter table public.profiles drop constraint if exists profiles_languages_check;
alter table public.profiles add constraint profiles_languages_check
  check (native_language <> target_language);
