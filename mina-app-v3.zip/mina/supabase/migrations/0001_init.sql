-- Mina: learning memory. Every table is private to its owner through row level security.

create table if not exists public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  display_name text,
  native_language text not null default 'he',
  target_language text not null default 'en',
  cefr_level text not null default 'A1' check (cefr_level in ('A1','A2','B1','B2','C1','C2')),
  interests text[] not null default '{}',
  goal text,
  daily_minutes int not null default 10 check (daily_minutes between 5 and 60),
  hebrew_usage text not null default 'medium' check (hebrew_usage in ('low','medium','high')),
  speech_speed text not null default 'normal' check (speech_speed in ('slow','normal','fast')),
  onboarded boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.lesson_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  mode text not null,
  topic text,
  started_at timestamptz not null default now(),
  duration_seconds int not null default 0 check (duration_seconds >= 0),
  mistakes_count int not null default 0,
  vocabulary_count int not null default 0,
  transcript jsonb not null default '[]'::jsonb
);
create index if not exists lesson_sessions_user_time on public.lesson_sessions (user_id, started_at desc);

create table if not exists public.mistakes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  wrong text not null,
  correct text not null,
  explanation_he text,
  category text not null default 'other',
  times_seen int not null default 1,
  first_seen timestamptz not null default now(),
  last_seen timestamptz not null default now()
);
create unique index if not exists mistakes_dedupe on public.mistakes (user_id, lower(correct), category);

create table if not exists public.vocabulary (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  word text not null,
  translation_he text not null,
  example text,
  created_at timestamptz not null default now()
);
create unique index if not exists vocabulary_dedupe on public.vocabulary (user_id, lower(word));

alter table public.profiles enable row level security;
alter table public.lesson_sessions enable row level security;
alter table public.mistakes enable row level security;
alter table public.vocabulary enable row level security;

drop policy if exists "own profile" on public.profiles;
create policy "own profile" on public.profiles for all
  using ((select auth.uid()) = id) with check ((select auth.uid()) = id);

drop policy if exists "own sessions" on public.lesson_sessions;
create policy "own sessions" on public.lesson_sessions for all
  using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);

drop policy if exists "own mistakes" on public.mistakes;
create policy "own mistakes" on public.mistakes for all
  using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);

drop policy if exists "own vocabulary" on public.vocabulary;
create policy "own vocabulary" on public.vocabulary for all
  using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);

-- A profile row appears automatically when someone signs up.
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id) values (new.id) on conflict (id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- Record a mistake; if the student already made it, count the repeat instead.
-- Returns how many times it has now been seen, so the teacher can react to repeats.
create or replace function public.log_mistake(
  p_wrong text, p_correct text, p_explanation_he text, p_category text
) returns int
language plpgsql security invoker set search_path = '' as $$
declare
  seen int;
begin
  if (select auth.uid()) is null then
    raise exception 'not authenticated';
  end if;
  insert into public.mistakes (user_id, wrong, correct, explanation_he, category)
  values ((select auth.uid()), left(p_wrong, 400), left(p_correct, 400), left(p_explanation_he, 400), coalesce(p_category, 'other'))
  on conflict (user_id, lower(correct), category)
  do update set times_seen = public.mistakes.times_seen + 1,
                last_seen = now(),
                wrong = excluded.wrong,
                explanation_he = coalesce(excluded.explanation_he, public.mistakes.explanation_he)
  returning times_seen into seen;
  return seen;
end $$;

revoke all on function public.log_mistake(text, text, text, text) from public, anon;
grant execute on function public.log_mistake(text, text, text, text) to authenticated;
revoke all on function public.handle_new_user() from public, anon, authenticated;
