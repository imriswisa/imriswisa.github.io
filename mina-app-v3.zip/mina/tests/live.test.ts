import assert from 'node:assert/strict';
import { once } from 'node:events';
import { test } from 'node:test';
import { WebSocketServer, type WebSocket as ServerSocket } from 'ws';
import { bytesToBase64, int16ToBytes } from '../src/lib/audio/pcm';
import { GeminiLiveClient, type LiveCallbacks, type LiveFailure } from '../src/lib/live/GeminiLiveClient';

// A stand-in for the Gemini Live endpoint that speaks the same JSON protocol, so the
// client's framing, tool round-trip and reconnection can be checked without a key.
async function mockServer() {
  const wss = new WebSocketServer({ port: 0 });
  await once(wss, 'listening');
  const port = (wss.address() as any).port;
  const RealWS = globalThis.WebSocket;
  const urls: string[] = [];
  (globalThis as any).WebSocket = class extends RealWS {
    constructor(url: string) {
      urls.push(url);
      super(`ws://127.0.0.1:${port}/${url.includes('?') ? url.slice(url.indexOf('?')) : ''}`);
    }
  };
  return {
    wss,
    urls,
    nextConnection: () => once(wss, 'connection').then(([s]) => s as ServerSocket),
    close: async () => {
      (globalThis as any).WebSocket = RealWS;
      for (const c of wss.clients) c.terminate();
      await new Promise((r) => wss.close(r));
    },
  };
}

const nextMessage = (s: ServerSocket) => once(s, 'message').then(([d]) => JSON.parse(String(d)));
const tick = (ms = 30) => new Promise((r) => setTimeout(r, ms));

function recorder() {
  const log: string[] = [];
  const audio: Int16Array[] = [];
  const tools: any[] = [];
  let fatal: LiveFailure | null = null;
  const cb: LiveCallbacks = {
    onReady: () => log.push('ready'),
    onAudio: (p) => audio.push(p),
    onInterrupted: () => log.push('interrupted'),
    onTurnComplete: () => log.push('turn'),
    onUserText: (t) => log.push(`user:${t}`),
    onTeacherText: (t) => log.push(`mina:${t}`),
    onToolCalls: (c) => tools.push(...c),
    onReconnecting: (n) => log.push(`reconnecting:${n}`),
    onFatal: (f) => {
      fatal = f;
      log.push(`fatal:${f.kind}`);
    },
  };
  return { cb, log, audio, tools, getFatal: () => fatal };
}

const SETUP = { model: 'gemini-3.8-live', voice: 'Aoede', systemInstruction: 'You are Mina.', tools: [{ functionDeclarations: [] }] };

test('handshake, audio both ways, transcripts, tools, interruption', async () => {
  const srv = await mockServer();
  const r = recorder();
  const client = new GeminiLiveClient('auth_tokens/abc 123', SETUP, r.cb);
  const conn = srv.nextConnection();
  client.connect();
  const sock = await conn;

  // The token goes in the access_token query parameter of the constrained endpoint.
  assert.match(srv.urls[0], /BidiGenerateContentConstrained\?access_token=auth_tokens%2Fabc%20123$/);

  const setup = (await nextMessage(sock)).setup;
  assert.equal(setup.model, 'models/gemini-3.8-live');
  assert.deepEqual(setup.generationConfig.responseModalities, ['AUDIO']);
  assert.equal(setup.generationConfig.speechConfig.voiceConfig.prebuiltVoiceConfig.voiceName, 'Aoede');
  assert.equal(setup.systemInstruction.parts[0].text, 'You are Mina.');
  assert.deepEqual(setup.sessionResumption, {});
  assert.ok(setup.inputAudioTranscription && setup.outputAudioTranscription);

  // Audio sent before the server confirms setup must be dropped, not queued.
  client.sendAudio(new Int16Array(160));
  sock.send(Buffer.from(JSON.stringify({ setupComplete: {} }))); // binary frame, like the real API
  await tick();
  assert.deepEqual(r.log, ['ready']);

  client.sendAudio(Int16Array.from([1, -2, 3]));
  const audioMsg = await nextMessage(sock);
  assert.equal(audioMsg.realtimeInput.audio.mimeType, 'audio/pcm;rate=16000');
  assert.equal(audioMsg.realtimeInput.audio.data, bytesToBase64(int16ToBytes(Int16Array.from([1, -2, 3]))));

  const voice = Int16Array.from([100, -100, 2000, -32768]);
  sock.send(
    JSON.stringify({
      serverContent: {
        inputTranscription: { text: 'מה ההבדל בין go ל-went?' },
        outputTranscription: { text: 'תקשיב,' },
        modelTurn: { parts: [{ inlineData: { mimeType: 'audio/pcm;rate=24000', data: bytesToBase64(int16ToBytes(voice)) } }] },
      },
    }),
  );
  sock.send(JSON.stringify({ toolCall: { functionCalls: [{ id: 'f1', name: 'set_expression', args: { emotion: 'annoyed' } }] } }));
  sock.send(JSON.stringify({ serverContent: { interrupted: true } }));
  sock.send(JSON.stringify({ serverContent: { turnComplete: true } }));
  sock.send('not json at all');
  await tick();

  assert.deepEqual([...r.audio[0]], [...voice]);
  assert.deepEqual(r.tools, [{ id: 'f1', name: 'set_expression', args: { emotion: 'annoyed' } }]);
  assert.deepEqual(r.log, ['ready', 'user:מה ההבדל בין go ל-went?', 'mina:תקשיב,', 'interrupted', 'turn']);

  client.respondToTools([{ id: 'f1', name: 'set_expression', result: { ok: true } }]);
  const resp = (await nextMessage(sock)).toolResponse.functionResponses[0];
  assert.deepEqual(resp, { id: 'f1', name: 'set_expression', response: { ok: true, scheduling: 'SILENT' } });

  client.sendText('hello');
  assert.deepEqual(await nextMessage(sock), { realtimeInput: { text: 'hello' } });

  client.close();
  await tick(60);
  assert.equal(r.getFatal(), null, 'closing on purpose is not an error');
  await srv.close();
});

test('network drop: reconnects and resumes the same session', async () => {
  const srv = await mockServer();
  const r = recorder();
  const client = new GeminiLiveClient('tok', SETUP, r.cb);
  let conn = srv.nextConnection();
  client.connect();
  let sock = await conn;
  await nextMessage(sock);
  sock.send(JSON.stringify({ setupComplete: {} }));
  sock.send(JSON.stringify({ sessionResumptionUpdate: { newHandle: 'handle-42', resumable: true } }));
  await tick();

  conn = srv.nextConnection();
  sock.terminate(); // simulate the network dying
  sock = await conn;
  const setup = (await nextMessage(sock)).setup;
  assert.deepEqual(setup.sessionResumption, { handle: 'handle-42' });
  sock.send(JSON.stringify({ setupComplete: {} }));
  await tick();
  assert.deepEqual(r.log, ['ready', 'reconnecting:1', 'ready']);
  assert.equal(r.getFatal(), null);
  client.close();
  await srv.close();
});

test('server refusing the token is reported, not retried forever', async () => {
  const srv = await mockServer();
  const r = recorder();
  const client = new GeminiLiveClient('bad', SETUP, r.cb);
  const conn = srv.nextConnection();
  client.connect();
  const sock = await conn;
  await nextMessage(sock);
  sock.close(1008, 'API key not valid');
  await tick(80);
  assert.deepEqual(r.getFatal(), { kind: 'rejected', code: 1008, detail: 'API key not valid' });
  assert.equal(srv.urls.length, 1);
  client.close();
  await srv.close();
});

test('gives up with a network error after repeated failures', async () => {
  const srv = await mockServer();
  const r = recorder();
  srv.wss.on('connection', (s) => s.terminate());
  const client = new GeminiLiveClient('tok', SETUP, r.cb);
  client.connect();
  for (let i = 0; i < 80 && !r.getFatal(); i++) await tick(100);
  assert.deepEqual(r.getFatal(), { kind: 'network' });
  assert.equal(srv.urls.length, 4); // first try + 3 reconnects
  client.close();
  await srv.close();
});
