"""Browser end-to-end test of the web build against a fake backend.

Nothing here talks to Supabase or Gemini: every HTTP call and the Gemini WebSocket
are intercepted and answered locally, so it checks the app's own behaviour only.

  pip install playwright pillow && playwright install chromium
  EXPO_PUBLIC_SUPABASE_URL=https://mock.supabase.co \
  EXPO_PUBLIC_SUPABASE_ANON_KEY=mock-anon-key-mock-anon-key-mock-anon-key \
    npx expo export --platform web --output-dir /tmp/mina-web
  (cd /tmp/mina-web && python3 -m http.server 8099 &)
  mkdir -p /tmp/shots && python3 tests/e2e/run.py [light|dark]
"""
import asyncio, base64, json, math, struct, sys, time
from playwright.async_api import async_playwright

OUT = '/tmp/shots'
def jwt():
    b = lambda d: base64.urlsafe_b64encode(json.dumps(d).encode()).rstrip(b'=').decode()
    return f"{b({'alg':'HS256','typ':'JWT'})}.{b({'sub':'u1','exp':int(time.time())+3600,'role':'authenticated','email':'t@example.com'})}.sig"

USER = {'id': 'u1', 'aud': 'authenticated', 'role': 'authenticated', 'email': 't@example.com', 'app_metadata': {}, 'user_metadata': {}, 'created_at': '2026-11-01T00:00:00Z'}
SESSION = {'access_token': jwt(), 'token_type': 'bearer', 'expires_in': 3600, 'expires_at': int(time.time()) + 3600, 'refresh_token': 'r', 'user': USER}
profile = {'id': 'u1', 'display_name': None, 'cefr_level': 'A1', 'interests': [], 'goal': None, 'daily_minutes': 10, 'hebrew_usage': 'medium', 'speech_speed': 'normal', 'onboarded': False}
db = {'sessions': [], 'mistakes': [], 'vocab': [], 'rpc': [], 'token_body': None}
CORS = {'access-control-allow-origin': '*', 'access-control-allow-headers': '*', 'access-control-allow-methods': '*'}

def tone(ms, freq=220, amp=9000):
    n = int(24000 * ms / 1000)
    pcm = b''.join(struct.pack('<h', int(amp * math.sin(2 * math.pi * freq * i / 24000) * (0.5 + 0.5 * math.sin(2 * math.pi * 6 * i / 24000)))) for i in range(n))
    return base64.b64encode(pcm).decode()

async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch(args=['--use-fake-device-for-media-stream', '--use-fake-ui-for-media-stream', '--no-sandbox', '--autoplay-policy=no-user-gesture-required'])
        ctx = await browser.new_context(viewport={'width': 390, 'height': 844}, device_scale_factor=2, permissions=['microphone'], locale='he-IL', color_scheme=sys.argv[1] if len(sys.argv) > 1 else 'light')
        page = await ctx.new_page()
        errors = []
        page.on('pageerror', lambda e: errors.append(f'pageerror: {e}'))
        page.on('console', lambda m: errors.append(f'console.{m.type}: {m.text}') if m.type in ('error',) else None)

        async def api(route):
            req = route.request
            url = req.url
            if req.method == 'OPTIONS':
                return await route.fulfill(status=200, headers=CORS)
            def ok(body, status=200):
                return route.fulfill(status=status, headers={**CORS, 'content-type': 'application/json'}, body=json.dumps(body))
            if '/auth/v1/signup' in url or '/auth/v1/token' in url:
                return await ok(SESSION)
            if '/auth/v1/logout' in url:
                return await route.fulfill(status=204, headers=CORS)
            if '/auth/v1/user' in url:
                return await ok(USER)
            if '/rest/v1/profiles' in url:
                if req.method == 'PATCH':
                    profile.update(json.loads(req.post_data)); return await ok(profile)
                return await ok(profile)
            if '/rest/v1/rpc/log_mistake' in url:
                body = json.loads(req.post_data); db['rpc'].append(body)
                db['mistakes'].append({'id': f"m{len(db['mistakes'])}", 'wrong': body['p_wrong'], 'correct': body['p_correct'], 'explanation_he': body['p_explanation_he'], 'category': body['p_category'], 'times_seen': 2})
                return await ok(2)
            if '/rest/v1/vocabulary' in url:
                if req.method == 'POST':
                    b = json.loads(req.post_data); db['vocab'].append({'id': f"v{len(db['vocab'])}", **b}); return await ok(None, 201)
                return await ok(db['vocab'])
            if '/rest/v1/mistakes' in url:
                return await ok(db['mistakes'])
            if '/rest/v1/lesson_sessions' in url:
                if req.method == 'POST':
                    db['sessions'].append(json.loads(req.post_data)); return await ok(None, 201)
                return await ok([{'started_at': s['started_at'], 'duration_seconds': s['duration_seconds']} for s in db['sessions']])
            if '/functions/v1/live-token' in url:
                db['token_body'] = json.loads(req.post_data)
                return await ok({'token': 'auth_tokens/mock', 'model': 'gemini-3.8-live', 'voice': 'Aoede', 'systemInstruction': 'mock', 'placement': False})
            print('UNHANDLED', req.method, url); return await ok({}, 404)
        await page.route('https://mock.supabase.co/**', api)

        live = {'setup': None, 'audio_msgs': 0, 'tool_responses': [], 'texts': []}
        async def gemini(ws):
            def on_msg(raw):
                m = json.loads(raw)
                if 'setup' in m:
                    live['setup'] = m['setup']; ws.send(json.dumps({'setupComplete': {}}))
                elif 'realtimeInput' in m:
                    if 'audio' in m['realtimeInput']: live['audio_msgs'] += 1
                    if 'text' in m['realtimeInput']: live['texts'].append(m['realtimeInput']['text'])
                elif 'toolResponse' in m:
                    live['tool_responses'] += m['toolResponse']['functionResponses']
            ws.on_message(on_msg)
            live['ws'] = ws
        await page.route_web_socket('wss://generativelanguage.googleapis.com/**', gemini)

        shot = lambda name: page.screenshot(path=f'{OUT}/{name}.png')
        await page.goto('http://127.0.0.1:8099/')
        await page.wait_for_selector('text=היי, אני מינה'); await page.wait_for_timeout(600); await shot('01-auth')
        await page.get_by_label('אימייל').fill('t@example.com'); await page.get_by_label('סיסמה').fill('secret12')
        await page.get_by_role('button', name='יצירת חשבון').click()
        await page.wait_for_selector('text=איך קוראים לך?'); await page.get_by_label('השם שלך').fill('דני'); await shot('02-onb-name')
        await page.get_by_role('button', name='המשך').click(); await page.get_by_role('button', name='בסיסי').click(); await page.wait_for_timeout(300); await shot('03-onb-level')
        await page.get_by_role('button', name='המשך').click(); await page.get_by_role('button', name='ספורט').click(); await page.get_by_role('button', name='כושר').click()
        await page.get_by_role('button', name='המשך').click(); await page.get_by_role('button', name='טיולים בחו״ל').click(); await shot('04-onb-goal')
        await page.get_by_role('button', name='המשך').click(); await page.wait_for_timeout(200); await shot('05-onb-habits')
        await page.get_by_role('button', name='יאללה, מתחילים').click()
        await page.wait_for_selector('text=היי דני'); await page.wait_for_timeout(500); await shot('06-home')
        assert profile['onboarded'] and profile['cefr_level'] == 'A2' and profile['interests'] == ['ספורט', 'כושר'], profile

        await page.get_by_role('button', name='להתחיל שיעור').click()
        await page.wait_for_selector('text=מינה מקשיבה', timeout=15000)
        ws = live['ws']
        assert db['token_body'] == {'mode': 'daily'}, db['token_body']
        await page.wait_for_timeout(700); await shot('07-session-listening')
        assert live['audio_msgs'] > 3, live['audio_msgs']   # microphone audio is streaming up
        assert any('lesson just started' in t for t in live['texts'])

        # Mina speaks, changes expression and writes on the board.
        ws.send(json.dumps({'toolCall': {'functionCalls': [{'id': 'a', 'name': 'set_expression', 'args': {'emotion': 'annoyed'}}]}}))
        ws.send(json.dumps({'serverContent': {'inputTranscription': {'text': 'Yesterday I go to the gym'}}}))
        ws.send(json.dumps({'serverContent': {'outputTranscription': {'text': "Again?! We literally practiced this yesterday! It's \"I went to the gym.\""}, 'modelTurn': {'parts': [{'inlineData': {'mimeType': 'audio/pcm;rate=24000', 'data': tone(3000)}}]}}}))
        ws.send(json.dumps({'toolCall': {'functionCalls': [
            {'id': 'b', 'name': 'whiteboard_show', 'args': {'title': 'עבר פשוט', 'blocks': [
                {'kind': 'correction', 'wrong': 'Yesterday I go to the gym', 'en': 'Yesterday I went to the gym', 'highlight': ['went'], 'he': 'אתמול = עבר, אז go הופך ל-went'},
                {'kind': 'rule', 'he': 'go זה הווה, went זה עבר', 'en': 'go → went', 'highlight': ['went']},
                {'kind': 'word', 'en': 'treadmill', 'he': 'הליכון', 'emoji': '🏃'}]}},
            {'id': 'c', 'name': 'save_mistake', 'args': {'wrong': 'Yesterday I go to the gym', 'correct': 'Yesterday I went to the gym', 'explanation_he': 'אחרי yesterday משתמשים בעבר', 'category': 'grammar'}},
            {'id': 'd', 'name': 'save_vocabulary', 'args': {'word': 'treadmill', 'translation_he': 'הליכון', 'example': 'I run on the treadmill.'}},
            {'id': 'e', 'name': 'set_expression', 'args': {'emotion': 'furious'}},
        ]}}))
        await page.wait_for_selector('text=מינה מדברת'); await page.wait_for_timeout(900); await shot('08-session-speaking-annoyed')
        byid = {r['id']: r['response'] for r in live['tool_responses']}
        assert byid['a'] == {'ok': True, 'scheduling': 'SILENT'}, byid
        assert byid['b']['shown'] == 3 and byid['c'] == {'saved': True, 'times_seen': 2, 'repeated': True, 'scheduling': 'SILENT'} and byid['d']['saved'] is True, byid
        assert byid['e']['ok'] is False, byid  # invalid emotion is rejected back to the model

        # Student interrupts: playback must stop at once.
        ws.send(json.dumps({'serverContent': {'interrupted': True}}))
        await page.wait_for_selector('text=מינה מקשיבה', timeout=2000)

        ws.send(json.dumps({'toolCall': {'functionCalls': [
            {'id': 'f', 'name': 'set_expression', 'args': {'emotion': 'laughing'}},
            {'id': 'g', 'name': 'whiteboard_show', 'args': {'append': False, 'blocks': [
                {'kind': 'fill_blank', 'en': 'Last week I ____ to the gym three times.', 'answer': 'went', 'he': 'בשבוע שעבר הלכתי לחדר כושר שלוש פעמים'},
                {'kind': 'word_by_word', 'pairs': [{'en': 'I', 'he': 'אני'}, {'en': 'went', 'he': 'הלכתי'}, {'en': 'to the gym', 'he': 'לחדר כושר'}]},
                {'kind': 'pronunciation', 'en': 'went', 'he': 'וֶנְט, עם W עגולה ולא V'},
                {'kind': 'note', 'he': 'לא לשכוח: yesterday = עבר!'}]}}]}}))
        ws.send(json.dumps({'serverContent': {'modelTurn': {'parts': [{'inlineData': {'mimeType': 'audio/pcm;rate=24000', 'data': tone(2500, 300, 14000)}}]}}}))
        await page.wait_for_timeout(1000); await shot('09-session-laughing-exercise')
        ws.send(json.dumps({'toolCall': {'functionCalls': [{'id': 'h', 'name': 'whiteboard_reveal', 'args': {}}]}}))
        await page.wait_for_timeout(500); await shot('10-session-revealed')
        await page.get_by_role('button', name='לבקש הסבר בעברית').click(); await page.wait_for_timeout(100)
        assert any('explain in Hebrew' in t for t in live['texts'])
        await page.get_by_role('button', name='להשתיק את המיקרופון').click(); await page.wait_for_timeout(300); await shot('11-session-muted')

        # Network drop -> resume.
        ws.send(json.dumps({'sessionResumptionUpdate': {'newHandle': 'h1', 'resumable': True}})); await page.wait_for_timeout(100)
        live['setup'] = None; await ws.close(code=1011, reason='')
        await page.wait_for_function('true', timeout=1000)
        for _ in range(40):
            if live['setup']: break
            await page.wait_for_timeout(100)
        assert live['setup'] and live['setup']['sessionResumption'] == {'handle': 'h1'}, live['setup']

        await page.wait_for_timeout(20500)  # lessons under 20 s are not recorded
        await page.get_by_role('button', name='לסיים את השיעור').click()
        await page.wait_for_selector('text=מה תיקנו היום'); await page.wait_for_timeout(500); await shot('12-summary')
        s = db['sessions'][0]
        assert s['mode'] == 'daily' and s['mistakes_count'] == 1 and s['vocabulary_count'] == 1 and s['duration_seconds'] >= 20, s
        assert s['transcript'][0] == {'who': 'student', 'text': 'Yesterday I go to the gym'}, s['transcript']
        await page.get_by_role('button', name='סיום').click(); await page.wait_for_selector('text=היי דני'); await page.wait_for_timeout(500); await shot('13-home-after')
        for tab, name in [('לימוד', '14-learn'), ('תרגול', '15-practice'), ('חזרה', '16-review'), ('פרופיל', '17-profile')]:
            await page.get_by_role('tab', name=tab).click(); await page.wait_for_timeout(600); await shot(name)
        print('E2E OK'); print('\n'.join(errors[:20]))
        await browser.close()
asyncio.run(main())
