import assert from 'node:assert/strict';
import { test } from 'node:test';
import { buildToolDeclarations, parseBlocks, parseCefr, parseEmotion, splitHighlights } from '../src/lib/live/tools';
import { minutesToday, streak, weekMinutes } from '../src/lib/stats';

test('parseBlocks keeps valid blocks and drops junk from the model', () => {
  const blocks = parseBlocks([
    { kind: 'correction', wrong: 'Yesterday I go to the gym', en: 'Yesterday I went to the gym', highlight: ['went', 7], he: 'עבר' },
    { kind: 'dance', en: 'nope' },
    { kind: 'word' },
    'garbage',
    null,
    { kind: 'word_by_word', pairs: [{ en: 'I', he: 'אני' }, { en: 'went' }, { he: 'x' }] },
  ]);
  assert.equal(blocks.length, 2);
  assert.equal(blocks[0].kind, 'correction');
  assert.deepEqual(blocks[0].highlight, ['went']);
  assert.deepEqual(blocks[1].pairs, [{ en: 'I', he: 'אני' }]);
  assert.notEqual(blocks[0].id, blocks[1].id);
  assert.deepEqual(parseBlocks('not an array'), []);
  assert.deepEqual(parseBlocks(undefined), []);
});

test('parseBlocks caps size', () => {
  const many = Array.from({ length: 30 }, () => ({ kind: 'sentence', en: 'x'.repeat(5000) }));
  const out = parseBlocks(many);
  assert.equal(out.length, 8);
  assert.equal(out[0].en!.length, 400);
});

test('emotion and level parsing reject unknown values', () => {
  assert.equal(parseEmotion('annoyed'), 'annoyed');
  assert.equal(parseEmotion('furious'), null);
  assert.equal(parseEmotion(undefined), null);
  assert.equal(parseCefr('B2'), 'B2');
  assert.equal(parseCefr('Z9'), null);
});

test('splitHighlights marks words case-insensitively and is regex-safe', () => {
  assert.deepEqual(splitHighlights('I went home', ['WENT']), [
    { text: 'I ', hit: false },
    { text: 'went', hit: true },
    { text: ' home', hit: false },
  ]);
  assert.deepEqual(splitHighlights('How much (is) it?', ['(is)']).filter((p) => p.hit), [{ text: '(is)', hit: true }]);
  assert.deepEqual(splitHighlights('plain', []), [{ text: 'plain', hit: false }]);
});

test('set_level tool only exists in the placement test', () => {
  const names = (p: boolean) => buildToolDeclarations({ placement: p })[0].functionDeclarations.map((f: any) => f.name);
  assert.ok(!names(false).includes('set_level'));
  assert.ok(names(true).includes('set_level'));
  for (const n of ['set_expression', 'whiteboard_show', 'whiteboard_clear', 'save_mistake', 'save_vocabulary']) {
    assert.ok(names(false).includes(n));
  }
});

test('streak and weekly minutes', () => {
  const now = new Date(2026, 10, 15, 16, 0);
  const at = (daysAgo: number, secs: number) => {
    const d = new Date(now);
    d.setDate(d.getDate() - daysAgo);
    return { started_at: d.toISOString(), duration_seconds: secs };
  };
  assert.equal(streak([], now), 0);
  assert.equal(streak([at(0, 600), at(1, 600), at(2, 60), at(4, 600)], now), 3);
  assert.equal(streak([at(1, 600), at(2, 600)], now), 2); // today not done yet: streak still alive
  assert.equal(streak([at(2, 600)], now), 0);
  const week = weekMinutes([at(0, 600), at(0, 330), at(6, 120), at(7, 999)], now);
  assert.deepEqual(week, [2, 0, 0, 0, 0, 0, 16]);
  assert.equal(minutesToday([at(0, 600)], now), 10);
});
