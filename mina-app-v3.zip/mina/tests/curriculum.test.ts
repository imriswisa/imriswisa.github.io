import assert from 'node:assert/strict';
import { test } from 'node:test';
import { CURRICULUM, lessonById, lessonsFor, nextLesson } from '../src/lib/curriculum';
import { LANGUAGES, lang } from '../src/lib/languages';

test('every lesson is complete and ids are unique', () => {
  const ids = new Set<string>();
  for (const l of CURRICULUM) {
    assert.ok(!ids.has(l.id), l.id);
    ids.add(l.id);
    for (const k of ['title', 'goal', 'topic', 'warmup', 'practice', 'scene'] as const) assert.ok(l[k].length > 3, `${l.id}.${k}`);
    assert.ok(l.teach.length >= 3, l.id);
  }
});

test('next lesson walks the level in order, then cycles', () => {
  const a1 = lessonsFor('A1');
  assert.equal(nextLesson('A1', []).id, a1[0].id);
  assert.equal(nextLesson('A1', [a1[0].id]).id, a1[1].id);
  const all = a1.map((l) => l.id);
  assert.ok(a1.some((l) => l.id === nextLesson('A1', all).id));
  assert.ok(lessonsFor('C2').length > 0);
  assert.equal(lessonById(a1[2].id)?.title, a1[2].title);
  assert.equal(lessonById('nope'), undefined);
});

test('languages', () => {
  assert.equal(lang('he').rtl, true);
  assert.equal(lang('fr').en, 'French');
  assert.equal(lang('xx').code, 'en');
  assert.equal(new Set(LANGUAGES.map((l) => l.code)).size, LANGUAGES.length);
});

import { formatCountdown, israelTime, nextDailyReset, scopeFromText } from '../src/lib/quota';

test('daily quota resets at midnight Pacific, shown in Israel time', () => {
  // Winter: 16 Nov 2026 14:39 Israel (12:39 UTC). LA midnight = 08:00 UTC next day = 10:00 Israel.
  const winter = new Date(Date.UTC(2026, 10, 16, 12, 39));
  const r1 = nextDailyReset(winter);
  assert.equal(r1.toISOString(), '2026-11-17T08:00:00.000Z');
  assert.deepEqual(israelTime(r1, winter), { time: '10:00', day: 'מחר' });
  // Summer: 1 Jul 2026 05:00 Israel (02:00 UTC). LA is still on 30 Jun; midnight = 07:00 UTC = 10:00 Israel today.
  const summer = new Date(Date.UTC(2026, 6, 1, 2, 0));
  const r2 = nextDailyReset(summer);
  assert.equal(r2.toISOString(), '2026-07-01T07:00:00.000Z');
  assert.deepEqual(israelTime(r2, summer), { time: '10:00', day: 'היום' });
  // Late March: Israel already on summer time, the US too -> 10:00 Israel.
  const march = new Date(Date.UTC(2026, 2, 28, 20, 0));
  assert.deepEqual(israelTime(nextDailyReset(march), march), { time: '10:00', day: 'מחר' });
});

test('countdown and scope helpers', () => {
  assert.equal(formatCountdown(65), '1:05');
  assert.equal(formatCountdown(-3), '0:00');
  assert.equal(scopeFromText('Quota exceeded for GenerateRequestsPerDayPerProject'), 'day');
  assert.equal(scopeFromText('per minute limit'), 'minute');
  assert.equal(scopeFromText('RESOURCE_EXHAUSTED'), 'unknown');
});
