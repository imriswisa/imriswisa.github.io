import assert from 'node:assert/strict';
import { test } from 'node:test';
import {
  LevelTimeline,
  LinearResampler,
  base64ToBytes,
  bytesToBase64,
  bytesToInt16,
  floatToInt16,
  int16ToBytes,
  utf8Decode,
} from '../src/lib/audio/pcm';

test('base64 round-trips every length and matches Node', () => {
  for (let len = 0; len < 70; len++) {
    const bytes = Uint8Array.from({ length: len }, (_, i) => (i * 37 + len * 11) & 0xff);
    const b64 = bytesToBase64(bytes);
    assert.equal(b64, Buffer.from(bytes).toString('base64'));
    assert.deepEqual([...base64ToBytes(b64)], [...bytes]);
  }
});

test('PCM bytes <-> int16 keeps sign and endianness', () => {
  const pcm = Int16Array.from([0, 1, -1, 32767, -32768, 12345, -12345]);
  const bytes = int16ToBytes(pcm);
  assert.deepEqual([...bytes.slice(2, 6)], [1, 0, 0xff, 0xff]);
  assert.deepEqual([...bytesToInt16(bytes)], [...pcm]);
});

test('floatToInt16 clamps out-of-range samples', () => {
  assert.deepEqual([...floatToInt16(Float32Array.from([0, 1, -1, 2, -2, 0.5]))], [0, 32767, -32768, 32767, -32768, 16384]);
});

test('resampler 48k -> 16k: right length and no seams across blocks', () => {
  const total = 4800;
  const ramp = Float32Array.from({ length: total }, (_, i) => i / total);
  const whole = new LinearResampler(48000, 16000).process(ramp);
  assert.equal(whole.length, 1600);

  const r = new LinearResampler(48000, 16000);
  const parts: number[] = [];
  for (let off = 0; off < total; off += 128) parts.push(...r.process(ramp.subarray(off, Math.min(total, off + 128))));
  assert.equal(parts.length, 1600);
  parts.forEach((v, i) => assert.ok(Math.abs(v - whole[i]) < 1e-6, `sample ${i}`));
});

test('resampler 44.1k -> 16k keeps a steady ramp across uneven blocks', () => {
  const r = new LinearResampler(44100, 16000);
  const ramp = Float32Array.from({ length: 44100 }, (_, i) => i / 44100);
  const out: number[] = [];
  for (let off = 0; off < ramp.length; off += 128) out.push(...r.process(ramp.subarray(off, off + 128)));
  assert.ok(Math.abs(out.length - 16000) <= 1);
  for (let i = 1; i < out.length; i++) assert.ok(Math.abs(out[i] - out[i - 1] - 1 / 16000) < 1e-5);
});

test('level timeline follows playback time, not arrival time', () => {
  const tl = new LevelTimeline();
  const loud = new Int16Array(2400).fill(8000); // 100 ms
  const quiet = new Int16Array(2400); // 100 ms of silence
  assert.equal(tl.push(loud, 24000, 1000), 1000);
  assert.equal(tl.push(quiet, 24000, 1000), 1100); // queued behind the first chunk
  assert.ok(tl.levelAt(1050) > 0.5);
  assert.equal(tl.levelAt(1150), 0);
  assert.equal(tl.isPlaying(1150), true);
  assert.equal(tl.isPlaying(1250), false);
  tl.push(loud, 24000, 2000);
  tl.clear(); // interruption
  assert.equal(tl.levelAt(2010), 0);
  assert.equal(tl.isPlaying(2010), false);
});

test('utf8Decode handles Hebrew and emoji', () => {
  const text = '{"t":"מה ההבדל בין go ל-went? 🏋️"}';
  assert.equal(utf8Decode(new TextEncoder().encode(text)), text);
});
